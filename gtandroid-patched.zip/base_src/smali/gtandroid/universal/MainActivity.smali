.class public Lgtandroid/universal/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/MainActivity$100000000;,
        Lgtandroid/universal/MainActivity$100000001;,
        Lgtandroid/universal/MainActivity$100000002;,
        Lgtandroid/universal/MainActivity$100000003;,
        Lgtandroid/universal/MainActivity$100000004;,
        Lgtandroid/universal/MainActivity$100000005;,
        Lgtandroid/universal/MainActivity$100000006;,
        Lgtandroid/universal/MainActivity$100000007;,
        Lgtandroid/universal/MainActivity$100000008;,
        Lgtandroid/universal/MainActivity$100000009;,
        Lgtandroid/universal/MainActivity$100000010;,
        Lgtandroid/universal/MainActivity$100000012;,
        Lgtandroid/universal/MainActivity$100000013;,
        Lgtandroid/universal/MainActivity$100000015;,
        Lgtandroid/universal/MainActivity$EventToggle;,
        Lgtandroid/universal/MainActivity$100000016;,
        Lgtandroid/universal/MainActivity$100000017;,
        Lgtandroid/universal/MainActivity$100000019;,
        Lgtandroid/universal/MainActivity$100000020;,
        Lgtandroid/universal/MainActivity$100000021;,
        Lgtandroid/universal/MainActivity$100000022;,
        Lgtandroid/universal/MainActivity$100000023;,
        Lgtandroid/universal/MainActivity$100000024;,
        Lgtandroid/universal/MainActivity$100000025;,
        Lgtandroid/universal/MainActivity$100000026;,
        Lgtandroid/universal/MainActivity$100000027;,
        Lgtandroid/universal/MainActivity$100000028;,
        Lgtandroid/universal/MainActivity$100000029;,
        Lgtandroid/universal/MainActivity$100000030;,
        Lgtandroid/universal/MainActivity$100000031;,
        Lgtandroid/universal/MainActivity$100000032;,
        Lgtandroid/universal/MainActivity$100000033;,
        Lgtandroid/universal/MainActivity$100000034;,
        Lgtandroid/universal/MainActivity$100000035;,
        Lgtandroid/universal/MainActivity$100000036;,
        Lgtandroid/universal/MainActivity$100000037;,
        Lgtandroid/universal/MainActivity$100000038;,
        Lgtandroid/universal/MainActivity$100000039;,
        Lgtandroid/universal/MainActivity$100000040;,
        Lgtandroid/universal/MainActivity$100000041;,
        Lgtandroid/universal/MainActivity$100000042;,
        Lgtandroid/universal/MainActivity$100000043;,
        Lgtandroid/universal/MainActivity$100000045;,
        Lgtandroid/universal/MainActivity$100000046;,
        Lgtandroid/universal/MainActivity$100000047;,
        Lgtandroid/universal/MainActivity$100000048;,
        Lgtandroid/universal/MainActivity$100000049;,
        Lgtandroid/universal/MainActivity$100000050;,
        Lgtandroid/universal/MainActivity$100000052;,
        Lgtandroid/universal/MainActivity$100000053;,
        Lgtandroid/universal/MainActivity$100000054;,
        Lgtandroid/universal/MainActivity$100000055;,
        Lgtandroid/universal/MainActivity$100000056;,
        Lgtandroid/universal/MainActivity$100000057;,
        Lgtandroid/universal/MainActivity$100000058;,
        Lgtandroid/universal/MainActivity$100000059;,
        Lgtandroid/universal/MainActivity$100000060;,
        Lgtandroid/universal/MainActivity$100000061;,
        Lgtandroid/universal/MainActivity$100000062;,
        Lgtandroid/universal/MainActivity$100000063;,
        Lgtandroid/universal/MainActivity$100000064;,
        Lgtandroid/universal/MainActivity$100000065;,
        Lgtandroid/universal/MainActivity$100000066;,
        Lgtandroid/universal/MainActivity$100000067;,
        Lgtandroid/universal/MainActivity$100000068;,
        Lgtandroid/universal/MainActivity$100000069;,
        Lgtandroid/universal/MainActivity$100000070;,
        Lgtandroid/universal/MainActivity$100000071;,
        Lgtandroid/universal/MainActivity$100000072;,
        Lgtandroid/universal/MainActivity$100000073;,
        Lgtandroid/universal/MainActivity$100000074;,
        Lgtandroid/universal/MainActivity$100000075;,
        Lgtandroid/universal/MainActivity$100000076;,
        Lgtandroid/universal/MainActivity$100000077;,
        Lgtandroid/universal/MainActivity$100000078;,
        Lgtandroid/universal/MainActivity$100000079;,
        Lgtandroid/universal/MainActivity$100000080;,
        Lgtandroid/universal/MainActivity$100000081;,
        Lgtandroid/universal/MainActivity$100000082;,
        Lgtandroid/universal/MainActivity$100000083;,
        Lgtandroid/universal/MainActivity$100000084;,
        Lgtandroid/universal/MainActivity$100000085;,
        Lgtandroid/universal/MainActivity$100000086;,
        Lgtandroid/universal/MainActivity$100000087;,
        Lgtandroid/universal/MainActivity$100000088;
    }
.end annotation


# static fields
.field private static final ADS_JSON_URL:Ljava/lang/String; = "https://www.dropbox.com/scl/fi/09ruiljtbntgf9rgvhvq9/ads.json?rlkey=0w8aip1kjoyv37nt8cb02q1pc&st=yp4oxh66&dl=1"

.field private static final BG_CARD:I = -0xedebe3

.field private static final BG_DARK:I = -0xf5f3ee

.field private static final EVENTS_KEY:Ljava/lang/String; = "events_list"

.field private static final NEON_AMBER:I = -0x36c3

.field private static final NEON_CYAN:I = -0xff1a01

.field private static final NEON_GREEN:I = -0xc60078

.field private static final NEON_MAGENTA:I = -0xd13c

.field private static final NEON_RED:I = -0xb293

.field private static final NEON_VIOLET:I = -0x57aa01

.field private static final PUNISHMENT_QUEUE_KEY:Ljava/lang/String; = "punishment_queue_lines"

.field private static final REQUEST_ACCESS_GATE:I = 0x28e

.field private static final REQUEST_EXPORT:I = 0x378

.field private static final REQUEST_IMPORT:I = 0x309

.field private static final REQUEST_LOG_EXPORT:I = 0x3df

.field private static final REQUEST_NAV_EXPORT:I = 0x296

.field private static final REQUEST_NAV_IMPORT:I = 0x295

.field private static final REQUEST_OVERLAY:I = 0x3e7

.field private static final REQUEST_T9_EXPORT:I = 0x371

.field private static final REQUEST_T9_IMPORT:I = 0x303

.field private static final REQUEST_TRG_EXPORT:I = 0x298

.field private static final REQUEST_TRG_IMPORT:I = 0x297

.field private static final TEXT_MUTED:I = -0x655f4c


# instance fields
.field private bottomNav:Landroid/widget/LinearLayout;

.field private btnToggleMenu:Landroid/widget/Button;

.field customButtons:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private eventEditorDialog:Landroid/app/AlertDialog;

.field private isFloatingMenuEnabled:Z

.field private mainContainer:Landroid/widget/LinearLayout;

.field prefs:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>()V
    .locals 6

    .prologue
    .line 3504
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Landroid/app/Activity;-><init>()V

    move-object v2, v0

    new-instance v3, Ljava/util/ArrayList;

    move-object v5, v3

    move-object v3, v5

    move-object v4, v5

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    iput-object v3, v2, Lgtandroid/universal/MainActivity;->customButtons:Ljava/util/ArrayList;

    move-object v2, v0

    const/4 v3, 0x0

    iput-boolean v3, v2, Lgtandroid/universal/MainActivity;->isFloatingMenuEnabled:Z

    return-void
.end method

.method static access$1000035(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->postTrackerReadyNotification()V

    return-void
.end method

.method static access$1000046(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showMainScreen()V

    return-void
.end method

.method static access$1000052(Lgtandroid/universal/MainActivity;Lorg/json/JSONArray;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->displayAds(Lorg/json/JSONArray;)V

    return-void
.end method

.method static access$1000056(Lgtandroid/universal/MainActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->downloadString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object v0, v4

    return-object v0
.end method

.method static access$1000058(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->toggleFloatingMenu()V

    return-void
.end method

.method static access$1000064(Lgtandroid/universal/MainActivity;)Lorg/json/JSONArray;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->loadEvents()Lorg/json/JSONArray;

    move-result-object v3

    move-object v0, v3

    return-object v0
.end method

.method static access$1000065(Lgtandroid/universal/MainActivity;Lorg/json/JSONArray;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->saveEvents(Lorg/json/JSONArray;)V

    return-void
.end method

.method static access$1000066(Lgtandroid/universal/MainActivity;Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->normalizeEventTime(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object v0, v4

    return-object v0
.end method

.method static access$1000077(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showEventEditor()V

    return-void
.end method

.method static access$1000080(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->showEventEditDialog(I)V

    return-void
.end method

.method static access$1000089(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showEditorScreen()V

    return-void
.end method

.method static access$1000098(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showSettingsScreen()V

    return-void
.end method

.method static access$1000102(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showSpecialFeaturesScreen()V

    return-void
.end method

.method static access$1000108(Lgtandroid/universal/MainActivity;Ljava/util/List;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->savePunishmentQueueLines(Ljava/util/List;)V

    return-void
.end method

.method static access$1000109(Lgtandroid/universal/MainActivity;)Ljava/util/List;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->loadQuickAnswerPairs()Ljava/util/List;

    move-result-object v3

    move-object v0, v3

    return-object v0
.end method

.method static access$1000112(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showTriggerEditor()V

    return-void
.end method

.method static access$1000113(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->updateTriggerMasterButton(Landroid/widget/Button;)V

    return-void
.end method

.method static access$1000115(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showTriggerList()V

    return-void
.end method

.method static access$1000120(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->showTriggerEditDialog(I)V

    return-void
.end method

.method static access$1000126(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showNavigatorEditor()V

    return-void
.end method

.method static access$1000130(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showNavigatorListDialog()V

    return-void
.end method

.method static access$1000134(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showPunishmentQueueEditor()V

    return-void
.end method

.method static access$1000136(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showPunishmentEditor()V

    return-void
.end method

.method static access$1000139(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->showPunishmentTypeEditor(Ljava/lang/String;)V

    return-void
.end method

.method static access$1000141(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->showAddPunishmentDialog(Ljava/lang/String;)V

    return-void
.end method

.method static access$1000142(Lgtandroid/universal/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object v9, v0

    move-object v10, v1

    move-object v11, v2

    move-object v12, v3

    move-object v13, v4

    move-object v14, v5

    move-object v15, v6

    invoke-direct/range {v9 .. v15}, Lgtandroid/universal/MainActivity;->savePunishment(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000145(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->showPunishmentsListByType(Ljava/lang/String;)V

    return-void
.end method

.method static access$1000147(Lgtandroid/universal/MainActivity;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object v10, v0

    move-object v11, v1

    move v12, v2

    move-object v13, v3

    move-object v14, v4

    move-object v15, v5

    move-object/from16 v16, v6

    move-object/from16 v17, v7

    invoke-direct/range {v10 .. v17}, Lgtandroid/universal/MainActivity;->showEditPunishmentDialog(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000148(Lgtandroid/universal/MainActivity;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object v10, v0

    move-object v11, v1

    move v12, v2

    move-object v13, v3

    move-object v14, v4

    move-object v15, v5

    move-object/from16 v16, v6

    move-object/from16 v17, v7

    invoke-direct/range {v10 .. v17}, Lgtandroid/universal/MainActivity;->updatePunishment(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000149(Lgtandroid/universal/MainActivity;Ljava/lang/String;I)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v5, v0

    move-object v6, v1

    move v7, v2

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/MainActivity;->deletePunishment(Ljava/lang/String;I)V

    return-void
.end method

.method static access$1000152(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showQuickAnswersEditor()V

    return-void
.end method

.method static access$1000154(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showAddQuickAnswerDialog()V

    return-void
.end method

.method static access$1000155(Lgtandroid/universal/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v6, v0

    move-object v7, v1

    move-object v8, v2

    move-object v9, v3

    invoke-direct {v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->saveQuickAnswer(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000158(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showQuickAnswersList()V

    return-void
.end method

.method static access$1000160(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 12

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object/from16 v4, p4

    move-object v7, v0

    move v8, v1

    move-object v9, v2

    move-object v10, v3

    move-object v11, v4

    invoke-direct {v7, v8, v9, v10, v11}, Lgtandroid/universal/MainActivity;->showEditQuickAnswerDialog(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000161(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 12

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object/from16 v4, p4

    move-object v7, v0

    move v8, v1

    move-object v9, v2

    move-object v10, v3

    move-object v11, v4

    invoke-direct {v7, v8, v9, v10, v11}, Lgtandroid/universal/MainActivity;->updateQuickAnswer(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000162(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->deleteQuickAnswer(I)V

    return-void
.end method

.method static access$1000166(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showNormalButtonsList()V

    return-void
.end method

.method static access$1000168(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;)V
    .locals 10

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v6, v0

    move v7, v1

    move-object v8, v2

    move-object v9, v3

    invoke-direct {v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->showEditNormalButtonDialog(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000169(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;)V
    .locals 10

    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v6, v0

    move v7, v1

    move-object v8, v2

    move-object v9, v3

    invoke-direct {v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->updateNormalButton(ILjava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000170(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->deleteNormalButton(I)V

    return-void
.end method

.method static access$1000174(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showTransparencyDialog()V

    return-void
.end method

.method static access$1000176(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showKeyboardSizeDialog()V

    return-void
.end method

.method static access$1000178(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showAdminLevelDialog()V

    return-void
.end method

.method static access$1000179(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->exportConfig()V

    return-void
.end method

.method static access$1000180(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->importConfig()V

    return-void
.end method

.method static access$1000183(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showFamWarEditor()V

    return-void
.end method

.method static access$1000185(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showAddFamWarDialog()V

    return-void
.end method

.method static access$1000186(Lgtandroid/universal/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 14

    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object v8, v0

    move-object v9, v1

    move-object v10, v2

    move-object v11, v3

    move-object v12, v4

    move-object v13, v5

    invoke-direct/range {v8 .. v13}, Lgtandroid/universal/MainActivity;->saveFamWarCommand(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000189(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showFamWarList()V

    return-void
.end method

.method static access$1000191(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object v9, v0

    move v10, v1

    move-object v11, v2

    move-object v12, v3

    move-object v13, v4

    move-object v14, v5

    move-object v15, v6

    invoke-direct/range {v9 .. v15}, Lgtandroid/universal/MainActivity;->showEditFamWarDialog(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000192(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object v9, v0

    move v10, v1

    move-object v11, v2

    move-object v12, v3

    move-object v13, v4

    move-object v14, v5

    move-object v15, v6

    invoke-direct/range {v9 .. v15}, Lgtandroid/universal/MainActivity;->updateFamWarCommand(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method static access$1000193(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->deleteFamWarCommand(I)V

    return-void
.end method

.method static access$1000196(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->notifyT9DictChanged()V

    return-void
.end method

.method static access$1000203(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showT9Editor()V

    return-void
.end method

.method static access$1000205(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showAddT9WordDialog()V

    return-void
.end method

.method static access$1000206(Lgtandroid/universal/MainActivity;Ljava/lang/String;)Z
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->addT9Word(Ljava/lang/String;)Z

    move-result v4

    move v0, v4

    return v0
.end method

.method static access$1000208(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showT9WordsList()V

    return-void
.end method

.method static access$1000209(Lgtandroid/universal/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/MainActivity;->deleteT9Word(I)V

    return-void
.end method

.method static access$1000210(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->importT9Dictionary()V

    return-void
.end method

.method static access$1000211(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->exportT9Dictionary()V

    return-void
.end method

.method static access$1000215(Lgtandroid/universal/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->showErrorLogDialog()V

    return-void
.end method

.method static access$L1000006()I
    .locals 3

    sget v2, Lgtandroid/universal/MainActivity;->REQUEST_LOG_EXPORT:I

    move v0, v2

    return v0
.end method

.method static access$L1000007()I
    .locals 3

    sget v2, Lgtandroid/universal/MainActivity;->REQUEST_NAV_IMPORT:I

    move v0, v2

    return v0
.end method

.method static access$L1000008()I
    .locals 3

    sget v2, Lgtandroid/universal/MainActivity;->REQUEST_NAV_EXPORT:I

    move v0, v2

    return v0
.end method

.method static access$L1000009()I
    .locals 3

    sget v2, Lgtandroid/universal/MainActivity;->REQUEST_TRG_IMPORT:I

    move v0, v2

    return v0
.end method

.method static access$L1000010()I
    .locals 3

    sget v2, Lgtandroid/universal/MainActivity;->REQUEST_TRG_EXPORT:I

    move v0, v2

    return v0
.end method

.method static access$L1000024()Ljava/lang/String;
    .locals 3

    sget-object v2, Lgtandroid/universal/MainActivity;->ADS_JSON_URL:Ljava/lang/String;

    move-object v0, v2

    return-object v0
.end method

.method static access$S1000006(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/MainActivity;->REQUEST_LOG_EXPORT:I

    return-void
.end method

.method static access$S1000007(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/MainActivity;->REQUEST_NAV_IMPORT:I

    return-void
.end method

.method static access$S1000008(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/MainActivity;->REQUEST_NAV_EXPORT:I

    return-void
.end method

.method static access$S1000009(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/MainActivity;->REQUEST_TRG_IMPORT:I

    return-void
.end method

.method static access$S1000010(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/MainActivity;->REQUEST_TRG_EXPORT:I

    return-void
.end method

.method static access$S1000024(Ljava/lang/String;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    sput-object v3, Lgtandroid/universal/MainActivity;->ADS_JSON_URL:Ljava/lang/String;

    return-void
.end method

.method private addAutoReportAndAutoFormToggles(Landroid/widget/LinearLayout;)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            ")V"
        }
    .end annotation

    .prologue
    .line 153
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    new-instance v13, Landroid/widget/Button;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    move-object v15, v0

    invoke-direct {v14, v15}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v3, v13

    .line 154
    move-object v13, v3

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    const-string v15, "\ud83d\udccb \u0410\u0432\u0442\u043e\u0440\u0435\u043f\u043e\u0440\u0442: "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move-object v15, v0

    iget-object v15, v15, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v16, "floating_menu_enabled"

    const/16 v17, 0x0

    invoke-interface/range {v15 .. v17}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    if-eqz v15, :cond_0

    const-string v15, "\u0412\u043a\u043b"

    :goto_0
    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 155
    move-object v13, v3

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    const/16 v16, -0x1

    const/16 v17, -0x2

    invoke-direct/range {v15 .. v17}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 158
    move-object v13, v3

    const/16 v14, 0x14

    const/16 v15, 0x19

    const/16 v16, 0x14

    const/16 v17, 0x19

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 159
    move-object v13, v3

    const/16 v14, 0x10

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 160
    move-object v13, v3

    const/4 v14, -0x1

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 161
    move-object v13, v3

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 163
    new-instance v13, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    invoke-direct {v14}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v4, v13

    .line 164
    move-object v13, v4

    const v14, -0x63d850

    invoke-virtual {v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 165
    move-object v13, v4

    const/16 v14, 0xf

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 166
    move-object v13, v3

    move-object v14, v4

    invoke-virtual {v13, v14}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 168
    move-object v13, v3

    new-instance v14, Lgtandroid/universal/MainActivity$100000001;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    move-object/from16 v16, v0

    move-object/from16 v17, v3

    invoke-direct/range {v15 .. v17}, Lgtandroid/universal/MainActivity$100000001;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 182
    move-object v13, v1

    move-object v14, v3

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 184
    new-instance v13, Landroid/view/View;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    move-object v15, v0

    invoke-direct {v14, v15}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v5, v13

    .line 185
    move-object v13, v5

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    const/16 v16, -0x1

    const/16 v17, 0xf

    invoke-direct/range {v15 .. v17}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 187
    move-object v13, v1

    move-object v14, v5

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 189
    new-instance v13, Landroid/widget/Button;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    move-object v15, v0

    invoke-direct {v14, v15}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v6, v13

    .line 190
    move-object v13, v6

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    const-string v15, "\ud83e\udd16 \u0410\u0432\u0442\u043e\u0444\u043e\u0440\u043c\u0430: "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move-object v15, v0

    iget-object v15, v15, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v16, "auto_form_enabled"

    const/16 v17, 0x1

    invoke-interface/range {v15 .. v17}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    if-eqz v15, :cond_1

    const-string v15, "\u0412\u043a\u043b"

    :goto_1
    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 191
    move-object v13, v6

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    const/16 v16, -0x1

    const/16 v17, -0x2

    invoke-direct/range {v15 .. v17}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 194
    move-object v13, v6

    const/16 v14, 0x14

    const/16 v15, 0x19

    const/16 v16, 0x14

    const/16 v17, 0x19

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 195
    move-object v13, v6

    const/16 v14, 0x10

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 196
    move-object v13, v6

    const/4 v14, -0x1

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 197
    move-object v13, v6

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 199
    new-instance v13, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    invoke-direct {v14}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v7, v13

    .line 200
    move-object v13, v7

    const v14, -0xde690d

    invoke-virtual {v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 201
    move-object v13, v7

    const/16 v14, 0xf

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 202
    move-object v13, v6

    move-object v14, v7

    invoke-virtual {v13, v14}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 204
    move-object v13, v6

    new-instance v14, Lgtandroid/universal/MainActivity$100000002;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    move-object/from16 v16, v0

    move-object/from16 v17, v6

    invoke-direct/range {v15 .. v17}, Lgtandroid/universal/MainActivity$100000002;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 218
    move-object v13, v1

    move-object v14, v6

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 220
    new-instance v13, Landroid/view/View;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    move-object v15, v0

    invoke-direct {v14, v15}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v8, v13

    .line 221
    move-object v13, v8

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    const/16 v16, -0x1

    const/16 v17, 0xf

    invoke-direct/range {v15 .. v17}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 223
    move-object v13, v1

    move-object v14, v8

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 225
    new-instance v13, Landroid/widget/Button;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    move-object v15, v0

    invoke-direct {v14, v15}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v9, v13

    .line 226
    move-object v13, v9

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    const-string v15, "\ud83c\udd98 \u041f\u043e\u043c\u043e\u0449\u044c \u0438\u0433\u0440\u043e\u043a\u0443: "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move-object v15, v0

    iget-object v15, v15, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v16, "help_player_enabled"

    const/16 v17, 0x1

    invoke-interface/range {v15 .. v17}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    if-eqz v15, :cond_2

    const-string v15, "\u0412\u043a\u043b"

    :goto_2
    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 227
    move-object v13, v9

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    const/16 v16, -0x1

    const/16 v17, -0x2

    invoke-direct/range {v15 .. v17}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 230
    move-object v13, v9

    const/16 v14, 0x14

    const/16 v15, 0x19

    const/16 v16, 0x14

    const/16 v17, 0x19

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 231
    move-object v13, v9

    const/16 v14, 0x10

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 232
    move-object v13, v9

    const/4 v14, -0x1

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 233
    move-object v13, v9

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 235
    new-instance v13, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    invoke-direct {v14}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v10, v13

    .line 236
    move-object v13, v10

    const v14, -0xff7685

    invoke-virtual {v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 237
    move-object v13, v10

    const/16 v14, 0xf

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 238
    move-object v13, v9

    move-object v14, v10

    invoke-virtual {v13, v14}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 240
    move-object v13, v9

    new-instance v14, Lgtandroid/universal/MainActivity$100000003;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    move-object/from16 v16, v0

    move-object/from16 v17, v9

    invoke-direct/range {v15 .. v17}, Lgtandroid/universal/MainActivity$100000003;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 254
    move-object v13, v1

    move-object v14, v9

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 256
    new-instance v13, Landroid/view/View;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    move-object v15, v0

    invoke-direct {v14, v15}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v11, v13

    .line 257
    move-object v13, v11

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    const/16 v16, -0x1

    const/16 v17, 0xf

    invoke-direct/range {v15 .. v17}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 259
    move-object v13, v1

    move-object v14, v11

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void

    .line 154
    :cond_0
    const-string v15, "\u0412\u044b\u043a\u043b"

    goto/16 :goto_0

    .line 190
    :cond_1
    const-string v15, "\u0412\u044b\u043a\u043b"

    goto/16 :goto_1

    .line 226
    :cond_2
    const-string v15, "\u0412\u044b\u043a\u043b"

    goto/16 :goto_2
.end method

.method private addPrefToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZI)V
    .locals 23
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "ZI)V"
        }
    .end annotation

    .prologue
    .line 129
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    new-instance v11, Landroid/widget/Button;

    move-object/from16 v22, v11

    move-object/from16 v11, v22

    move-object/from16 v12, v22

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v7, v11

    .line 130
    move-object v11, v7

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 131
    move-object v11, v7

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 132
    move-object v11, v7

    const/16 v12, 0xf

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 133
    move-object v11, v7

    const/16 v12, 0x14

    const/16 v13, 0x16

    const/16 v14, 0x14

    const/16 v15, 0x16

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 134
    const/4 v11, 0x1

    new-array v11, v11, [Z

    move-object/from16 v22, v11

    move-object/from16 v11, v22

    move-object/from16 v12, v22

    const/4 v13, 0x0

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v15, v3

    move/from16 v16, v4

    invoke-interface/range {v14 .. v16}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    aput-boolean v14, v12, v13

    move-object v8, v11

    .line 135
    move-object v11, v7

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v22, v12

    move-object/from16 v12, v22

    move-object/from16 v13, v22

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v22, v13

    move-object/from16 v13, v22

    move-object/from16 v14, v22

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    move-object v14, v2

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    const-string v14, ": "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v8

    const/4 v14, 0x0

    aget-boolean v13, v13, v14

    if-eqz v13, :cond_0

    const-string v13, "\u0412\u043a\u043b"

    :goto_0
    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 136
    move-object v11, v7

    move-object v12, v8

    const/4 v13, 0x0

    aget-boolean v12, v12, v13

    if-eqz v12, :cond_1

    move v12, v5

    :goto_1
    invoke-virtual {v11, v12}, Landroid/view/View;->setBackgroundColor(I)V

    .line 137
    move-object v11, v7

    new-instance v12, Lgtandroid/universal/MainActivity$100000000;

    move-object/from16 v22, v12

    move-object/from16 v12, v22

    move-object/from16 v13, v22

    move-object v14, v0

    move-object v15, v8

    move-object/from16 v16, v3

    move-object/from16 v17, v7

    move-object/from16 v18, v2

    move/from16 v19, v5

    invoke-direct/range {v13 .. v19}, Lgtandroid/universal/MainActivity$100000000;-><init>(Lgtandroid/universal/MainActivity;[ZLjava/lang/String;Landroid/widget/Button;Ljava/lang/String;I)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 145
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v22, v11

    move-object/from16 v11, v22

    move-object/from16 v12, v22

    const/4 v13, -0x1

    const/4 v14, -0x2

    invoke-direct {v12, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v9, v11

    .line 147
    move-object v11, v9

    const/4 v12, 0x0

    const/16 v13, 0xf

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 148
    move-object v11, v7

    move-object v12, v9

    invoke-virtual {v11, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 149
    move-object v11, v1

    move-object v12, v7

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void

    .line 135
    :cond_0
    const-string v13, "\u0412\u044b\u043a\u043b"

    goto :goto_0

    .line 136
    :cond_1
    const v12, -0x99999a

    goto :goto_1
.end method

.method private addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1433
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    new-instance v6, Landroid/widget/TextView;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 1434
    move-object v6, v4

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "\u258d "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v2

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1435
    move-object v6, v4

    const/16 v7, 0xe

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1436
    move-object v6, v4

    const v7, 0x3da3d70a    # 0.08f

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 1437
    move-object v6, v4

    const v7, -0x57aa01

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1438
    move-object v6, v4

    const/4 v7, 0x0

    const/16 v8, 0x1a

    const/4 v9, 0x0

    const/16 v10, 0xc

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1439
    move-object v6, v4

    const/4 v7, 0x0

    check-cast v7, Landroid/graphics/Typeface;

    const/4 v8, 0x1

    invoke-virtual {v6, v7, v8}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1440
    move-object v6, v1

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method private addT9Word(Ljava/lang/String;)Z
    .locals 11

    .prologue
    .line 3300
    move-object v0, p0

    move-object v1, p1

    move-object v7, v0

    :try_start_0
    invoke-direct {v7}, Lgtandroid/universal/MainActivity;->getT9WordsArray()Lorg/json/JSONArray;

    move-result-object v7

    move-object v3, v7

    .line 3301
    move-object v7, v1

    invoke-virtual {v7}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 3302
    const/4 v7, 0x0

    move v5, v7

    :goto_0
    move v7, v5

    move-object v8, v3

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-lt v7, v8, :cond_0

    .line 3307
    move-object v7, v3

    move-object v8, v1

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v7

    .line 3308
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "t9_words"

    move-object v9, v3

    invoke-virtual {v9}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3309
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/MainActivity;->notifyT9DictChanged()V

    .line 3310
    const/4 v7, 0x1

    move v0, v7

    .line 3313
    :goto_1
    return v0

    .line 3303
    :cond_0
    move-object v7, v3

    move v8, v5

    const-string v9, ""

    invoke-virtual {v7, v8, v9}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v7

    move-object v8, v4

    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v7

    if-eqz v7, :cond_1

    .line 3304
    const/4 v7, 0x0

    move v0, v7

    goto :goto_1

    .line 3302
    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 3310
    :catch_0
    move-exception v7

    move-object v3, v7

    .line 3312
    move-object v7, v0

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v10, v8

    move-object v8, v10

    move-object v9, v10

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v3

    invoke-virtual {v9}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    .line 3313
    const/4 v7, 0x0

    move v0, v7

    goto :goto_1
.end method

.method private applyNeonGlow(Landroid/widget/TextView;I)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/TextView;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 107
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v1

    move v5, v2

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 108
    move-object v4, v1

    const/high16 v5, 0x41900000    # 18.0f

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v8, v2

    invoke-virtual {v4, v5, v6, v7, v8}, Landroid/widget/TextView;->setShadowLayer(FFFI)V

    return-void
.end method

.method private attachEventTimeFormatter(Landroid/widget/EditText;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/EditText;",
            ")V"
        }
    .end annotation

    .prologue
    .line 967
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    new-instance v4, Lgtandroid/universal/MainActivity$100000016;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    move-object v6, v0

    invoke-direct {v5, v6}, Lgtandroid/universal/MainActivity$100000016;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    return-void
.end method

.method private buildActionCard(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;
    .locals 20

    .prologue
    .line 619
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p4

    move-object/from16 v6, p5

    new-instance v13, Landroid/widget/LinearLayout;

    move-object/from16 v19, v13

    move-object/from16 v13, v19

    move-object/from16 v14, v19

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v13

    .line 620
    move-object v13, v8

    const/4 v14, 0x1

    invoke-virtual {v13, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 621
    move-object v13, v8

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 622
    move-object v13, v8

    move-object v14, v1

    const/16 v15, 0xa

    int-to-float v15, v15

    invoke-direct {v14, v15}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v14

    move-object v15, v1

    const/16 v16, 0x14

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v15

    move-object/from16 v16, v1

    const/16 v17, 0xa

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v16

    move-object/from16 v17, v1

    const/16 v18, 0x14

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v17

    invoke-virtual/range {v13 .. v17}, Landroid/view/View;->setPadding(IIII)V

    .line 623
    move-object v13, v8

    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v19, v14

    move-object/from16 v14, v19

    move-object/from16 v15, v19

    const/16 v16, 0x0

    const/16 v17, -0x2

    const/high16 v18, 0x3f800000    # 1.0f

    invoke-direct/range {v15 .. v18}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v13, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 624
    move-object v13, v8

    const/4 v14, 0x1

    invoke-virtual {v13, v14}, Landroid/view/View;->setClickable(Z)V

    .line 625
    move-object v13, v8

    const/4 v14, 0x1

    invoke-virtual {v13, v14}, Landroid/view/View;->setFocusable(Z)V

    .line 626
    move-object v13, v8

    move-object v14, v1

    move v15, v5

    invoke-direct {v14, v15}, Lgtandroid/universal/MainActivity;->createNeonCardBackground(I)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    invoke-virtual {v13, v14}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 627
    move-object v13, v8

    move-object v14, v6

    invoke-virtual {v13, v14}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 629
    new-instance v13, Landroid/widget/TextView;

    move-object/from16 v19, v13

    move-object/from16 v13, v19

    move-object/from16 v14, v19

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v9, v13

    .line 630
    move-object v13, v9

    move-object v14, v2

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 631
    move-object v13, v9

    const/16 v14, 0x1c

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 632
    move-object v13, v9

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 633
    move-object v13, v8

    move-object v14, v9

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 635
    new-instance v13, Landroid/widget/TextView;

    move-object/from16 v19, v13

    move-object/from16 v13, v19

    move-object/from16 v14, v19

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v10, v13

    .line 636
    move-object v13, v10

    move-object v14, v3

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 637
    move-object v13, v10

    move v14, v5

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 638
    move-object v13, v10

    const/4 v14, 0x0

    check-cast v14, Landroid/graphics/Typeface;

    const/4 v15, 0x1

    invoke-virtual {v13, v14, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 639
    move-object v13, v10

    const/16 v14, 0xe

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 640
    move-object v13, v10

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 641
    move-object v13, v10

    const/4 v14, 0x0

    move-object v15, v1

    const/16 v16, 0x8

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v15

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 642
    move-object v13, v8

    move-object v14, v10

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 644
    new-instance v13, Landroid/widget/TextView;

    move-object/from16 v19, v13

    move-object/from16 v13, v19

    move-object/from16 v14, v19

    move-object v15, v1

    invoke-direct {v14, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v11, v13

    .line 645
    move-object v13, v11

    move-object v14, v4

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 646
    move-object v13, v11

    const v14, -0x655f4c

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextColor(I)V

    .line 647
    move-object v13, v11

    const/16 v14, 0xb

    int-to-float v14, v14

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setTextSize(F)V

    .line 648
    move-object v13, v11

    const/16 v14, 0x11

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setGravity(I)V

    .line 649
    move-object v13, v11

    const/4 v14, 0x0

    move-object v15, v1

    const/16 v16, 0x2

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v15

    const/16 v16, 0x0

    const/16 v17, 0x0

    invoke-virtual/range {v13 .. v17}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 650
    move-object v13, v8

    move-object v14, v11

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 652
    move-object v13, v8

    move-object v1, v13

    return-object v1
.end method

.method private buildBottomNav()Landroid/view/View;
    .locals 13

    .prologue
    .line 331
    move-object v0, p0

    move-object v4, v0

    new-instance v5, Landroid/widget/LinearLayout;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v5, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    .line 332
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 333
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    const v5, -0xedebe3

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 334
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    const/4 v5, 0x0

    move-object v6, v0

    const/16 v7, 0xa

    int-to-float v7, v7

    invoke-direct {v6, v7}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v6

    const/4 v7, 0x0

    move-object v8, v0

    const/16 v9, 0xa

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    invoke-virtual {v4, v5, v6, v7, v8}, Landroid/view/View;->setPadding(IIII)V

    .line 336
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    move-object v12, v4

    move-object v4, v12

    move-object v5, v12

    invoke-direct {v5}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v2, v4

    .line 337
    move-object v4, v2

    const v5, -0xedebe3

    invoke-virtual {v4, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 338
    move-object v4, v2

    move-object v5, v0

    const/4 v6, 0x1

    int-to-float v6, v6

    invoke-direct {v5, v6}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v5

    move-object v6, v0

    const v7, -0xff1a01

    const/16 v8, 0x3c

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->withAlpha(II)I

    move-result v6

    invoke-virtual {v4, v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 339
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    move-object v5, v2

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 341
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    move-object v5, v0

    const-string v6, "\ud83c\udfe0"

    const-string v7, "\u0413\u043b\u0430\u0432\u043d\u0430\u044f"

    const v8, -0xff1a01

    new-instance v9, Lgtandroid/universal/MainActivity$100000004;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000004;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->buildNavItem(Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 345
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    move-object v5, v0

    const-string v6, "\ud83d\udee0"

    const-string v7, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440"

    const v8, -0xd13c

    new-instance v9, Lgtandroid/universal/MainActivity$100000005;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000005;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->buildNavItem(Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 349
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    move-object v5, v0

    const-string v6, "\u2699"

    const-string v7, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    const v8, -0x57aa01

    new-instance v9, Lgtandroid/universal/MainActivity$100000006;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000006;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->buildNavItem(Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 353
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity;->bottomNav:Landroid/widget/LinearLayout;

    move-object v0, v4

    return-object v0
.end method

.method private buildNavItem(Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;
    .locals 17

    .prologue
    .line 357
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p4

    new-instance v10, Landroid/widget/LinearLayout;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v6, v10

    .line 358
    move-object v10, v6

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 359
    move-object v10, v6

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 360
    move-object v10, v6

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    const/4 v13, 0x0

    const/4 v14, -0x2

    const/high16 v15, 0x3f800000    # 1.0f

    invoke-direct {v12, v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 361
    move-object v10, v6

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/view/View;->setClickable(Z)V

    .line 362
    move-object v10, v6

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/view/View;->setFocusable(Z)V

    .line 363
    move-object v10, v6

    move-object v11, v4

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 365
    new-instance v10, Landroid/widget/TextView;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v7, v10

    .line 366
    move-object v10, v7

    move-object v11, v1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 367
    move-object v10, v7

    const/16 v11, 0x14

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 368
    move-object v10, v7

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 369
    move-object v10, v7

    move v11, v3

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 370
    move-object v10, v6

    move-object v11, v7

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 372
    new-instance v10, Landroid/widget/TextView;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v8, v10

    .line 373
    move-object v10, v8

    move-object v11, v2

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 374
    move-object v10, v8

    const/16 v11, 0xb

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 375
    move-object v10, v8

    const v11, -0x655f4c

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 376
    move-object v10, v8

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 377
    move-object v10, v8

    const/4 v11, 0x0

    move-object v12, v0

    const/4 v13, 0x2

    int-to-float v13, v13

    invoke-direct {v12, v13}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v12

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 378
    move-object v10, v6

    move-object v11, v8

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 380
    move-object v10, v6

    move-object v0, v10

    return-object v0
.end method

.method private buildScreenHeaderCard(Ljava/lang/String;Ljava/lang/String;I)Landroid/view/View;
    .locals 17

    .prologue
    .line 1286
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    new-instance v10, Landroid/widget/LinearLayout;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v10

    .line 1287
    move-object v10, v5

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1288
    move-object v10, v5

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1289
    move-object v10, v5

    move-object v11, v0

    const/16 v12, 0x14

    int-to-float v12, v12

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v11

    move-object v12, v0

    const/16 v13, 0x16

    int-to-float v13, v13

    invoke-direct {v12, v13}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v12

    move-object v13, v0

    const/16 v14, 0x14

    int-to-float v14, v14

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v13

    move-object v14, v0

    const/16 v15, 0x16

    int-to-float v15, v15

    invoke-direct {v14, v15}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v14

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/view/View;->setPadding(IIII)V

    .line 1290
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v6, v10

    .line 1292
    move-object v10, v6

    move-object v11, v0

    const/16 v12, 0x10

    int-to-float v12, v12

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v11

    move-object v12, v0

    const/16 v13, 0x10

    int-to-float v13, v13

    invoke-direct {v12, v13}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v12

    move-object v13, v0

    const/16 v14, 0x10

    int-to-float v14, v14

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v13

    move-object v14, v0

    const/16 v15, 0x8

    int-to-float v15, v15

    invoke-direct {v14, v15}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v14

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 1293
    move-object v10, v5

    move-object v11, v6

    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1294
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    invoke-direct {v11}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v7, v10

    .line 1295
    move-object v10, v7

    const v11, -0xedebe3

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1296
    move-object v10, v7

    move-object v11, v0

    const/16 v12, 0x12

    int-to-float v12, v12

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v11

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1297
    move-object v10, v7

    move-object v11, v0

    const/high16 v12, 0x3fc00000    # 1.5f

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v11

    move-object v12, v0

    move v13, v3

    const/16 v14, 0x5a

    invoke-direct {v12, v13, v14}, Lgtandroid/universal/MainActivity;->withAlpha(II)I

    move-result v12

    invoke-virtual {v10, v11, v12}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1298
    move-object v10, v5

    move-object v11, v7

    invoke-virtual {v10, v11}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1300
    new-instance v10, Landroid/widget/TextView;

    move-object/from16 v16, v10

    move-object/from16 v10, v16

    move-object/from16 v11, v16

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v8, v10

    .line 1301
    move-object v10, v8

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    move-object v13, v1

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, "  "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v2

    invoke-virtual {v12}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1302
    move-object v10, v8

    const/16 v11, 0x14

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1303
    move-object v10, v8

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 1304
    move-object v10, v8

    const/4 v11, 0x0

    check-cast v11, Landroid/graphics/Typeface;

    const/4 v12, 0x1

    invoke-virtual {v10, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1305
    move-object v10, v8

    const v11, 0x3ca3d70a    # 0.02f

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 1306
    move-object v10, v0

    move-object v11, v8

    move v12, v3

    invoke-direct {v10, v11, v12}, Lgtandroid/universal/MainActivity;->applyNeonGlow(Landroid/widget/TextView;I)V

    .line 1307
    move-object v10, v5

    move-object v11, v8

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1308
    move-object v10, v5

    move-object v0, v10

    return-object v0
.end method

.method private createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/lang/String;",
            "I",
            "Landroid/view/View$OnClickListener;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1312
    move-object v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p4

    new-instance v9, Landroid/widget/Button;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v6, v9

    .line 1313
    move-object v9, v6

    move-object v10, v2

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1314
    move-object v9, v6

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1317
    move-object v9, v6

    const/16 v10, 0x18

    const/16 v11, 0x18

    const/16 v12, 0x18

    const/16 v13, 0x18

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1318
    move-object v9, v6

    const/16 v10, 0x10

    int-to-float v10, v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1319
    move-object v9, v6

    move v10, v3

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1320
    move-object v9, v6

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1321
    move-object v9, v6

    move-object v10, v0

    move v11, v3

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->createNeonCardBackground(I)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1323
    move-object v9, v6

    move-object v10, v4

    invoke-virtual {v9, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1324
    move-object v9, v1

    move-object v10, v6

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1326
    new-instance v9, Landroid/view/View;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v7, v9

    .line 1327
    move-object v9, v7

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, -0x1

    const/16 v13, 0x12

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1329
    move-object v9, v1

    move-object v10, v7

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method private createNeonCardBackground(I)Landroid/graphics/drawable/Drawable;
    .locals 13

    .prologue
    .line 82
    move-object v0, p0

    move v1, p1

    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v3, v7

    .line 83
    move-object v7, v3

    const v8, -0xedebe3

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 84
    move-object v7, v3

    move-object v8, v0

    const/16 v9, 0x10

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    int-to-float v8, v8

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 85
    move-object v7, v3

    move-object v8, v0

    const/4 v9, 0x2

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    move v9, v1

    invoke-virtual {v7, v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 87
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    invoke-direct {v8}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v4, v7

    .line 88
    move-object v7, v4

    move-object v8, v0

    move v9, v1

    const/16 v10, 0x32

    invoke-direct {v8, v9, v10}, Lgtandroid/universal/MainActivity;->withAlpha(II)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 89
    move-object v7, v4

    move-object v8, v0

    const/16 v9, 0x10

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    int-to-float v8, v8

    invoke-virtual {v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 90
    move-object v7, v4

    move-object v8, v0

    const/4 v9, 0x2

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    move v9, v1

    invoke-virtual {v7, v8, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 92
    new-instance v7, Landroid/graphics/drawable/StateListDrawable;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    invoke-direct {v8}, Landroid/graphics/drawable/StateListDrawable;-><init>()V

    move-object v5, v7

    .line 93
    move-object v7, v5

    const/4 v8, 0x1

    new-array v8, v8, [I

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    const/4 v10, 0x0

    const v11, 0x10100a7

    aput v11, v9, v10

    move-object v9, v4

    invoke-virtual {v7, v8, v9}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 94
    move-object v7, v5

    const/4 v8, 0x0

    new-array v8, v8, [I

    move-object v9, v3

    invoke-virtual {v7, v8, v9}, Landroid/graphics/drawable/StateListDrawable;->addState([ILandroid/graphics/drawable/Drawable;)V

    .line 95
    move-object v7, v5

    move-object v0, v7

    return-object v0
.end method

.method private createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Ljava/lang/String;",
            "I",
            "Landroid/view/View$OnClickListener;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1444
    move-object v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p4

    new-instance v9, Landroid/widget/Button;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v6, v9

    .line 1445
    move-object v9, v6

    move-object v10, v2

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1446
    move-object v9, v6

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1449
    move-object v9, v6

    const/16 v10, 0x16

    const/16 v11, 0x12

    const/16 v12, 0x16

    const/16 v13, 0x12

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1450
    move-object v9, v6

    const/16 v10, 0x10

    int-to-float v10, v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1451
    move-object v9, v6

    move v10, v3

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1452
    move-object v9, v6

    const/4 v10, 0x0

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1453
    move-object v9, v6

    move-object v10, v0

    move v11, v3

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->createNeonCardBackground(I)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1455
    move-object v9, v6

    move-object v10, v4

    invoke-virtual {v9, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1456
    move-object v9, v1

    move-object v10, v6

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1458
    new-instance v9, Landroid/view/View;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v7, v9

    .line 1459
    move-object v9, v7

    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    const/4 v12, -0x1

    const/16 v13, 0xe

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v9, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1461
    move-object v9, v1

    move-object v10, v7

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method private deleteFamWarCommand(I)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 3082
    move-object v0, p0

    move v1, p1

    :try_start_0
    new-instance v5, Lorg/json/JSONArray;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v8, "famwar_commands"

    const-string v9, "[]"

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 3083
    move-object v5, v3

    move v6, v1

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->remove(I)Ljava/lang/Object;

    move-result-object v5

    .line 3084
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v6, "famwar_commands"

    move-object v7, v3

    invoke-virtual {v7}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3085
    move-object v5, v0

    const-string v6, "\u2705 \u0423\u0434\u0430\u043b\u0435\u043d\u043e!"

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 3087
    :goto_0
    return-void

    .line 3085
    :catch_0
    move-exception v5

    move-object v3, v5

    .line 3087
    move-object v5, v0

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private deleteNormalButton(I)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 2682
    move-object v0, p0

    move/from16 v1, p1

    move-object v9, v0

    const-string v10, "btn_count"

    const/4 v11, 0x0

    invoke-direct {v9, v10, v11}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v9

    move v3, v9

    .line 2683
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    move-object v4, v9

    .line 2685
    move v9, v1

    move v5, v9

    :goto_0
    move v9, v5

    move v10, v3

    const/4 v11, 0x1

    add-int/lit8 v10, v10, -0x1

    if-lt v9, v10, :cond_0

    .line 2692
    move-object v9, v4

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "btn_"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move v12, v3

    const/4 v13, 0x1

    add-int/lit8 v12, v12, -0x1

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "_name"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v9, v10}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    .line 2693
    move-object v9, v4

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "btn_"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move v12, v3

    const/4 v13, 0x1

    add-int/lit8 v12, v12, -0x1

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "_text"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v9, v10}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    .line 2694
    move-object v9, v4

    const-string v10, "btn_count"

    move v11, v3

    const/4 v12, 0x1

    add-int/lit8 v11, v11, -0x1

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    .line 2695
    move-object v9, v4

    invoke-interface {v9}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 2697
    move-object v9, v0

    const-string v10, "\u2705 \u0423\u0434\u0430\u043b\u0435\u043d\u043e!"

    const/4 v11, 0x0

    invoke-static {v9, v10, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/Toast;->show()V

    return-void

    .line 2686
    :cond_0
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "btn_"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move v12, v5

    const/4 v13, 0x1

    add-int/lit8 v12, v12, 0x1

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "_name"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    const-string v11, ""

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v6, v9

    .line 2687
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "btn_"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move v12, v5

    const/4 v13, 0x1

    add-int/lit8 v12, v12, 0x1

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "_text"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    const-string v11, ""

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    move-object v7, v9

    .line 2688
    move-object v9, v4

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "btn_"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move v12, v5

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "_name"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    move-object v11, v6

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    .line 2689
    move-object v9, v4

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "btn_"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move v12, v5

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "_text"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    move-object v11, v7

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    .line 2685
    add-int/lit8 v5, v5, 0x1

    goto/16 :goto_0
.end method

.method private deletePunishment(Ljava/lang/String;I)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 2278
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    :try_start_0
    new-instance v7, Ljava/lang/StringBuffer;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "punishment_"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v1

    invoke-virtual {v8}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 2279
    new-instance v7, Lorg/json/JSONArray;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v10, v4

    const-string v11, "[]"

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v5, v7

    .line 2280
    move-object v7, v5

    move v8, v2

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->remove(I)Ljava/lang/Object;

    move-result-object v7

    .line 2281
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    move-object v8, v4

    move-object v9, v5

    invoke-virtual {v9}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 2282
    move-object v7, v0

    const-string v8, "\u2705 \u0423\u0434\u0430\u043b\u0435\u043d\u043e!"

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2284
    :goto_0
    return-void

    .line 2282
    :catch_0
    move-exception v7

    move-object v4, v7

    .line 2284
    move-object v7, v0

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v4

    invoke-virtual {v9}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private deleteQuickAnswer(I)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 2534
    move-object v0, p0

    move v1, p1

    :try_start_0
    new-instance v5, Lorg/json/JSONArray;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v8, "quick_answers"

    const-string v9, "[]"

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-direct {v6, v7}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 2535
    move-object v5, v3

    move v6, v1

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->remove(I)Ljava/lang/Object;

    move-result-object v5

    .line 2536
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v6, "quick_answers"

    move-object v7, v3

    invoke-virtual {v7}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 2537
    move-object v5, v0

    const-string v6, "\u2705 \u0423\u0434\u0430\u043b\u0435\u043d\u043e!"

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2539
    :goto_0
    return-void

    .line 2537
    :catch_0
    move-exception v5

    move-object v3, v5

    .line 2539
    move-object v5, v0

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private deleteT9Word(I)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 3383
    move-object v0, p0

    move v1, p1

    move-object v5, v0

    :try_start_0
    invoke-direct {v5}, Lgtandroid/universal/MainActivity;->getT9WordsArray()Lorg/json/JSONArray;

    move-result-object v5

    move-object v3, v5

    .line 3384
    move-object v5, v3

    move v6, v1

    invoke-virtual {v5, v6}, Lorg/json/JSONArray;->remove(I)Ljava/lang/Object;

    move-result-object v5

    .line 3385
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string v6, "t9_words"

    move-object v7, v3

    invoke-virtual {v7}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3386
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/MainActivity;->notifyT9DictChanged()V

    .line 3387
    move-object v5, v0

    const-string v6, "\u2705 \u0423\u0434\u0430\u043b\u0435\u043d\u043e!"

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 3389
    :goto_0
    return-void

    .line 3387
    :catch_0
    move-exception v5

    move-object v3, v5

    .line 3389
    move-object v5, v0

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private displayAds(Lorg/json/JSONArray;)V
    .locals 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")V"
        }
    .end annotation

    .prologue
    .line 678
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    const/16 v18, 0x0

    check-cast v18, Landroid/widget/HorizontalScrollView;

    move-object/from16 v5, v18

    .line 679
    move-object/from16 v18, v2

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v18, v0

    invoke-virtual/range {v18 .. v18}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v18

    const/16 v19, 0x1

    add-int/lit8 v18, v18, -0x1

    move/from16 v6, v18

    :goto_0
    move/from16 v18, v6

    const/16 v19, 0x0

    move/from16 v0, v18

    move/from16 v1, v19

    if-ge v0, v1, :cond_0

    .line 687
    :goto_1
    move-object/from16 v18, v5

    if-nez v18, :cond_2

    .line 703
    :goto_2
    return-void

    .line 680
    :cond_0
    move-object/from16 v18, v2

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v18, v0

    move/from16 v19, v6

    invoke-virtual/range {v18 .. v19}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v18

    move-object/from16 v7, v18

    .line 681
    move-object/from16 v18, v7

    move-object/from16 v0, v18

    instance-of v0, v0, Landroid/widget/HorizontalScrollView;

    move/from16 v18, v0

    if-eqz v18, :cond_1

    .line 682
    move-object/from16 v18, v7

    check-cast v18, Landroid/widget/HorizontalScrollView;

    move-object/from16 v5, v18

    .line 683
    goto :goto_1

    .line 679
    :cond_1
    add-int/lit8 v6, v6, -0x1

    goto :goto_0

    .line 689
    :cond_2
    move-object/from16 v18, v5

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v18

    check-cast v18, Landroid/widget/LinearLayout;

    move-object/from16 v6, v18

    .line 690
    move-object/from16 v18, v6

    invoke-virtual/range {v18 .. v18}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 692
    move-object/from16 v18, v3

    invoke-virtual/range {v18 .. v18}, Lorg/json/JSONArray;->length()I

    move-result v18

    const/16 v19, 0x0

    move/from16 v0, v18

    move/from16 v1, v19

    if-ne v0, v1, :cond_3

    .line 693
    new-instance v18, Landroid/widget/TextView;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    move-object/from16 v20, v2

    invoke-direct/range {v19 .. v20}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v7, v18

    .line 694
    move-object/from16 v18, v7

    const-string v19, "\u041d\u0435\u0442 \u043d\u043e\u0432\u043e\u0441\u0442\u0435\u0439"

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 695
    move-object/from16 v18, v7

    const v19, -0x655f4c

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setTextColor(I)V

    .line 696
    move-object/from16 v18, v7

    const/16 v19, 0x32

    const/16 v20, 0x96

    const/16 v21, 0x32

    const/16 v22, 0x96

    invoke-virtual/range {v18 .. v22}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 697
    move-object/from16 v18, v6

    move-object/from16 v19, v7

    invoke-virtual/range {v18 .. v19}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 698
    goto :goto_2

    .line 701
    :cond_3
    const/16 v18, 0xc8

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move-object/from16 v19, v2

    invoke-virtual/range {v19 .. v19}, Landroid/view/ContextThemeWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v19

    move-object/from16 v0, v19

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    move/from16 v19, v0

    mul-float v18, v18, v19

    move/from16 v0, v18

    float-to-int v0, v0

    move/from16 v18, v0

    move/from16 v7, v18

    .line 703
    const/16 v18, 0x0

    move/from16 v8, v18

    :goto_3
    move/from16 v18, v8

    move-object/from16 v19, v3

    invoke-virtual/range {v19 .. v19}, Lorg/json/JSONArray;->length()I

    move-result v19

    move/from16 v0, v18

    move/from16 v1, v19

    if-lt v0, v1, :cond_4

    goto/16 :goto_2

    .line 705
    :cond_4
    move-object/from16 v18, v3

    move/from16 v19, v8

    :try_start_0
    invoke-virtual/range {v18 .. v19}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v18

    move-object/from16 v9, v18

    .line 706
    move-object/from16 v18, v9

    const-string v19, "link"

    const-string v20, ""

    invoke-virtual/range {v18 .. v20}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    move-object/from16 v10, v18

    .line 707
    move-object/from16 v18, v9

    const-string v19, "image"

    const-string v20, ""

    invoke-virtual/range {v18 .. v20}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    move-object/from16 v11, v18

    .line 708
    move-object/from16 v18, v9

    const-string v19, "text"

    const-string v20, "\u041d\u043e\u0432\u043e\u0441\u0442\u0438"

    invoke-virtual/range {v18 .. v20}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    move-object/from16 v12, v18

    .line 710
    new-instance v18, Landroid/widget/LinearLayout;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    move-object/from16 v20, v2

    invoke-direct/range {v19 .. v20}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v18

    .line 711
    move-object/from16 v18, v13

    const/16 v19, 0x1

    invoke-virtual/range {v18 .. v19}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 712
    move-object/from16 v18, v13

    new-instance v19, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v19

    move-object/from16 v19, v23

    move-object/from16 v20, v23

    move/from16 v21, v7

    const/16 v22, -0x1

    invoke-direct/range {v20 .. v22}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v18 .. v19}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 716
    move-object/from16 v18, v13

    const/16 v19, 0x5

    const/16 v20, 0x5

    const/16 v21, 0x5

    const/16 v22, 0x5

    invoke-virtual/range {v18 .. v22}, Landroid/view/View;->setPadding(IIII)V

    .line 718
    new-instance v18, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    invoke-direct/range {v19 .. v19}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v14, v18

    .line 719
    move-object/from16 v18, v14

    const v19, -0xedebe3

    invoke-virtual/range {v18 .. v19}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 720
    move-object/from16 v18, v14

    const/16 v19, 0xe

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    invoke-virtual/range {v18 .. v19}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 721
    move-object/from16 v18, v14

    move-object/from16 v19, v2

    const/high16 v20, 0x3fc00000    # 1.5f

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v19

    move-object/from16 v20, v2

    const v21, -0x57aa01

    const/16 v22, 0xa0

    invoke-direct/range {v20 .. v22}, Lgtandroid/universal/MainActivity;->withAlpha(II)I

    move-result v20

    invoke-virtual/range {v18 .. v20}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 722
    move-object/from16 v18, v13

    move-object/from16 v19, v14

    invoke-virtual/range {v18 .. v19}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 723
    move-object/from16 v18, v13

    const/16 v19, 0x1

    invoke-virtual/range {v18 .. v19}, Landroid/view/View;->setClickable(Z)V

    .line 724
    move-object/from16 v18, v10

    invoke-virtual/range {v18 .. v18}, Ljava/lang/String;->isEmpty()Z

    move-result v18

    if-nez v18, :cond_5

    .line 725
    move-object/from16 v18, v13

    new-instance v19, Lgtandroid/universal/MainActivity$100000013;

    move-object/from16 v23, v19

    move-object/from16 v19, v23

    move-object/from16 v20, v23

    move-object/from16 v21, v2

    move-object/from16 v22, v10

    invoke-direct/range {v20 .. v22}, Lgtandroid/universal/MainActivity$100000013;-><init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V

    invoke-virtual/range {v18 .. v19}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 738
    :cond_5
    move-object/from16 v18, v11

    invoke-virtual/range {v18 .. v18}, Ljava/lang/String;->isEmpty()Z

    move-result v18

    if-nez v18, :cond_6

    .line 739
    new-instance v18, Landroid/widget/ImageView;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    move-object/from16 v20, v2

    invoke-direct/range {v19 .. v20}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v18

    .line 740
    move-object/from16 v18, v15

    new-instance v19, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v19

    move-object/from16 v19, v23

    move-object/from16 v20, v23

    const/16 v21, -0x1

    const/16 v22, 0xfa

    invoke-direct/range {v20 .. v22}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v18 .. v19}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 744
    move-object/from16 v18, v15

    sget-object v19, Landroid/widget/ImageView$ScaleType;->FIT_XY:Landroid/widget/ImageView$ScaleType;

    invoke-virtual/range {v18 .. v19}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 745
    move-object/from16 v18, v15

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Landroid/widget/ImageView;->setAdjustViewBounds(Z)V

    .line 746
    move-object/from16 v18, v2

    move-object/from16 v19, v11

    move-object/from16 v20, v15

    invoke-direct/range {v18 .. v20}, Lgtandroid/universal/MainActivity;->loadImageAsync(Ljava/lang/String;Landroid/widget/ImageView;)V

    .line 747
    move-object/from16 v18, v13

    move-object/from16 v19, v15

    invoke-virtual/range {v18 .. v19}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 750
    :cond_6
    new-instance v18, Landroid/widget/TextView;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    move-object/from16 v20, v2

    invoke-direct/range {v19 .. v20}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v18

    .line 751
    move-object/from16 v18, v15

    move-object/from16 v19, v12

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 752
    move-object/from16 v18, v15

    const/16 v19, 0xc

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setTextSize(F)V

    .line 753
    move-object/from16 v18, v15

    const v19, -0x17160e

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setTextColor(I)V

    .line 754
    move-object/from16 v18, v15

    const/16 v19, 0x11

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setGravity(I)V

    .line 755
    move-object/from16 v18, v15

    const/16 v19, 0x8

    const/16 v20, 0xa

    const/16 v21, 0x8

    const/16 v22, 0xa

    invoke-virtual/range {v18 .. v22}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 756
    move-object/from16 v18, v15

    const/16 v19, 0x2

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setMaxLines(I)V

    .line 757
    move-object/from16 v18, v15

    sget-object v19, Landroid/text/TextUtils$TruncateAt;->END:Landroid/text/TextUtils$TruncateAt;

    invoke-virtual/range {v18 .. v19}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    .line 758
    move-object/from16 v18, v13

    move-object/from16 v19, v15

    invoke-virtual/range {v18 .. v19}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 760
    move-object/from16 v18, v6

    move-object/from16 v19, v13

    invoke-virtual/range {v18 .. v19}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 762
    move/from16 v18, v8

    move-object/from16 v19, v3

    invoke-virtual/range {v19 .. v19}, Lorg/json/JSONArray;->length()I

    move-result v19

    const/16 v20, 0x1

    add-int/lit8 v19, v19, -0x1

    move/from16 v0, v18

    move/from16 v1, v19

    if-ge v0, v1, :cond_7

    .line 763
    new-instance v18, Landroid/view/View;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    move-object/from16 v20, v2

    invoke-direct/range {v19 .. v20}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v16, v18

    .line 764
    move-object/from16 v18, v16

    new-instance v19, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v19

    move-object/from16 v19, v23

    move-object/from16 v20, v23

    const/16 v21, 0x8

    const/16 v22, -0x1

    invoke-direct/range {v20 .. v22}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v18 .. v19}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 765
    move-object/from16 v18, v6

    move-object/from16 v19, v16

    invoke-virtual/range {v18 .. v19}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 703
    :cond_7
    :goto_4
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_3

    .line 765
    :catch_0
    move-exception v18

    move-object/from16 v9, v18

    .line 768
    move-object/from16 v18, v9

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_4
.end method

.method private downloadString(Ljava/lang/String;)Ljava/lang/String;
    .locals 15
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .prologue
    .line 795
    move-object v0, p0

    move-object/from16 v1, p1

    new-instance v9, Ljava/net/URL;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v1

    invoke-direct {v10, v11}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    move-object v3, v9

    .line 796
    move-object v9, v3

    invoke-virtual {v9}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v9

    check-cast v9, Ljava/net/HttpURLConnection;

    move-object v4, v9

    .line 797
    move-object v9, v4

    const/16 v10, 0x1388

    invoke-virtual {v9, v10}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 798
    move-object v9, v4

    const/16 v10, 0x1388

    invoke-virtual {v9, v10}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 799
    move-object v9, v4

    const-string v10, "GET"

    invoke-virtual {v9, v10}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 800
    new-instance v9, Ljava/io/BufferedReader;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    new-instance v11, Ljava/io/InputStreamReader;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    move-object v13, v4

    invoke-virtual {v13}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v13

    invoke-direct {v12, v13}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v10, v11}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    move-object v5, v9

    .line 801
    new-instance v9, Ljava/lang/StringBuilder;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move-object v6, v9

    .line 803
    :goto_0
    move-object v9, v5

    invoke-virtual {v9}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v9

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v7, v10

    if-nez v9, :cond_0

    .line 806
    move-object v9, v5

    invoke-virtual {v9}, Ljava/io/BufferedReader;->close()V

    .line 807
    move-object v9, v6

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    move-object v0, v9

    return-object v0

    .line 804
    :cond_0
    move-object v9, v6

    move-object v10, v7

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "\n"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    goto :goto_0
.end method

.method private dp(F)I
    .locals 5

    .prologue
    .line 103
    move-object v0, p0

    move v1, p1

    move v3, v1

    move-object v4, v0

    invoke-virtual {v4}, Landroid/view/ContextThemeWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v3, v4

    float-to-int v3, v3

    move v0, v3

    return v0
.end method

.method private exportConfig()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2786
    move-object v0, p0

    new-instance v4, Landroid/content/Intent;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "android.intent.action.CREATE_DOCUMENT"

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v2, v4

    .line 2787
    move-object v4, v2

    const-string v5, "android.intent.category.OPENABLE"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 2788
    move-object v4, v2

    const-string v5, "*/*"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 2789
    move-object v4, v2

    const-string v5, "android.intent.extra.TITLE"

    const-string v6, "GTAndroid_config.cfg"

    invoke-virtual {v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 2790
    move-object v4, v0

    move-object v5, v2

    const/16 v6, 0x378

    invoke-virtual {v4, v5, v6}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private exportLogToFile(Landroid/net/Uri;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 3481
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    :try_start_0
    invoke-virtual {v5}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v5

    move-object v6, v1

    invoke-virtual {v5, v6}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v5

    move-object v3, v5

    .line 3482
    move-object v5, v3

    move-object v6, v0

    invoke-static {v6}, Lgtandroid/universal/AppLogger;->readAll(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->getBytes()[B

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/io/OutputStream;->write([B)V

    .line 3483
    move-object v5, v3

    invoke-virtual {v5}, Ljava/io/OutputStream;->close()V

    .line 3484
    move-object v5, v0

    const-string v6, "\u2705 \u041b\u043e\u0433 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    const/4 v7, 0x1

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 3486
    :goto_0
    return-void

    .line 3484
    :catch_0
    move-exception v5

    move-object v3, v5

    .line 3486
    move-object v5, v0

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x0

    invoke-static {v5, v6, v7}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v5

    invoke-virtual {v5}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private exportNavigatorToFile(Landroid/net/Uri;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1906
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    :try_start_0
    invoke-virtual {v6}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    move-object v7, v1

    invoke-virtual {v6, v7}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v6

    move-object v3, v6

    .line 1907
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-static {v6}, Lgtandroid/universal/NavData;->loadNavigator(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v6

    invoke-static {v6}, Lgtandroid/universal/NavData;->toCfg(Ljava/util/List;)Ljava/lang/String;

    move-result-object v6

    move-object v4, v6

    .line 1908
    move-object v6, v3

    move-object v7, v4

    const-string v8, "UTF-8"

    invoke-static {v8}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/io/OutputStream;->write([B)V

    .line 1909
    move-object v6, v3

    invoke-virtual {v6}, Ljava/io/OutputStream;->close()V

    .line 1910
    move-object v6, v0

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "\u2705 \u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, "navigator.cfg"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x1

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1912
    :goto_0
    return-void

    .line 1910
    :catch_0
    move-exception v6

    move-object v3, v6

    .line 1912
    move-object v6, v0

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v3

    invoke-virtual {v8}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private exportT9Dictionary()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 3401
    move-object v0, p0

    new-instance v4, Landroid/content/Intent;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "android.intent.action.CREATE_DOCUMENT"

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v2, v4

    .line 3402
    move-object v4, v2

    const-string v5, "android.intent.category.OPENABLE"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 3403
    move-object v4, v2

    const-string v5, "*/*"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 3404
    move-object v4, v2

    const-string v5, "android.intent.extra.TITLE"

    const-string v6, "t9_words.cfg"

    invoke-virtual {v4, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 3405
    move-object v4, v0

    move-object v5, v2

    const/16 v6, 0x371

    invoke-virtual {v4, v5, v6}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private exportT9ToFile(Landroid/net/Uri;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 3492
    move-object v0, p0

    move-object v1, p1

    move-object v8, v0

    :try_start_0
    invoke-virtual {v8}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v8

    move-object v9, v1

    invoke-virtual {v8, v9}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v8

    move-object v3, v8

    .line 3493
    move-object v8, v0

    invoke-direct {v8}, Lgtandroid/universal/MainActivity;->getT9WordsArray()Lorg/json/JSONArray;

    move-result-object v8

    move-object v4, v8

    .line 3494
    new-instance v8, Ljava/lang/StringBuilder;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    move-object v5, v8

    .line 3495
    const/4 v8, 0x0

    move v6, v8

    :goto_0
    move v8, v6

    move-object v9, v4

    invoke-virtual {v9}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-lt v8, v9, :cond_0

    .line 3498
    move-object v8, v3

    move-object v9, v5

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/String;->getBytes()[B

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/io/OutputStream;->write([B)V

    .line 3499
    move-object v8, v3

    invoke-virtual {v8}, Ljava/io/OutputStream;->close()V

    .line 3500
    move-object v8, v0

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\u2705 \u042d\u043a\u0441\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043e \u0441\u043b\u043e\u0432: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v4

    invoke-virtual {v10}, Lorg/json/JSONArray;->length()I

    move-result v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x1

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 3502
    :goto_1
    return-void

    .line 3496
    :cond_0
    move-object v8, v5

    move-object v9, v4

    move v10, v6

    const-string v11, ""

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, "\n"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v8

    .line 3495
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 3500
    :catch_0
    move-exception v8

    move-object v3, v8

    .line 3502
    move-object v8, v0

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v3

    invoke-virtual {v10}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    goto :goto_1
.end method

.method private exportToFile(Landroid/net/Uri;)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 3146
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v12, v0

    :try_start_0
    invoke-virtual {v12}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v12

    move-object v13, v1

    invoke-virtual {v12, v13}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v12

    move-object v3, v12

    .line 3147
    new-instance v12, Ljava/lang/StringBuilder;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const-string v14, "# GTAndroid Config\n\n"

    invoke-direct {v13, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object v4, v12

    .line 3149
    move-object v12, v4

    const-string v13, "admin_level="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    const-string v14, "admin_level"

    const/4 v15, 0x1

    invoke-direct {v13, v14, v15}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3150
    move-object v12, v4

    const-string v13, "btn_count="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    const-string v14, "btn_count"

    const/4 v15, 0x0

    invoke-direct {v13, v14, v15}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3152
    move-object v12, v0

    const-string v13, "btn_count"

    const/4 v14, 0x0

    invoke-direct {v12, v13, v14}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v12

    move v5, v12

    .line 3153
    const/4 v12, 0x0

    move v6, v12

    :goto_0
    move v12, v6

    move v13, v5

    if-lt v12, v13, :cond_0

    .line 3159
    move-object v12, v4

    const-string v13, "quick_answers="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v14, "quick_answers"

    const-string v15, "[]"

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3160
    move-object v12, v4

    const-string v13, "famwar_commands="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v14, "famwar_commands"

    const-string v15, "[]"

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3162
    const/16 v12, 0xb

    new-array v12, v12, [Ljava/lang/String;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x0

    const-string v15, "\u043a\u0438\u043a"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x1

    const-string v15, "\u0431\u0430\u043d"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x2

    const-string v15, "\u0432\u0430\u0440\u043d"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x3

    const-string v15, "\u0434\u0436\u0430\u0438\u043b"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x4

    const-string v15, "\u043c\u0443\u0442"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x5

    const-string v15, "un\u0431\u0430\u043d"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x6

    const-string v15, "un\u0432\u0430\u0440\u043d"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/4 v14, 0x7

    const-string v15, "un\u0434\u0436\u0430\u0438\u043b"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/16 v14, 0x8

    const-string v15, "un\u043c\u0443\u0442"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/16 v14, 0x9

    const-string v15, "\u0440\u043c\u0443\u0442"

    aput-object v15, v13, v14

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    const/16 v14, 0xa

    const-string v15, "un\u0440\u043c\u0443\u0442"

    aput-object v15, v13, v14

    move-object v6, v12

    .line 3163
    move-object v12, v6

    move-object v7, v12

    const/4 v12, 0x0

    move v8, v12

    .line 3165
    :goto_1
    move v12, v8

    move-object v13, v7

    array-length v13, v13

    if-lt v12, v13, :cond_1

    .line 3168
    move-object v12, v4

    const-string v13, "keyboard_size="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    const-string v14, "keyboard_size"

    const/4 v15, 0x1

    invoke-direct {v13, v14, v15}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3169
    move-object v12, v4

    const-string v13, "keyboard_transparency="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    const-string v14, "keyboard_transparency"

    const/16 v15, 0x64

    invoke-direct {v13, v14, v15}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3171
    move-object v12, v3

    move-object v13, v4

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/String;->getBytes()[B

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/io/OutputStream;->write([B)V

    .line 3172
    move-object v12, v3

    invoke-virtual {v12}, Ljava/io/OutputStream;->close()V

    .line 3173
    move-object v12, v0

    const-string v13, "\u2705 \u042d\u043a\u0441\u043f\u043e\u0440\u0442 \u0443\u0441\u043f\u0435\u0448\u0435\u043d!"

    const/4 v14, 0x1

    invoke-static {v12, v13, v14}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v12

    invoke-virtual {v12}, Landroid/widget/Toast;->show()V

    .line 3175
    :goto_2
    return-void

    .line 3154
    :cond_0
    move-object v12, v4

    const-string v13, "btn_"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move v13, v6

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "_name="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v17, v14

    move-object/from16 v14, v17

    move-object/from16 v15, v17

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v17, v15

    move-object/from16 v15, v17

    move-object/from16 v16, v17

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    const-string v16, "btn_"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move/from16 v16, v6

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    const-string v15, "_name"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    const-string v15, ""

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3155
    move-object v12, v4

    const-string v13, "btn_"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move v13, v6

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "_text="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v17, v14

    move-object/from16 v14, v17

    move-object/from16 v15, v17

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v17, v15

    move-object/from16 v15, v17

    move-object/from16 v16, v17

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    const-string v16, "btn_"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move/from16 v16, v6

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    const-string v15, "_text"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    const-string v15, ""

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 3153
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_0

    .line 3163
    :cond_1
    move-object v12, v7

    move v13, v8

    aget-object v12, v12, v13

    move-object v9, v12

    .line 3164
    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "punishment_"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v9

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    move-object v10, v12

    .line 3165
    move-object v12, v4

    move-object v13, v10

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "="

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v14, v10

    const-string v15, "[]"

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v12

    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_1

    .line 3173
    :catch_0
    move-exception v12

    move-object v3, v12

    .line 3175
    move-object v12, v0

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    const-string v14, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v3

    invoke-virtual {v14}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x0

    invoke-static {v12, v13, v14}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v12

    invoke-virtual {v12}, Landroid/widget/Toast;->show()V

    goto/16 :goto_2
.end method

.method private exportTriggersToFile(Landroid/net/Uri;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1740
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    :try_start_0
    invoke-virtual {v6}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    move-object v7, v1

    invoke-virtual {v6, v7}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object v6

    move-object v3, v6

    .line 1741
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-static {v6}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v6

    move-object v4, v6

    .line 1742
    move-object v6, v3

    move-object v7, v4

    invoke-static {v7}, Lgtandroid/universal/TriggerData;->toJson(Ljava/util/List;)Ljava/lang/String;

    move-result-object v7

    const-string v8, "UTF-8"

    invoke-static {v8}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/io/OutputStream;->write([B)V

    .line 1743
    move-object v6, v3

    invoke-virtual {v6}, Ljava/io/OutputStream;->close()V

    .line 1744
    move-object v6, v0

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "\u2705 \u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e \u0442\u0440\u0438\u0433\u0433\u0435\u0440\u043e\u0432: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v4

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x1

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 1746
    :goto_0
    return-void

    .line 1744
    :catch_0
    move-exception v6

    move-object v3, v6

    .line 1746
    move-object v6, v0

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v3

    invoke-virtual {v8}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private getIntPref(Ljava/lang/String;I)I
    .locals 10

    .prologue
    .line 1466
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v7, v0

    :try_start_0
    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v8, v1

    invoke-interface {v7, v8}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    move-result v7

    if-eqz v7, :cond_0

    .line 1468
    move-object v7, v0

    :try_start_1
    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v8, v1

    move v9, v2

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I
    :try_end_1
    .catch Ljava/lang/ClassCastException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    move-result v7

    move v0, v7

    .line 1477
    :goto_0
    return v0

    .line 1468
    :catch_0
    move-exception v7

    move-object v4, v7

    .line 1470
    move-object v7, v0

    :try_start_2
    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v8, v1

    move v9, v2

    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object v5, v7

    .line 1471
    move-object v7, v5

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    move-result v7

    move v0, v7

    goto :goto_0

    .line 1477
    :cond_0
    :goto_1
    move v7, v2

    move v0, v7

    goto :goto_0

    .line 1471
    :catch_1
    move-exception v7

    move-object v4, v7

    .line 1475
    move-object v7, v4

    invoke-virtual {v7}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1
.end method

.method private getT9WordsArray()Lorg/json/JSONArray;
    .locals 10

    .prologue
    .line 3185
    move-object v0, p0

    :try_start_0
    new-instance v4, Lorg/json/JSONArray;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v7, "t9_words"

    const-string v8, "[]"

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v4

    .line 3187
    :goto_0
    return-object v0

    .line 3185
    :catch_0
    move-exception v4

    move-object v2, v4

    .line 3187
    new-instance v4, Lorg/json/JSONArray;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    invoke-direct {v5}, Lorg/json/JSONArray;-><init>()V

    move-object v0, v4

    goto :goto_0
.end method

.method private importConfig()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2794
    move-object v0, p0

    new-instance v4, Landroid/content/Intent;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v2, v4

    .line 2795
    move-object v4, v2

    const-string v5, "android.intent.category.OPENABLE"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 2796
    move-object v4, v2

    const-string v5, "*/*"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 2797
    move-object v4, v0

    move-object v5, v2

    const/16 v6, 0x309

    invoke-virtual {v4, v5, v6}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private importFromFile(Landroid/net/Uri;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 3093
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v11, v0

    :try_start_0
    invoke-virtual {v11}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v11

    move-object v12, v1

    invoke-virtual {v11, v12}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v11

    move-object v3, v11

    .line 3094
    new-instance v11, Ljava/io/BufferedReader;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    new-instance v13, Ljava/io/InputStreamReader;

    move-object/from16 v16, v13

    move-object/from16 v13, v16

    move-object/from16 v14, v16

    move-object v15, v3

    invoke-direct {v14, v15}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v12, v13}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    move-object v4, v11

    .line 3095
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    move-object v6, v11

    .line 3098
    move-object v11, v6

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    .line 3100
    :cond_0
    :goto_0
    move-object v11, v4

    invoke-virtual {v11}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v11

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v5, v12

    if-nez v11, :cond_1

    .line 3109
    move-object v11, v4

    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V

    .line 3110
    move-object v11, v6

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_4

    .line 3113
    move-object v11, v0

    :try_start_1
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "admin_level"

    const-string v13, "1"

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 3114
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "admin_level"

    move-object v13, v7

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 3116
    :goto_1
    move-object v11, v0

    :try_start_2
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "admin_level"

    invoke-interface {v11, v12}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_4

    .line 3119
    move-object v11, v0

    :try_start_3
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "btn_count"

    const-string v13, "0"

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 3120
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "btn_count"

    move-object v13, v7

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 3122
    :goto_2
    move-object v11, v0

    :try_start_4
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "btn_count"

    invoke-interface {v11, v12}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 3125
    move-object v11, v0

    :try_start_5
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "keyboard_size"

    const-string v13, "1"

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 3126
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "keyboard_size"

    move-object v13, v7

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    .line 3128
    :goto_3
    move-object v11, v0

    :try_start_6
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "keyboard_size"

    invoke-interface {v11, v12}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_4

    .line 3131
    move-object v11, v0

    :try_start_7
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "keyboard_transparency"

    const-string v13, "100"

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 3132
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "keyboard_transparency"

    move-object v13, v7

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3

    .line 3134
    :goto_4
    move-object v11, v0

    :try_start_8
    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "keyboard_transparency"

    invoke-interface {v11, v12}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3136
    move-object v11, v0

    invoke-direct {v11}, Lgtandroid/universal/MainActivity;->loadCustomButtons()V

    .line 3137
    move-object v11, v0

    const-string v12, "\u2705 \u0418\u043c\u043f\u043e\u0440\u0442 \u0443\u0441\u043f\u0435\u0448\u0435\u043d!"

    const/4 v13, 0x1

    invoke-static {v11, v12, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v11

    invoke-virtual {v11}, Landroid/widget/Toast;->show()V

    .line 3140
    :goto_5
    return-void

    .line 3101
    :cond_1
    move-object v11, v5

    const-string v12, "#"

    invoke-virtual {v11, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-nez v11, :cond_2

    move-object v11, v5

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_3

    :cond_2
    goto/16 :goto_0

    .line 3103
    :cond_3
    move-object v11, v5

    const-string v12, "="

    const/4 v13, 0x2

    invoke-virtual {v11, v12, v13}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v11

    move-object v7, v11

    .line 3104
    move-object v11, v7

    array-length v11, v11

    const/4 v12, 0x2

    if-ne v11, v12, :cond_0

    .line 3105
    move-object v11, v7

    const/4 v12, 0x0

    aget-object v11, v11, v12

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    move-object v8, v11

    .line 3106
    move-object v11, v7

    const/4 v12, 0x1

    aget-object v11, v11, v12

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    move-object v9, v11

    .line 3107
    move-object v11, v6

    move-object v12, v8

    move-object v13, v9

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_4

    move-result-object v11

    goto/16 :goto_0

    .line 3114
    :catch_0
    move-exception v11

    move-object v7, v11

    goto/16 :goto_1

    .line 3120
    :catch_1
    move-exception v11

    move-object v7, v11

    goto/16 :goto_2

    .line 3126
    :catch_2
    move-exception v11

    move-object v7, v11

    goto/16 :goto_3

    .line 3132
    :catch_3
    move-exception v11

    move-object v7, v11

    goto :goto_4

    .line 3137
    :catch_4
    move-exception v11

    move-object v3, v11

    .line 3139
    move-object v11, v3

    invoke-virtual {v11}, Ljava/lang/Throwable;->printStackTrace()V

    .line 3140
    move-object v11, v0

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v3

    invoke-virtual {v13}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x0

    invoke-static {v11, v12, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v11

    invoke-virtual {v11}, Landroid/widget/Toast;->show()V

    goto :goto_5
.end method

.method private importNavigatorFromFile(Landroid/net/Uri;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1880
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v10, v0

    :try_start_0
    invoke-virtual {v10}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v10

    move-object v11, v1

    invoke-virtual {v10, v11}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v10

    move-object v3, v10

    .line 1881
    new-instance v10, Ljava/io/ByteArrayOutputStream;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    invoke-direct {v11}, Ljava/io/ByteArrayOutputStream;-><init>()V

    move-object v4, v10

    .line 1882
    const/16 v10, 0x1000

    new-array v10, v10, [B

    move-object v5, v10

    .line 1884
    :goto_0
    move-object v10, v3

    move-object v11, v5

    invoke-virtual {v10, v11}, Ljava/io/InputStream;->read([B)I

    move-result v10

    move v15, v10

    move v10, v15

    move v11, v15

    move v6, v11

    const/4 v11, 0x0

    if-gt v10, v11, :cond_0

    .line 1885
    move-object v10, v3

    invoke-virtual {v10}, Ljava/io/InputStream;->close()V

    .line 1886
    new-instance v10, Ljava/lang/String;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v4

    invoke-virtual {v12}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v12

    const-string v13, "UTF-8"

    invoke-static {v13}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v13

    invoke-direct {v11, v12, v13}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    move-object v7, v10

    .line 1888
    move-object v10, v7

    invoke-static {v10}, Lgtandroid/universal/NavData;->parse(Ljava/lang/String;)Ljava/util/List;

    move-result-object v10

    move-object v8, v10

    .line 1889
    move-object v10, v8

    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_1

    .line 1890
    move-object v10, v0

    const-string v11, "\u274c \u0412 \u0444\u0430\u0439\u043b\u0435 \u043d\u0435\u0442 \u043f\u0440\u043e\u043d\u0443\u043c\u0435\u0440\u043e\u0432\u0430\u043d\u043d\u044b\u0445 \u0441\u0442\u0440\u043e\u043a. \u041d\u0443\u0436\u0435\u043d \u0444\u043e\u0440\u043c\u0430\u0442: \u00ab1. \u041a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u044f\u00bb, \u043c\u0435\u0441\u0442\u0430 \u043d\u0435\u043e\u0431\u044f\u0437\u0430\u0442\u0435\u043b\u044c\u043d\u044b: \u00ab1.1. \u041c\u0435\u0441\u0442\u043e\u00bb"

    const/4 v12, 0x1

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    .line 1900
    :goto_1
    return-void

    .line 1884
    :cond_0
    move-object v10, v4

    move-object v11, v5

    const/4 v12, 0x0

    move v13, v6

    invoke-virtual {v10, v11, v12, v13}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 1896
    :catch_0
    move-exception v10

    move-object v3, v10

    .line 1900
    move-object v10, v0

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v3

    invoke-virtual {v12}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    const/4 v12, 0x0

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    :goto_2
    goto :goto_1

    .line 1895
    :cond_1
    move-object v10, v0

    :try_start_1
    iget-object v10, v10, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v11, v8

    invoke-static {v10, v11}, Lgtandroid/universal/NavData;->saveNavigator(Landroid/content/SharedPreferences;Ljava/util/List;)V

    .line 1896
    move-object v10, v0

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object v15, v12

    move-object v12, v15

    move-object v13, v15

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object v15, v13

    move-object v13, v15

    move-object v14, v15

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    const-string v14, "\u2705 \u0418\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043e: \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0439 "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v8

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, ", \u043c\u0435\u0441\u0442 "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v8

    invoke-static {v12}, Lgtandroid/universal/NavData;->countItems(Ljava/util/List;)I

    move-result v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    const/4 v12, 0x1

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    goto :goto_2
.end method

.method private importT9Dictionary()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 3394
    move-object v0, p0

    new-instance v4, Landroid/content/Intent;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "android.intent.action.OPEN_DOCUMENT"

    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v2, v4

    .line 3395
    move-object v4, v2

    const-string v5, "android.intent.category.OPENABLE"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 3396
    move-object v4, v2

    const-string v5, "*/*"

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    .line 3397
    move-object v4, v0

    move-object v5, v2

    const/16 v6, 0x303

    invoke-virtual {v4, v5, v6}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    return-void
.end method

.method private importT9FromFile(Landroid/net/Uri;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 3410
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v11, v0

    :try_start_0
    invoke-virtual {v11}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v11

    move-object v12, v1

    invoke-virtual {v11, v12}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v11

    move-object v3, v11

    .line 3411
    new-instance v11, Ljava/io/BufferedReader;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    new-instance v13, Ljava/io/InputStreamReader;

    move-object/from16 v16, v13

    move-object/from16 v13, v16

    move-object/from16 v14, v16

    move-object v15, v3

    invoke-direct {v14, v15}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    invoke-direct {v12, v13}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    move-object v4, v11

    .line 3412
    new-instance v11, Lorg/json/JSONArray;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    invoke-direct {v12}, Lorg/json/JSONArray;-><init>()V

    move-object v6, v11

    .line 3415
    new-instance v11, Ljava/util/HashSet;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    invoke-direct {v12}, Ljava/util/HashSet;-><init>()V

    move-object v7, v11

    .line 3417
    :goto_0
    move-object v11, v4

    invoke-virtual {v11}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v11

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v5, v12

    if-nez v11, :cond_0

    .line 3425
    move-object v11, v4

    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V

    .line 3427
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "t9_words"

    move-object v13, v6

    invoke-virtual {v13}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3428
    move-object v11, v0

    invoke-direct {v11}, Lgtandroid/universal/MainActivity;->notifyT9DictChanged()V

    .line 3429
    move-object v11, v0

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u2705 \u0418\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043e \u0441\u043b\u043e\u0432: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v6

    invoke-virtual {v13}, Lorg/json/JSONArray;->length()I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x1

    invoke-static {v11, v12, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v11

    invoke-virtual {v11}, Landroid/widget/Toast;->show()V

    .line 3432
    :goto_1
    return-void

    .line 3418
    :cond_0
    move-object v11, v5

    invoke-virtual {v11}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v11

    move-object v8, v11

    .line 3419
    move-object v11, v8

    invoke-virtual {v11}, Ljava/lang/String;->isEmpty()Z

    move-result v11

    if-nez v11, :cond_1

    move-object v11, v8

    const-string v12, "#"

    invoke-virtual {v11, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_2

    :cond_1
    goto :goto_0

    .line 3420
    :cond_2
    move-object v11, v8

    invoke-virtual {v11}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v11

    move-object v9, v11

    .line 3421
    move-object v11, v7

    move-object v12, v9

    invoke-interface {v11, v12}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_3

    goto :goto_0

    .line 3422
    :cond_3
    move-object v11, v7

    move-object v12, v9

    invoke-interface {v11, v12}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v11

    .line 3423
    move-object v11, v6

    move-object v12, v8

    invoke-virtual {v11, v12}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v11

    goto/16 :goto_0

    .line 3429
    :catch_0
    move-exception v11

    move-object v3, v11

    .line 3431
    move-object v11, v3

    invoke-virtual {v11}, Ljava/lang/Throwable;->printStackTrace()V

    .line 3432
    move-object v11, v0

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v3

    invoke-virtual {v13}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x0

    invoke-static {v11, v12, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v11

    invoke-virtual {v11}, Landroid/widget/Toast;->show()V

    goto :goto_1
.end method

.method private importTriggersFromFile(Landroid/net/Uri;)V
    .locals 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/net/Uri;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1712
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object/from16 v18, v2

    :try_start_0
    invoke-virtual/range {v18 .. v18}, Landroid/content/ContextWrapper;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v18

    move-object/from16 v19, v3

    invoke-virtual/range {v18 .. v19}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object v18

    move-object/from16 v5, v18

    .line 1713
    new-instance v18, Ljava/io/ByteArrayOutputStream;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    invoke-direct/range {v19 .. v19}, Ljava/io/ByteArrayOutputStream;-><init>()V

    move-object/from16 v6, v18

    .line 1714
    const/16 v18, 0x1000

    move/from16 v0, v18

    new-array v0, v0, [B

    move-object/from16 v18, v0

    move-object/from16 v7, v18

    .line 1716
    :goto_0
    move-object/from16 v18, v5

    move-object/from16 v19, v7

    invoke-virtual/range {v18 .. v19}, Ljava/io/InputStream;->read([B)I

    move-result v18

    move/from16 v23, v18

    move/from16 v18, v23

    move/from16 v19, v23

    move/from16 v8, v19

    const/16 v19, 0x0

    move/from16 v0, v18

    move/from16 v1, v19

    if-gt v0, v1, :cond_1

    .line 1717
    move-object/from16 v18, v5

    invoke-virtual/range {v18 .. v18}, Ljava/io/InputStream;->close()V

    .line 1718
    new-instance v18, Ljava/lang/String;

    move-object/from16 v23, v18

    move-object/from16 v18, v23

    move-object/from16 v19, v23

    move-object/from16 v20, v6

    invoke-virtual/range {v20 .. v20}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v20

    const-string v21, "UTF-8"

    invoke-static/range {v21 .. v21}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v21

    invoke-direct/range {v19 .. v21}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    move-object/from16 v9, v18

    .line 1719
    move-object/from16 v18, v9

    invoke-virtual/range {v18 .. v18}, Ljava/lang/String;->length()I

    move-result v18

    const/16 v19, 0x0

    move/from16 v0, v18

    move/from16 v1, v19

    if-le v0, v1, :cond_0

    move-object/from16 v18, v9

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Ljava/lang/String;->charAt(I)C

    move-result v18

    const v19, 0xfeff

    move/from16 v0, v18

    move/from16 v1, v19

    if-ne v0, v1, :cond_0

    move-object/from16 v18, v9

    const/16 v19, 0x1

    invoke-virtual/range {v18 .. v19}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v18

    move-object/from16 v9, v18

    .line 1721
    :cond_0
    move-object/from16 v18, v9

    invoke-static/range {v18 .. v18}, Lgtandroid/universal/TriggerData;->parseJson(Ljava/lang/String;)Ljava/util/List;

    move-result-object v18

    move-object/from16 v10, v18

    .line 1722
    move-object/from16 v18, v10

    invoke-interface/range {v18 .. v18}, Ljava/util/List;->isEmpty()Z

    move-result v18

    if-eqz v18, :cond_2

    .line 1723
    move-object/from16 v18, v2

    const-string v19, "\u274c \u0412 \u0444\u0430\u0439\u043b\u0435 \u043d\u0435\u0442 \u043d\u0438 \u043e\u0434\u043d\u043e\u0433\u043e \u0442\u0440\u0438\u0433\u0433\u0435\u0440\u0430 (\u043d\u0443\u0436\u0435\u043d \u0444\u0430\u0439\u043b, \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d\u043d\u044b\u0439 \u0447\u0435\u0440\u0435\u0437 \u042d\u043a\u0441\u043f\u043e\u0440\u0442)"

    const/16 v20, 0x1

    invoke-static/range {v18 .. v20}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Landroid/widget/Toast;->show()V

    .line 1734
    :goto_1
    return-void

    .line 1716
    :cond_1
    move-object/from16 v18, v6

    move-object/from16 v19, v7

    const/16 v20, 0x0

    move/from16 v21, v8

    invoke-virtual/range {v18 .. v21}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto/16 :goto_0

    .line 1732
    :catch_0
    move-exception v18

    move-object/from16 v5, v18

    .line 1734
    move-object/from16 v18, v2

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v23, v19

    move-object/from16 v19, v23

    move-object/from16 v20, v23

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    const-string v20, "\u274c \u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    const/16 v20, 0x0

    invoke-static/range {v18 .. v20}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Landroid/widget/Toast;->show()V

    :goto_2
    goto :goto_1

    .line 1726
    :cond_2
    move-object/from16 v18, v2

    :try_start_1
    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v18, v0

    invoke-static/range {v18 .. v18}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v18

    move-object/from16 v11, v18

    .line 1727
    const/16 v18, 0x0

    move/from16 v12, v18

    const/16 v18, 0x0

    move/from16 v13, v18

    .line 1728
    move-object/from16 v18, v10

    check-cast v18, Ljava/util/Collection;

    invoke-interface/range {v18 .. v18}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v18

    move-object/from16 v14, v18

    .line 1729
    :goto_3
    move-object/from16 v18, v14

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-nez v18, :cond_3

    .line 1731
    move-object/from16 v18, v2

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v18, v0

    move-object/from16 v19, v11

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/TriggerData;->save(Landroid/content/SharedPreferences;Ljava/util/List;)V

    .line 1732
    move-object/from16 v18, v2

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v23, v19

    move-object/from16 v19, v23

    move-object/from16 v20, v23

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v23, v20

    move-object/from16 v20, v23

    move-object/from16 v21, v23

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v23, v21

    move-object/from16 v21, v23

    move-object/from16 v22, v23

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    const-string v22, "\u2705 \u0418\u043c\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u043d\u043e: \u043d\u043e\u0432\u044b\u0445 "

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    move/from16 v22, v12

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    const-string v21, ", \u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u043e "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    move/from16 v20, v13

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    const/16 v20, 0x1

    invoke-static/range {v18 .. v20}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Landroid/widget/Toast;->show()V

    goto/16 :goto_2

    .line 1728
    :cond_3
    move-object/from16 v18, v14

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Lgtandroid/universal/TriggerData$Trigger;

    move-object/from16 v16, v18

    .line 1729
    move-object/from16 v18, v11

    move-object/from16 v19, v16

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/TriggerData;->upsert(Ljava/util/List;Lgtandroid/universal/TriggerData$Trigger;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    move-result v18

    if-eqz v18, :cond_4

    add-int/lit8 v13, v13, 0x1

    goto/16 :goto_3

    :cond_4
    add-int/lit8 v12, v12, 0x1

    goto/16 :goto_3
.end method

.method private initUI()V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 263
    move-object v0, p0

    move-object v6, v0

    new-instance v7, Landroid/widget/LinearLayout;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    .line 264
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 265
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    const v7, -0xf5f3ee

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 267
    new-instance v6, Landroid/widget/ScrollView;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v2, v6

    .line 268
    move-object v6, v2

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 269
    move-object v6, v2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    const/4 v10, -0x1

    const/4 v11, -0x2

    invoke-direct {v9, v10, v11}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7, v8}, Landroid/widget/ScrollView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 272
    new-instance v6, Landroid/widget/LinearLayout;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v6

    .line 273
    move-object v6, v3

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 274
    move-object v6, v3

    move-object v7, v2

    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    const/4 v10, -0x1

    const/4 v11, 0x0

    const/high16 v12, 0x3f800000    # 1.0f

    invoke-direct {v9, v10, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v6, v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 276
    move-object v6, v3

    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/MainActivity;->buildBottomNav()Landroid/view/View;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 278
    new-instance v6, Landroid/widget/FrameLayout;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 279
    move-object v6, v4

    move-object v7, v3

    new-instance v8, Landroid/widget/FrameLayout$LayoutParams;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    const/4 v10, -0x1

    const/4 v11, -0x1

    invoke-direct {v9, v10, v11}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 281
    move-object v6, v0

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/app/Activity;->setContentView(Landroid/view/View;)V

    .line 282
    move-object v6, v0

    invoke-direct {v6}, Lgtandroid/universal/MainActivity;->showMainScreen()V

    .line 284
    move-object v6, v0

    invoke-direct {v6}, Lgtandroid/universal/MainActivity;->loadAdsInBackground()V

    return-void
.end method

.method private loadAdsInBackground()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 656
    move-object v0, p0

    new-instance v2, Ljava/lang/Thread;

    move-object v7, v2

    move-object v2, v7

    move-object v3, v7

    new-instance v4, Lgtandroid/universal/MainActivity$100000012;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    move-object v6, v0

    invoke-direct {v5, v6}, Lgtandroid/universal/MainActivity$100000012;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v3, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private loadCustomButtons()V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2543
    move-object v0, p0

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->customButtons:Ljava/util/ArrayList;

    invoke-virtual {v7}, Ljava/util/ArrayList;->clear()V

    .line 2544
    move-object v7, v0

    const-string v8, "btn_count"

    const/4 v9, 0x0

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v7

    move v2, v7

    .line 2545
    const/4 v7, 0x0

    move v3, v7

    :goto_0
    move v7, v3

    move v8, v2

    if-lt v7, v8, :cond_0

    return-void

    .line 2546
    :cond_0
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "btn_"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move v10, v3

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "_name"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    const-string v9, ""

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 2547
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "btn_"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move v10, v3

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "_text"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    const-string v9, ""

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    move-object v5, v7

    .line 2548
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->customButtons:Ljava/util/ArrayList;

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    move-object v10, v4

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, "|"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v5

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-result v7

    .line 2545
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0
.end method

.method private loadEvents()Lorg/json/JSONArray;
    .locals 10

    .prologue
    .line 946
    move-object v0, p0

    :try_start_0
    new-instance v4, Lorg/json/JSONArray;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v7, "events_list"

    const-string v8, "[]"

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v4

    .line 948
    :goto_0
    return-object v0

    .line 946
    :catch_0
    move-exception v4

    move-object v2, v4

    .line 948
    new-instance v4, Lorg/json/JSONArray;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    invoke-direct {v5}, Lorg/json/JSONArray;-><init>()V

    move-object v0, v4

    goto :goto_0
.end method

.method private loadImageAsync(Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Landroid/widget/ImageView;",
            ")V"
        }
    .end annotation

    .prologue
    .line 774
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    new-instance v4, Ljava/lang/Thread;

    move-object v11, v4

    move-object v4, v11

    move-object v5, v11

    new-instance v6, Lgtandroid/universal/MainActivity$100000015;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    move-object v9, v1

    move-object v10, v2

    invoke-direct {v7, v8, v9, v10}, Lgtandroid/universal/MainActivity$100000015;-><init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;Landroid/widget/ImageView;)V

    invoke-direct {v5, v6}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method private loadPunishmentQueueLines()Ljava/util/List;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .prologue
    .line 1483
    move-object v0, p0

    new-instance v6, Ljava/util/ArrayList;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    move-object v2, v6

    .line 1485
    :try_start_0
    new-instance v6, Lorg/json/JSONArray;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v9, "punishment_queue_lines"

    const-string v10, "[]"

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v6

    .line 1486
    const/4 v6, 0x0

    move v4, v6

    :goto_0
    move v6, v4

    move-object v7, v3

    invoke-virtual {v7}, Lorg/json/JSONArray;->length()I

    move-result v7

    if-lt v6, v7, :cond_0

    .line 1490
    :goto_1
    move-object v6, v2

    move-object v0, v6

    return-object v0

    .line 1486
    :cond_0
    move-object v6, v2

    move-object v7, v3

    move v8, v4

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v7

    invoke-interface {v6, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v6

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :catch_0
    move-exception v6

    move-object v3, v6

    .line 1488
    move-object v6, v3

    invoke-virtual {v6}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1
.end method

.method private loadQuickAnswerPairs()Ljava/util/List;
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<[",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .prologue
    .line 1500
    move-object v0, p0

    new-instance v7, Ljava/util/ArrayList;

    move-object v14, v7

    move-object v7, v14

    move-object v8, v14

    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    move-object v2, v7

    .line 1502
    :try_start_0
    new-instance v7, Lorg/json/JSONArray;

    move-object v14, v7

    move-object v7, v14

    move-object v8, v14

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v10, "quick_answers"

    const-string v11, "[]"

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v3, v7

    .line 1503
    const/4 v7, 0x0

    move v4, v7

    :goto_0
    move v7, v4

    move-object v8, v3

    invoke-virtual {v8}, Lorg/json/JSONArray;->length()I

    move-result v8

    if-lt v7, v8, :cond_0

    .line 1511
    :goto_1
    move-object v7, v2

    move-object v0, v7

    return-object v0

    .line 1504
    :cond_0
    move-object v7, v3

    move v8, v4

    invoke-virtual {v7, v8}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v7

    move-object v5, v7

    .line 1505
    move-object v7, v5

    if-nez v7, :cond_1

    .line 1503
    :goto_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 1506
    :cond_1
    move-object v7, v2

    const/4 v8, 0x2

    new-array v8, v8, [Ljava/lang/String;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    const/4 v10, 0x0

    move-object v11, v5

    const-string v12, "name"

    const-string v13, "\u041e\u0442\u0432\u0435\u0442"

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v9, v10

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    const/4 v10, 0x1

    move-object v11, v5

    const-string v12, "answer"

    const-string v13, ""

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    aput-object v11, v9, v10

    invoke-interface {v7, v8}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v7

    goto :goto_2

    .line 1503
    :catch_0
    move-exception v7

    move-object v3, v7

    .line 1509
    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1
.end method

.method private normalizeEventTime(Ljava/lang/String;)Ljava/lang/String;
    .locals 17

    .prologue
    .line 957
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v7, v1

    if-nez v7, :cond_0

    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    .line 963
    :goto_0
    return-object v0

    .line 958
    :cond_0
    const-string v7, "^\\s*(\\d{1,2}):(\\d{2})\\s*$"

    invoke-static {v7}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v7

    move-object v8, v1

    invoke-virtual {v7, v8}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v7

    move-object v3, v7

    .line 959
    move-object v7, v3

    invoke-virtual {v7}, Ljava/util/regex/Matcher;->find()Z

    move-result v7

    if-nez v7, :cond_1

    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    goto :goto_0

    .line 960
    :cond_1
    move-object v7, v3

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    move v4, v7

    .line 961
    move-object v7, v3

    const/4 v8, 0x2

    invoke-virtual {v7, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    move v5, v7

    .line 962
    move v7, v4

    const/16 v8, 0x17

    if-gt v7, v8, :cond_2

    move v7, v5

    const/16 v8, 0x3b

    if-le v7, v8, :cond_3

    :cond_2
    const/4 v7, 0x0

    check-cast v7, Ljava/lang/String;

    move-object v0, v7

    goto :goto_0

    .line 963
    :cond_3
    sget-object v7, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v8, "%02d:%02d"

    const/4 v9, 0x2

    new-array v9, v9, [Ljava/lang/Object;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    const/4 v11, 0x0

    move v12, v4

    new-instance v13, Ljava/lang/Integer;

    move v15, v12

    move-object/from16 v16, v13

    move-object/from16 v12, v16

    move v13, v15

    move-object/from16 v14, v16

    move v15, v13

    move-object/from16 v16, v14

    move-object/from16 v13, v16

    move v14, v15

    invoke-direct {v13, v14}, Ljava/lang/Integer;-><init>(I)V

    aput-object v12, v10, v11

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    const/4 v11, 0x1

    move v12, v5

    new-instance v13, Ljava/lang/Integer;

    move v15, v12

    move-object/from16 v16, v13

    move-object/from16 v12, v16

    move v13, v15

    move-object/from16 v14, v16

    move v15, v13

    move-object/from16 v16, v14

    move-object/from16 v13, v16

    move v14, v15

    invoke-direct {v13, v14}, Ljava/lang/Integer;-><init>(I)V

    aput-object v12, v10, v11

    invoke-static {v7, v8, v9}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v7

    move-object v0, v7

    goto :goto_0
.end method

.method private notifyT9DictChanged()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 3180
    move-object v0, p0

    move-object v2, v0

    new-instance v3, Landroid/content/Intent;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    const-string v5, "T9_DICT_CHANGED"

    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method private postTrackerReadyNotification()V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 288
    move-object/from16 v0, p0

    const-string v11, "gtandroid_tracker"

    move-object v2, v11

    .line 289
    move-object v11, v0

    const-string v12, "notification"

    invoke-virtual {v11, v12}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/app/NotificationManager;

    move-object v3, v11

    .line 290
    move-object v11, v3

    if-nez v11, :cond_0

    .line 325
    :goto_0
    return-void

    .line 292
    :cond_0
    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x1a

    if-lt v11, v12, :cond_1

    .line 293
    move-object v11, v3

    move-object v12, v2

    invoke-virtual {v11, v12}, Landroid/app/NotificationManager;->getNotificationChannel(Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object v11

    move-object v4, v11

    .line 294
    move-object v11, v4

    if-nez v11, :cond_1

    .line 295
    new-instance v11, Landroid/app/NotificationChannel;

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    move-object v13, v2

    const-string v14, "\u0427\u0430\u0442-\u0442\u0440\u0435\u043a\u0435\u0440"

    const/4 v15, 0x4

    invoke-direct {v12, v13, v14, v15}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    move-object v4, v11

    .line 297
    move-object v11, v4

    const-string v12, "\u041d\u0430\u043f\u043e\u043c\u0438\u043d\u0430\u043d\u0438\u0435 \u0432\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0447\u0430\u0442-\u0442\u0440\u0435\u043a\u0435\u0440 \u0443\u0436\u0435 \u0432 \u0438\u0433\u0440\u0435"

    invoke-virtual {v11, v12}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    .line 298
    move-object v11, v3

    move-object v12, v4

    invoke-virtual {v11, v12}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    .line 302
    :cond_1
    new-instance v11, Landroid/content/Intent;

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    move-object v13, v0

    :try_start_0
    const-string v14, "gtandroid.universal.AreaSelectorService"

    invoke-static {v14}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v14

    invoke-direct {v12, v13, v14}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v4, v11

    .line 303
    const/high16 v11, 0x8000000

    move v6, v11

    .line 304
    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x17

    if-lt v11, v12, :cond_2

    .line 305
    move v11, v6

    const/high16 v12, 0x4000000

    or-int/2addr v11, v12

    move v6, v11

    .line 307
    :cond_2
    move-object v11, v0

    const/16 v12, 0xbb9

    move-object v13, v4

    move v14, v6

    invoke-static {v11, v12, v13, v14}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v11

    move-object v7, v11

    .line 309
    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x1a

    if-lt v11, v12, :cond_3

    new-instance v11, Landroid/app/Notification$Builder;

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    move-object v13, v0

    move-object v14, v2

    invoke-direct {v12, v13, v14}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    :goto_1
    move-object v8, v11

    .line 313
    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u043e\u0442\u043a\u0440\u043e\u0439\u0442\u0435 \u0438\u0433\u0440\u0443, \u0434\u043e\u0436\u0434\u0438\u0442\u0435\u0441\u044c \u043d\u0443\u0436\u043d\u043e\u0433\u043e \u044d\u043a\u0440\u0430\u043d\u0430, "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, "\u0438 \u0442\u043e\u043b\u044c\u043a\u043e \u043f\u043e\u0442\u043e\u043c \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u043a\u043d\u043e\u043f\u043a\u0443 \u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c - \u0442\u0430\u043a \u0442\u0440\u0435\u043a\u0435\u0440 \u043d\u0430\u0441\u0442\u0440\u043e\u0438\u0442\u0441\u044f \u043f\u043e\u0434 \u043f\u0440\u0430\u0432\u0438\u043b\u044c\u043d\u044b\u0439 \u043f\u043e\u0432\u043e\u0440\u043e\u0442 \u044d\u043a\u0440\u0430\u043d\u0430."

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    move-object v9, v11

    .line 316
    move-object v11, v8

    const/high16 v12, 0x7f030000

    invoke-virtual {v11, v12}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 317
    move-object v11, v8

    const-string v12, "\u0427\u0430\u0442-\u0442\u0440\u0435\u043a\u0435\u0440 \u0433\u043e\u0442\u043e\u0432"

    invoke-virtual {v11, v12}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 318
    move-object v11, v8

    const-string v12, "\u0417\u0430\u0439\u0434\u0438\u0442\u0435 \u0432 \u0438\u0433\u0440\u0443, \u043f\u043e\u0442\u043e\u043c \u043d\u0430\u0436\u043c\u0438\u0442\u0435 \u043a\u043d\u043e\u043f\u043a\u0443 \u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c"

    invoke-virtual {v11, v12}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 319
    move-object v11, v8

    new-instance v12, Landroid/app/Notification$BigTextStyle;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    invoke-direct {v13}, Landroid/app/Notification$BigTextStyle;-><init>()V

    move-object v13, v9

    invoke-virtual {v12, v13}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object v12

    invoke-virtual {v11, v12}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 320
    move-object v11, v8

    const/4 v12, 0x0

    const-string v13, "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c"

    move-object v14, v7

    invoke-virtual {v11, v12, v13, v14}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 321
    move-object v11, v8

    move-object v12, v7

    invoke-virtual {v11, v12}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 322
    move-object v11, v8

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 323
    move-object v11, v8

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v11

    .line 325
    move-object v11, v3

    const/16 v12, 0xbb9

    move-object v13, v8

    invoke-virtual {v13}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v13

    invoke-virtual {v11, v12, v13}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    goto/16 :goto_0

    .line 302
    :catch_0
    move-exception v11

    move-object v5, v11

    new-instance v11, Ljava/lang/NoClassDefFoundError;

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    move-object v13, v5

    invoke-virtual {v13}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v13

    invoke-direct {v12, v13}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v11

    .line 309
    :cond_3
    new-instance v11, Landroid/app/Notification$Builder;

    move-object/from16 v18, v11

    move-object/from16 v11, v18

    move-object/from16 v12, v18

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    goto/16 :goto_1
.end method

.method private saveEvents(Lorg/json/JSONArray;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")V"
        }
    .end annotation

    .prologue
    .line 953
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "events_list"

    move-object v5, v1

    invoke-virtual {v5}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private saveFamWarCommand(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2887
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    :try_start_0
    new-instance v10, Lorg/json/JSONArray;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v13, "famwar_commands"

    const-string v14, "[]"

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v7, v10

    .line 2889
    new-instance v10, Lorg/json/JSONObject;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    invoke-direct {v11}, Lorg/json/JSONObject;-><init>()V

    move-object v8, v10

    .line 2890
    move-object v10, v8

    const-string v11, "name"

    move-object v12, v1

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 2891
    move-object v10, v8

    const-string v11, "command"

    move-object v12, v2

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 2892
    move-object v10, v8

    const-string v11, "time"

    move-object v12, v3

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 2893
    move-object v10, v8

    const-string v11, "reason"

    move-object v12, v4

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 2894
    move-object v10, v8

    const-string v11, "minlevel"

    move-object v12, v5

    invoke-virtual {v10, v11, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v10

    .line 2896
    move-object v10, v7

    move-object v11, v8

    invoke-virtual {v10, v11}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v10

    .line 2897
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const-string v11, "famwar_commands"

    move-object v12, v7

    invoke-virtual {v12}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2899
    :goto_0
    return-void

    .line 2897
    :catch_0
    move-exception v10

    move-object v7, v10

    .line 2899
    move-object v10, v0

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v7

    invoke-virtual {v12}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    const/4 v12, 0x0

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private savePunishment(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2077
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    :try_start_0
    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "punishment_"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v1

    invoke-virtual {v13}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    move-object v8, v12

    .line 2078
    new-instance v12, Lorg/json/JSONArray;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v15, v8

    const-string v16, "[]"

    invoke-interface/range {v14 .. v16}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-direct {v13, v14}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v9, v12

    .line 2080
    new-instance v12, Lorg/json/JSONObject;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Lorg/json/JSONObject;-><init>()V

    move-object v10, v12

    .line 2081
    move-object v12, v10

    const-string v13, "name"

    move-object v14, v2

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v12

    .line 2082
    move-object v12, v10

    const-string v13, "command"

    move-object v14, v3

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v12

    .line 2083
    move-object v12, v10

    const-string v13, "time"

    move-object v14, v4

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v12

    .line 2084
    move-object v12, v10

    const-string v13, "reason"

    move-object v14, v5

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v12

    .line 2085
    move-object v12, v10

    const-string v13, "minlevel"

    move-object v14, v6

    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v12

    .line 2087
    move-object v12, v9

    move-object v13, v10

    invoke-virtual {v12, v13}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v12

    .line 2088
    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v12}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v12

    move-object v13, v8

    move-object v14, v9

    invoke-virtual {v14}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v12

    invoke-interface {v12}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2090
    :goto_0
    return-void

    .line 2088
    :catch_0
    move-exception v12

    move-object v8, v12

    .line 2090
    move-object v12, v0

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    const-string v14, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v8

    invoke-virtual {v14}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    const/4 v14, 0x0

    invoke-static {v12, v13, v14}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v12

    invoke-virtual {v12}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private savePunishmentQueueLines(Ljava/util/List;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 1494
    move-object v0, p0

    move-object v1, p1

    new-instance v8, Lorg/json/JSONArray;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Lorg/json/JSONArray;-><init>()V

    move-object v3, v8

    .line 1495
    move-object v8, v1

    check-cast v8, Ljava/util/Collection;

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    move-object v4, v8

    :goto_0
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-nez v8, :cond_0

    .line 1496
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const-string v9, "punishment_queue_lines"

    move-object v10, v3

    invoke-virtual {v10}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    .line 1495
    :cond_0
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    move-object v6, v8

    move-object v8, v3

    move-object v9, v6

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v8

    goto :goto_0
.end method

.method private saveQuickAnswer(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2364
    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    :try_start_0
    new-instance v8, Lorg/json/JSONArray;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v11, "quick_answers"

    const-string v12, "[]"

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v5, v8

    .line 2366
    new-instance v8, Lorg/json/JSONObject;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    move-object v6, v8

    .line 2367
    move-object v8, v6

    const-string v9, "name"

    move-object v10, v1

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 2368
    move-object v8, v6

    const-string v9, "command"

    move-object v10, v2

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 2369
    move-object v8, v6

    const-string v9, "answer"

    move-object v10, v3

    invoke-virtual {v8, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v8

    .line 2370
    move-object v8, v5

    move-object v9, v6

    invoke-virtual {v8, v9}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v8

    .line 2371
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const-string v9, "quick_answers"

    move-object v10, v5

    invoke-virtual {v10}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2373
    :goto_0
    return-void

    .line 2371
    :catch_0
    move-exception v8

    move-object v5, v8

    .line 2373
    move-object v8, v0

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v5

    invoke-virtual {v10}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private showAddFamWarDialog()V
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2836
    move-object/from16 v0, p0

    new-instance v9, Landroid/widget/LinearLayout;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v9

    .line 2837
    move-object v9, v2

    const/4 v10, 0x1

    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2838
    move-object v9, v2

    const/16 v10, 0x14

    const/16 v11, 0x14

    const/16 v12, 0x14

    const/16 v13, 0x14

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 2840
    new-instance v9, Landroid/widget/EditText;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v3, v9

    .line 2841
    move-object v9, v3

    const-string v10, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041b\u0435\u0447\u0435\u043d\u0438\u0435)"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2842
    move-object v9, v2

    move-object v10, v3

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2844
    new-instance v9, Landroid/widget/EditText;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v4, v9

    .line 2845
    move-object v9, v4

    const-string v10, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: /heal)"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2846
    move-object v9, v2

    move-object v10, v4

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2848
    new-instance v9, Landroid/widget/EditText;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v5, v9

    .line 2849
    move-object v9, v5

    const-string v10, "\u0412\u0440\u0435\u043c\u044f (\u0435\u0441\u043b\u0438 \u043d\u0443\u0436\u043d\u043e, \u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: 60)"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2850
    move-object v9, v2

    move-object v10, v5

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2852
    new-instance v9, Landroid/widget/EditText;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v6, v9

    .line 2853
    move-object v9, v6

    const-string v10, "\u041f\u0440\u0438\u0447\u0438\u043d\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041b\u0435\u0447\u0435\u043d\u0438\u0435 \u043f\u043e\u0441\u043b\u0435 \u0431\u043e\u044f)"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2854
    move-object v9, v2

    move-object v10, v6

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2856
    new-instance v9, Landroid/widget/EditText;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v7, v9

    .line 2857
    move-object v9, v7

    const-string v10, "\u041c\u0438\u043d. \u0443\u0440\u043e\u0432\u0435\u043d\u044c (1-4)"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2858
    move-object v9, v7

    const/4 v10, 0x2

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setInputType(I)V

    .line 2859
    move-object v9, v2

    move-object v10, v7

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2861
    new-instance v9, Landroid/app/AlertDialog$Builder;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v10, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043a\u043e\u043c\u0430\u043d\u0434\u0443 FamWar"

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    move-object v10, v2

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v11, Lgtandroid/universal/MainActivity$100000076;

    move-object/from16 v19, v11

    move-object/from16 v11, v19

    move-object/from16 v12, v19

    move-object v13, v0

    move-object v14, v3

    move-object v15, v4

    move-object/from16 v16, v5

    move-object/from16 v17, v6

    move-object/from16 v18, v7

    invoke-direct/range {v12 .. v18}, Lgtandroid/universal/MainActivity$100000076;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;)V

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v11, 0x0

    check-cast v11, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    invoke-virtual {v9}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v9

    return-void
.end method

.method private showAddPunishmentDialog(Ljava/lang/String;)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2026
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    new-instance v10, Landroid/widget/LinearLayout;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v10

    .line 2027
    move-object v10, v3

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2028
    move-object v10, v3

    const/16 v11, 0x14

    const/16 v12, 0x14

    const/16 v13, 0x14

    const/16 v14, 0x14

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/view/View;->setPadding(IIII)V

    .line 2030
    new-instance v10, Landroid/widget/EditText;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v4, v10

    .line 2031
    move-object v10, v4

    const-string v11, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041f\u043e\u043c\u0435\u0445\u0430)"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2032
    move-object v10, v3

    move-object v11, v4

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2034
    new-instance v10, Landroid/widget/EditText;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v5, v10

    .line 2035
    move-object v10, v5

    const-string v11, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: /kick)"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2036
    move-object v10, v3

    move-object v11, v5

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2038
    new-instance v10, Landroid/widget/EditText;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v6, v10

    .line 2039
    move-object v10, v6

    const-string v11, "\u0412\u0440\u0435\u043c\u044f (\u0435\u0441\u043b\u0438 \u043d\u0443\u0436\u043d\u043e)"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2040
    move-object v10, v3

    move-object v11, v6

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2042
    new-instance v10, Landroid/widget/EditText;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v7, v10

    .line 2043
    move-object v10, v7

    const-string v11, "\u041f\u0440\u0438\u0447\u0438\u043d\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: 5.2 \u041e\u041f)"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2044
    move-object v10, v3

    move-object v11, v7

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2046
    new-instance v10, Landroid/widget/EditText;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v8, v10

    .line 2047
    move-object v10, v8

    const-string v11, "\u041c\u0438\u043d. \u0443\u0440\u043e\u0432\u0435\u043d\u044c (1-4)"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2048
    move-object v10, v8

    const/4 v11, 0x2

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setInputType(I)V

    .line 2049
    move-object v10, v3

    move-object v11, v8

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2050
    new-instance v10, Landroid/app/AlertDialog$Builder;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v21, v11

    move-object/from16 v11, v21

    move-object/from16 v12, v21

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    const-string v12, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c: "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v1

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v10

    move-object v11, v3

    invoke-virtual {v10, v11}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v10

    const-string v11, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v12, Lgtandroid/universal/MainActivity$100000058;

    move-object/from16 v21, v12

    move-object/from16 v12, v21

    move-object/from16 v13, v21

    move-object v14, v0

    move-object v15, v4

    move-object/from16 v16, v5

    move-object/from16 v17, v6

    move-object/from16 v18, v7

    move-object/from16 v19, v8

    move-object/from16 v20, v1

    invoke-direct/range {v13 .. v20}, Lgtandroid/universal/MainActivity$100000058;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Ljava/lang/String;)V

    invoke-virtual {v10, v11, v12}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v10

    const-string v11, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v12, 0x0

    check-cast v12, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v10, v11, v12}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v10

    invoke-virtual {v10}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v10

    return-void
.end method

.method private showAddQuickAnswerDialog()V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2324
    move-object/from16 v0, p0

    new-instance v7, Landroid/widget/LinearLayout;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v7

    .line 2325
    move-object v7, v2

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2326
    move-object v7, v2

    const/16 v8, 0x14

    const/16 v9, 0x14

    const/16 v10, 0x14

    const/16 v11, 0x14

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/view/View;->setPadding(IIII)V

    .line 2328
    new-instance v7, Landroid/widget/EditText;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v3, v7

    .line 2329
    move-object v7, v3

    const-string v8, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041f\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435)"

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2330
    move-object v7, v2

    move-object v8, v3

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2332
    new-instance v7, Landroid/widget/EditText;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v4, v7

    .line 2333
    move-object v7, v4

    const-string v8, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: /ans) - \u043e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u043f\u0443\u0441\u0442\u044b\u043c \u0435\u0441\u043b\u0438 \u043d\u0435 \u043d\u0443\u0436\u043d\u0430"

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2334
    move-object v7, v2

    move-object v8, v4

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2336
    new-instance v7, Landroid/widget/EditText;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v5, v7

    .line 2337
    move-object v7, v5

    const-string v8, "\u0422\u0435\u043a\u0441\u0442 \u043e\u0442\u0432\u0435\u0442\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041f\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044e!)"

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2338
    move-object v7, v5

    const/4 v8, 0x3

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setLines(I)V

    .line 2339
    move-object v7, v2

    move-object v8, v5

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2341
    new-instance v7, Landroid/app/AlertDialog$Builder;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v8, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442"

    invoke-virtual {v7, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    move-object v8, v2

    invoke-virtual {v7, v8}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    const-string v8, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v9, Lgtandroid/universal/MainActivity$100000064;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    move-object v11, v0

    move-object v12, v3

    move-object v13, v4

    move-object v14, v5

    invoke-direct {v10, v11, v12, v13, v14}, Lgtandroid/universal/MainActivity$100000064;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;)V

    invoke-virtual {v7, v8, v9}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    const-string v8, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v9, 0x0

    check-cast v9, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v7, v8, v9}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    invoke-virtual {v7}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v7

    return-void
.end method

.method private showAddT9WordDialog()V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 3269
    move-object v0, p0

    new-instance v5, Landroid/widget/LinearLayout;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v5

    .line 3270
    move-object v5, v2

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3271
    move-object v5, v2

    const/16 v6, 0x1e

    const/16 v7, 0x14

    const/16 v8, 0x1e

    const/16 v9, 0x14

    invoke-virtual {v5, v6, v7, v8, v9}, Landroid/view/View;->setPadding(IIII)V

    .line 3273
    new-instance v5, Landroid/widget/EditText;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v3, v5

    .line 3274
    move-object v5, v3

    const-string v6, "\u0421\u043b\u043e\u0432\u043e (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041f\u0440\u0438\u0432\u0435\u0442)"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 3275
    move-object v5, v2

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3277
    new-instance v5, Landroid/app/AlertDialog$Builder;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v6, "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u043b\u043e\u0432\u043e \u0432 \u04229"

    invoke-virtual {v5, v6}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v5

    move-object v6, v2

    invoke-virtual {v5, v6}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v5

    const-string v6, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v7, Lgtandroid/universal/MainActivity$100000085;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    move-object v10, v3

    invoke-direct {v8, v9, v10}, Lgtandroid/universal/MainActivity$100000085;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;)V

    invoke-virtual {v5, v6, v7}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v5

    const-string v6, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v7, 0x0

    check-cast v7, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v5, v6, v7}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v5

    invoke-virtual {v5}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v5

    return-void
.end method

.method private showAdminLevelDialog()V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2770
    move-object v0, p0

    const/4 v4, 0x4

    new-array v4, v4, [Ljava/lang/String;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    const/4 v6, 0x0

    const-string v7, "1"

    aput-object v7, v5, v6

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    const/4 v6, 0x1

    const-string v7, "2"

    aput-object v7, v5, v6

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    const/4 v6, 0x2

    const-string v7, "3"

    aput-object v7, v5, v6

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    const/4 v6, 0x3

    const-string v7, "4"

    aput-object v7, v5, v6

    move-object v2, v4

    .line 2771
    new-instance v4, Landroid/app/AlertDialog$Builder;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    move-object v6, v0

    invoke-direct {v5, v6}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v5, "\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0430\u0434\u043c\u0438\u043d\u0430"

    invoke-virtual {v4, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    move-object v5, v2

    new-instance v6, Lgtandroid/universal/MainActivity$100000073;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity$100000073;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v4, v5, v6}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    invoke-virtual {v4}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v4

    return-void
.end method

.method private showEditFamWarDialog(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 3008
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    new-instance v15, Landroid/widget/LinearLayout;

    move-object/from16 v26, v15

    move-object/from16 v15, v26

    move-object/from16 v16, v26

    move-object/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v8, v15

    .line 3009
    move-object v15, v8

    const/16 v16, 0x1

    invoke-virtual/range {v15 .. v16}, Landroid/widget/LinearLayout;->setOrientation(I)V

    move-object v15, v8

    const/16 v16, 0x14

    const/16 v17, 0x14

    const/16 v18, 0x14

    const/16 v19, 0x14

    invoke-virtual/range {v15 .. v19}, Landroid/view/View;->setPadding(IIII)V

    .line 3011
    new-instance v15, Landroid/widget/EditText;

    move-object/from16 v26, v15

    move-object/from16 v15, v26

    move-object/from16 v16, v26

    move-object/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v9, v15

    .line 3012
    move-object v15, v9

    const-string v16, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041b\u0435\u0447\u0435\u043d\u0438\u0435)"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 3013
    move-object v15, v9

    move-object/from16 v16, v2

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3014
    move-object v15, v8

    move-object/from16 v16, v9

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3016
    new-instance v15, Landroid/widget/EditText;

    move-object/from16 v26, v15

    move-object/from16 v15, v26

    move-object/from16 v16, v26

    move-object/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v10, v15

    .line 3017
    move-object v15, v10

    const-string v16, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: /heal)"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 3018
    move-object v15, v10

    move-object/from16 v16, v3

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3019
    move-object v15, v8

    move-object/from16 v16, v10

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3021
    new-instance v15, Landroid/widget/EditText;

    move-object/from16 v26, v15

    move-object/from16 v15, v26

    move-object/from16 v16, v26

    move-object/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v11, v15

    .line 3022
    move-object v15, v11

    const-string v16, "\u0412\u0440\u0435\u043c\u044f (\u0435\u0441\u043b\u0438 \u043d\u0443\u0436\u043d\u043e)"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 3023
    move-object v15, v11

    move-object/from16 v16, v4

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3024
    move-object v15, v8

    move-object/from16 v16, v11

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3026
    new-instance v15, Landroid/widget/EditText;

    move-object/from16 v26, v15

    move-object/from16 v15, v26

    move-object/from16 v16, v26

    move-object/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v12, v15

    .line 3027
    move-object v15, v12

    const-string v16, "\u041f\u0440\u0438\u0447\u0438\u043d\u0430"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 3028
    move-object v15, v12

    move-object/from16 v16, v5

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3029
    move-object v15, v8

    move-object/from16 v16, v12

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3031
    new-instance v15, Landroid/widget/EditText;

    move-object/from16 v26, v15

    move-object/from16 v15, v26

    move-object/from16 v16, v26

    move-object/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v13, v15

    .line 3032
    move-object v15, v13

    const-string v16, "\u041c\u0438\u043d. \u0443\u0440\u043e\u0432\u0435\u043d\u044c (1-4)"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 3033
    move-object v15, v13

    move-object/from16 v16, v6

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3034
    move-object v15, v13

    const/16 v16, 0x2

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setInputType(I)V

    .line 3035
    move-object v15, v8

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3037
    new-instance v15, Landroid/app/AlertDialog$Builder;

    move-object/from16 v26, v15

    move-object/from16 v15, v26

    move-object/from16 v16, v26

    move-object/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v16, "\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043a\u043e\u043c\u0430\u043d\u0434\u0443 FamWar"

    invoke-virtual/range {v15 .. v16}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v15

    move-object/from16 v16, v8

    invoke-virtual/range {v15 .. v16}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v15

    const-string v16, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v17, Lgtandroid/universal/MainActivity$100000079;

    move-object/from16 v26, v17

    move-object/from16 v17, v26

    move-object/from16 v18, v26

    move-object/from16 v19, v0

    move-object/from16 v20, v9

    move-object/from16 v21, v10

    move-object/from16 v22, v11

    move-object/from16 v23, v12

    move-object/from16 v24, v13

    move/from16 v25, v1

    invoke-direct/range {v18 .. v25}, Lgtandroid/universal/MainActivity$100000079;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;I)V

    invoke-virtual/range {v15 .. v17}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v15

    const-string v16, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/16 v17, 0x0

    check-cast v17, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v15 .. v17}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v15

    invoke-virtual {v15}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v15

    return-void
.end method

.method private showEditNormalButtonDialog(ILjava/lang/String;Ljava/lang/String;)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2639
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    new-instance v9, Landroid/widget/LinearLayout;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v9

    .line 2640
    move-object v9, v5

    const/4 v10, 0x1

    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2641
    move-object v9, v5

    const/16 v10, 0x1e

    const/16 v11, 0x14

    const/16 v12, 0x1e

    const/16 v13, 0x14

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 2643
    new-instance v9, Landroid/widget/EditText;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v6, v9

    .line 2644
    move-object v9, v6

    const-string v10, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043a\u043d\u043e\u043f\u043a\u0438"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2645
    move-object v9, v6

    move-object v10, v2

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2646
    move-object v9, v5

    move-object v10, v6

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2648
    new-instance v9, Landroid/widget/EditText;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v7, v9

    .line 2649
    move-object v9, v7

    const-string v10, "\u0422\u0435\u043a\u0441\u0442 \u043a\u043e\u043c\u0430\u043d\u0434\u044b"

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2650
    move-object v9, v7

    move-object v10, v3

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2651
    move-object v9, v5

    move-object v10, v7

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2653
    new-instance v9, Landroid/app/AlertDialog$Builder;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v10, "\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043a\u043d\u043e\u043f\u043a\u0443"

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    move-object v10, v5

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v11, Lgtandroid/universal/MainActivity$100000070;

    move-object/from16 v17, v11

    move-object/from16 v11, v17

    move-object/from16 v12, v17

    move-object v13, v0

    move-object v14, v6

    move-object v15, v7

    move/from16 v16, v1

    invoke-direct/range {v12 .. v16}, Lgtandroid/universal/MainActivity$100000070;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;I)V

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v11, 0x0

    check-cast v11, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    invoke-virtual {v9}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v9

    return-void
.end method

.method private showEditPunishmentDialog(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 29
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2201
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    new-instance v16, Landroid/widget/LinearLayout;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    move-object/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v9, v16

    .line 2202
    move-object/from16 v16, v9

    const/16 v17, 0x1

    invoke-virtual/range {v16 .. v17}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2203
    move-object/from16 v16, v9

    const/16 v17, 0x14

    const/16 v18, 0x14

    const/16 v19, 0x14

    const/16 v20, 0x14

    invoke-virtual/range {v16 .. v20}, Landroid/view/View;->setPadding(IIII)V

    .line 2205
    new-instance v16, Landroid/widget/EditText;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    move-object/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v16

    .line 2206
    move-object/from16 v16, v10

    const-string v17, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041f\u043e\u043c\u0435\u0445\u0430)"

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2207
    move-object/from16 v16, v10

    move-object/from16 v17, v3

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2208
    move-object/from16 v16, v9

    move-object/from16 v17, v10

    invoke-virtual/range {v16 .. v17}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2210
    new-instance v16, Landroid/widget/EditText;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    move-object/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v11, v16

    .line 2211
    move-object/from16 v16, v11

    const-string v17, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: /kick)"

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2212
    move-object/from16 v16, v11

    move-object/from16 v17, v4

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2213
    move-object/from16 v16, v9

    move-object/from16 v17, v11

    invoke-virtual/range {v16 .. v17}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2215
    new-instance v16, Landroid/widget/EditText;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    move-object/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v12, v16

    .line 2216
    move-object/from16 v16, v12

    const-string v17, "\u0412\u0440\u0435\u043c\u044f (\u0435\u0441\u043b\u0438 \u043d\u0443\u0436\u043d\u043e)"

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2217
    move-object/from16 v16, v12

    move-object/from16 v17, v5

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2218
    move-object/from16 v16, v9

    move-object/from16 v17, v12

    invoke-virtual/range {v16 .. v17}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2220
    new-instance v16, Landroid/widget/EditText;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    move-object/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v16

    .line 2221
    move-object/from16 v16, v13

    const-string v17, "\u041f\u0440\u0438\u0447\u0438\u043d\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: 5.2 \u041e\u041f)"

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2222
    move-object/from16 v16, v13

    move-object/from16 v17, v6

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2223
    move-object/from16 v16, v9

    move-object/from16 v17, v13

    invoke-virtual/range {v16 .. v17}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2225
    new-instance v16, Landroid/widget/EditText;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    move-object/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v16

    .line 2226
    move-object/from16 v16, v14

    const-string v17, "\u041c\u0438\u043d. \u0443\u0440\u043e\u0432\u0435\u043d\u044c (1-4)"

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2227
    move-object/from16 v16, v14

    move-object/from16 v17, v7

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2228
    move-object/from16 v16, v14

    const/16 v17, 0x2

    invoke-virtual/range {v16 .. v17}, Landroid/widget/TextView;->setInputType(I)V

    .line 2229
    move-object/from16 v16, v9

    move-object/from16 v17, v14

    invoke-virtual/range {v16 .. v17}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2231
    new-instance v16, Landroid/app/AlertDialog$Builder;

    move-object/from16 v28, v16

    move-object/from16 v16, v28

    move-object/from16 v17, v28

    move-object/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    new-instance v17, Ljava/lang/StringBuffer;

    move-object/from16 v28, v17

    move-object/from16 v17, v28

    move-object/from16 v18, v28

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuffer;-><init>()V

    const-string v18, "\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c: "

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    move-object/from16 v18, v1

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v16

    move-object/from16 v17, v9

    invoke-virtual/range {v16 .. v17}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v16

    const-string v17, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v18, Lgtandroid/universal/MainActivity$100000061;

    move-object/from16 v28, v18

    move-object/from16 v18, v28

    move-object/from16 v19, v28

    move-object/from16 v20, v0

    move-object/from16 v21, v10

    move-object/from16 v22, v11

    move-object/from16 v23, v12

    move-object/from16 v24, v13

    move-object/from16 v25, v14

    move-object/from16 v26, v1

    move/from16 v27, v2

    invoke-direct/range {v19 .. v27}, Lgtandroid/universal/MainActivity$100000061;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Ljava/lang/String;I)V

    invoke-virtual/range {v16 .. v18}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v16

    const-string v17, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/16 v18, 0x0

    check-cast v18, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v16 .. v18}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v16

    return-void
.end method

.method private showEditQuickAnswerDialog(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2474
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    new-instance v11, Landroid/widget/LinearLayout;

    move-object/from16 v20, v11

    move-object/from16 v11, v20

    move-object/from16 v12, v20

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v6, v11

    .line 2475
    move-object v11, v6

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2476
    move-object v11, v6

    const/16 v12, 0x14

    const/16 v13, 0x14

    const/16 v14, 0x14

    const/16 v15, 0x14

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/view/View;->setPadding(IIII)V

    .line 2478
    new-instance v11, Landroid/widget/EditText;

    move-object/from16 v20, v11

    move-object/from16 v11, v20

    move-object/from16 v12, v20

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v7, v11

    .line 2479
    move-object v11, v7

    const-string v12, "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041f\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435)"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2480
    move-object v11, v7

    move-object v12, v2

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2481
    move-object v11, v6

    move-object v12, v7

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2483
    new-instance v11, Landroid/widget/EditText;

    move-object/from16 v20, v11

    move-object/from16 v11, v20

    move-object/from16 v12, v20

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v8, v11

    .line 2484
    move-object v11, v8

    const-string v12, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: /ans) - \u043e\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u043f\u0443\u0441\u0442\u044b\u043c \u0435\u0441\u043b\u0438 \u043d\u0435 \u043d\u0443\u0436\u043d\u0430"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2485
    move-object v11, v8

    move-object v12, v3

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2486
    move-object v11, v6

    move-object v12, v8

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2488
    new-instance v11, Landroid/widget/EditText;

    move-object/from16 v20, v11

    move-object/from16 v11, v20

    move-object/from16 v12, v20

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v9, v11

    .line 2489
    move-object v11, v9

    const-string v12, "\u0422\u0435\u043a\u0441\u0442 \u043e\u0442\u0432\u0435\u0442\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u041f\u0440\u0438\u0432\u0435\u0442\u0441\u0442\u0432\u0443\u044e!)"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 2490
    move-object v11, v9

    move-object v12, v4

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2491
    move-object v11, v9

    const/4 v12, 0x3

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setLines(I)V

    move-object v11, v6

    move-object v12, v9

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2493
    new-instance v11, Landroid/app/AlertDialog$Builder;

    move-object/from16 v20, v11

    move-object/from16 v11, v20

    move-object/from16 v12, v20

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v12, "\u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442"

    invoke-virtual {v11, v12}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v11

    move-object v12, v6

    invoke-virtual {v11, v12}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v11

    const-string v12, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v13, Lgtandroid/universal/MainActivity$100000067;

    move-object/from16 v20, v13

    move-object/from16 v13, v20

    move-object/from16 v14, v20

    move-object v15, v0

    move-object/from16 v16, v7

    move-object/from16 v17, v8

    move-object/from16 v18, v9

    move/from16 v19, v1

    invoke-direct/range {v14 .. v19}, Lgtandroid/universal/MainActivity$100000067;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;I)V

    invoke-virtual {v11, v12, v13}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v11

    const-string v12, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v13, 0x0

    check-cast v13, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v11, v12, v13}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v11

    invoke-virtual {v11}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v11

    return-void
.end method

.method private showEditorScreen()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1242
    move-object v0, p0

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 1243
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v6, v0

    const-string v7, "\u26a1"

    const-string v8, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440"

    const v9, -0xff1a01

    invoke-direct {v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->buildScreenHeaderCard(Ljava/lang/String;Ljava/lang/String;I)Landroid/view/View;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1245
    new-instance v5, Landroid/widget/LinearLayout;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v5

    .line 1246
    move-object v5, v2

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1247
    move-object v5, v2

    move-object v6, v0

    const/16 v7, 0x14

    int-to-float v7, v7

    invoke-direct {v6, v7}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v6

    move-object v7, v0

    const/16 v8, 0x8

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v7

    move-object v8, v0

    const/16 v9, 0x14

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    move-object v9, v0

    const/16 v10, 0x14

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v9

    invoke-virtual {v5, v6, v7, v8, v9}, Landroid/view/View;->setPadding(IIII)V

    .line 1248
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v6, v2

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1250
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\ud83d\udcdd \u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u043d\u0430\u043a\u0430\u0437\u0430\u043d\u0438\u0439"

    const v8, -0xff9934

    new-instance v9, Lgtandroid/universal/MainActivity$100000024;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000024;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1254
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\ud83d\udce5 \u041d\u0430\u043a\u0430\u0437\u0430\u043d\u0438\u044f \u0438\u0437 \u0430\u0434\u043c\u0438\u043d \u0447\u0430\u0442\u0430"

    const v8, -0xff9934

    new-instance v9, Lgtandroid/universal/MainActivity$100000025;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000025;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1258
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\ud83d\udcac \u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0431\u044b\u0441\u0442\u0440\u043e\u0433\u043e \u043e\u0442\u0432\u0435\u0442\u0430"

    const v8, -0xff559a

    new-instance v9, Lgtandroid/universal/MainActivity$100000026;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000026;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1262
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\ud83d\udd50 \u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0441\u043e\u0431\u044b\u0442\u0438\u0435"

    const v8, -0x559a00

    new-instance v9, Lgtandroid/universal/MainActivity$100000027;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000027;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1265
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\ud83e\udded \u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440\u0430"

    const v8, -0xe1771b

    new-instance v9, Lgtandroid/universal/MainActivity$100000028;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000028;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1268
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\u26a1 \u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0442\u0440\u0438\u0433\u0433\u0435\u0440-\u0441\u043b\u043e\u0432\u0430"

    const v8, -0x1ac6cb

    new-instance v9, Lgtandroid/universal/MainActivity$100000029;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000029;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1272
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\u2694\ufe0f \u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 FamWar"

    const v8, -0x66ff34

    new-instance v9, Lgtandroid/universal/MainActivity$100000030;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000030;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1276
    move-object v5, v0

    move-object v6, v2

    const-string v7, "\ud83d\udd24 \u04229 (\u0430\u0432\u0442\u043e\u043a\u043e\u0440\u0440\u0435\u043a\u0446\u0438\u044f)"

    const v8, -0xff9f9c

    new-instance v9, Lgtandroid/universal/MainActivity$100000031;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000031;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v5, v6, v7, v8, v9}, Lgtandroid/universal/MainActivity;->createEditorButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1280
    new-instance v5, Landroid/view/View;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move-object v7, v0

    invoke-direct {v6, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v3, v5

    .line 1281
    move-object v5, v3

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    const/4 v8, -0x1

    move-object v9, v0

    const/16 v10, 0x5a

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v9

    invoke-direct {v7, v8, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v5, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1282
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method private showErrorLogDialog()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 3437
    move-object v0, p0

    move-object v6, v0

    invoke-static {v6}, Lgtandroid/universal/AppLogger;->readAll(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    move-object v2, v6

    .line 3438
    move-object v6, v2

    if-eqz v6, :cond_0

    move-object v6, v2

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_1

    .line 3439
    :cond_0
    const-string v6, "\u041b\u043e\u0433\u043e\u0432 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442."

    move-object v2, v6

    .line 3442
    :cond_1
    new-instance v6, Landroid/widget/TextView;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v6

    .line 3443
    move-object v6, v3

    move-object v7, v2

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3444
    move-object v6, v3

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextIsSelectable(Z)V

    .line 3445
    move-object v6, v3

    sget-object v7, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 3446
    move-object v6, v3

    const/16 v7, 0xb

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3447
    move-object v6, v3

    move-object v7, v0

    const/16 v8, 0x10

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v7

    move-object v8, v0

    const/16 v9, 0xa

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    move-object v9, v0

    const/16 v10, 0x10

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v9

    move-object v10, v0

    const/16 v11, 0xa

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3449
    new-instance v6, Landroid/widget/ScrollView;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 3450
    move-object v6, v4

    move-object v7, v3

    invoke-virtual {v6, v7}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 3451
    move-object v6, v4

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    const/4 v9, -0x1

    move-object v10, v0

    const/16 v11, 0x190

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3454
    new-instance v6, Landroid/app/AlertDialog$Builder;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v7, "\ud83d\udc1e \u041b\u043e\u0433\u0438 \u043e\u0448\u0438\u0431\u043e\u043a"

    invoke-virtual {v6, v7}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    const-string v7, "\ud83d\udcbe \u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    new-instance v8, Lgtandroid/universal/MainActivity$100000087;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    move-object v10, v0

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity$100000087;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v6, v7, v8}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    const-string v7, "\ud83d\uddd1 \u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c"

    new-instance v8, Lgtandroid/universal/MainActivity$100000088;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    move-object v10, v0

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity$100000088;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v6, v7, v8}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    const-string v7, "\u2716 \u041e\u0442\u043a\u0430\u0437\u0430\u0442\u044c\u0441\u044f"

    const/4 v8, 0x0

    check-cast v8, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v6, v7, v8}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    invoke-virtual {v6}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v6

    return-void
.end method

.method private showEventEditDialog(I)V
    .locals 31
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 1122
    move-object/from16 v2, p0

    move/from16 v3, p1

    move-object/from16 v19, v2

    invoke-direct/range {v19 .. v19}, Lgtandroid/universal/MainActivity;->loadEvents()Lorg/json/JSONArray;

    move-result-object v19

    move-object/from16 v5, v19

    .line 1123
    move/from16 v19, v3

    const/16 v20, 0x0

    move/from16 v0, v19

    move/from16 v1, v20

    if-lt v0, v1, :cond_2

    move-object/from16 v19, v5

    move/from16 v20, v3

    invoke-virtual/range {v19 .. v20}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v19

    :goto_0
    move-object/from16 v6, v19

    .line 1125
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v7, v19

    .line 1126
    move-object/from16 v19, v7

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1127
    move-object/from16 v19, v7

    move-object/from16 v20, v2

    const/16 v21, 0x14

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v20

    move-object/from16 v21, v2

    const/16 v22, 0xe

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    move-object/from16 v22, v2

    const/16 v23, 0x14

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-direct/range {v22 .. v23}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v22

    move-object/from16 v23, v2

    const/16 v24, 0x6

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v23 .. v24}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v23

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 1129
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v8, v19

    .line 1130
    move-object/from16 v19, v8

    const-string v20, "\u0412\u0440\u0435\u043c\u044f (\u041c\u0421\u041a):"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1131
    move-object/from16 v19, v7

    move-object/from16 v20, v8

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1133
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v9, v19

    .line 1134
    move-object/from16 v19, v9

    const/16 v20, 0x0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1135
    move-object/from16 v19, v9

    const/16 v20, 0x10

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1137
    new-instance v19, Landroid/widget/EditText;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v19

    .line 1138
    move-object/from16 v19, v10

    const-string v20, "11:00"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 1139
    move-object/from16 v19, v10

    const v20, 0x80001

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setInputType(I)V

    .line 1141
    move-object/from16 v19, v10

    const/16 v20, 0x11

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setGravity(I)V

    .line 1142
    move-object/from16 v19, v10

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v30, v20

    move-object/from16 v20, v30

    move-object/from16 v21, v30

    const/16 v22, 0x0

    const/16 v23, -0x2

    const/high16 v24, 0x3f800000    # 1.0f

    invoke-direct/range {v21 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1143
    move-object/from16 v19, v2

    move-object/from16 v20, v10

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/MainActivity;->attachEventTimeFormatter(Landroid/widget/EditText;)V

    .line 1144
    move-object/from16 v19, v9

    move-object/from16 v20, v10

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1146
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v11, v19

    .line 1147
    move-object/from16 v19, v11

    const-string v20, "  \u0434\u043e  "

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1148
    move-object/from16 v19, v11

    const/16 v20, 0x10

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1149
    move-object/from16 v19, v9

    move-object/from16 v20, v11

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1151
    new-instance v19, Landroid/widget/EditText;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v12, v19

    .line 1152
    move-object/from16 v19, v12

    const-string v20, "11:15"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 1153
    move-object/from16 v19, v12

    const v20, 0x80001

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setInputType(I)V

    .line 1155
    move-object/from16 v19, v12

    const/16 v20, 0x11

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setGravity(I)V

    .line 1156
    move-object/from16 v19, v12

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v30, v20

    move-object/from16 v20, v30

    move-object/from16 v21, v30

    const/16 v22, 0x0

    const/16 v23, -0x2

    const/high16 v24, 0x3f800000    # 1.0f

    invoke-direct/range {v21 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1157
    move-object/from16 v19, v2

    move-object/from16 v20, v12

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/MainActivity;->attachEventTimeFormatter(Landroid/widget/EditText;)V

    .line 1158
    move-object/from16 v19, v9

    move-object/from16 v20, v12

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1159
    move-object/from16 v19, v7

    move-object/from16 v20, v9

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1161
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v19

    .line 1162
    move-object/from16 v19, v13

    const-string v20, "\u041a\u0430\u043a\u043e\u0439 \u043f\u0440\u0438\u043d\u044f\u0442\u044c \u0440\u0435\u043f\u043e\u0440\u0442:"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1163
    move-object/from16 v19, v13

    const/16 v20, 0x0

    move-object/from16 v21, v2

    const/16 v22, 0xe

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1164
    move-object/from16 v19, v7

    move-object/from16 v20, v13

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1166
    new-instance v19, Landroid/widget/EditText;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v19

    .line 1167
    move-object/from16 v19, v14

    const-string v20, "\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: +   \u0438\u043b\u0438   \u0442\u043f"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 1168
    move-object/from16 v19, v14

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 1169
    move-object/from16 v19, v7

    move-object/from16 v20, v14

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1171
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v19

    .line 1172
    move-object/from16 v19, v15

    const-string v20, "\u041b\u043e\u0432\u0438\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u0440\u0435\u043f\u043e\u0440\u0442, \u043a\u043e\u0442\u043e\u0440\u044b\u0439 \u0432\u044b\u0433\u043b\u044f\u0434\u0438\u0442 \u0420\u041e\u0412\u041d\u041e \u0442\u0430\u043a \u0436\u0435, \u043a\u0430\u043a \u0437\u0434\u0435\u0441\u044c (\u0431\u0435\u0437 \u0440\u0430\u0437\u043d\u0438\u0446\u044b \u0432 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0435).\n\u041d\u0430\u043f\u0440\u0438\u043c\u0435\u0440 \u00ab\u043a\u043a\u043a\u00bb \u043f\u043e\u0439\u043c\u0430\u0435\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u00ab\u043a\u043a\u043a\u00bb, \u043d\u043e \u043d\u0435 \u00ab\u043a\u043a\u043a 322\u00bb."

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1173
    move-object/from16 v19, v15

    const/16 v20, 0xc

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1174
    move-object/from16 v19, v15

    const v20, -0x777778

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1175
    move-object/from16 v19, v15

    const/16 v20, 0x0

    move-object/from16 v21, v2

    const/16 v22, 0x6

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1176
    move-object/from16 v19, v7

    move-object/from16 v20, v15

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1178
    move-object/from16 v19, v6

    if-eqz v19, :cond_0

    .line 1179
    move-object/from16 v19, v10

    move-object/from16 v20, v6

    const-string v21, "from"

    const-string v22, ""

    invoke-virtual/range {v20 .. v22}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1180
    move-object/from16 v19, v12

    move-object/from16 v20, v6

    const-string v21, "to"

    const-string v22, ""

    invoke-virtual/range {v20 .. v22}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1181
    move-object/from16 v19, v14

    move-object/from16 v20, v6

    const-string v21, "keyword"

    const-string v22, ""

    invoke-virtual/range {v20 .. v22}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1184
    :cond_0
    new-instance v19, Landroid/app/AlertDialog$Builder;

    move-object/from16 v30, v19

    move-object/from16 v19, v30

    move-object/from16 v20, v30

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    move/from16 v20, v3

    const/16 v21, 0x0

    move/from16 v0, v20

    move/from16 v1, v21

    if-lt v0, v1, :cond_3

    const-string v20, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0441\u043e\u0431\u044b\u0442\u0438\u0435"

    :goto_1
    invoke-virtual/range {v19 .. v20}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    move-object/from16 v20, v7

    invoke-virtual/range {v19 .. v20}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    const-string v20, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    const/16 v21, 0x0

    check-cast v21, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v19 .. v21}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    const-string v20, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/16 v21, 0x0

    check-cast v21, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v19 .. v21}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    move-object/from16 v16, v19

    .line 1189
    move/from16 v19, v3

    const/16 v20, 0x0

    move/from16 v0, v19

    move/from16 v1, v20

    if-lt v0, v1, :cond_1

    .line 1190
    move-object/from16 v19, v16

    const-string v20, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    new-instance v21, Lgtandroid/universal/MainActivity$100000022;

    move-object/from16 v30, v21

    move-object/from16 v21, v30

    move-object/from16 v22, v30

    move-object/from16 v23, v2

    move/from16 v24, v3

    invoke-direct/range {v22 .. v24}, Lgtandroid/universal/MainActivity$100000022;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual/range {v19 .. v21}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    .line 1203
    :cond_1
    move-object/from16 v19, v16

    invoke-virtual/range {v19 .. v19}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v19

    move-object/from16 v17, v19

    .line 1204
    move-object/from16 v19, v17

    invoke-virtual/range {v19 .. v19}, Landroid/app/Dialog;->show()V

    .line 1205
    move-object/from16 v19, v17

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v19

    new-instance v20, Lgtandroid/universal/MainActivity$100000023;

    move-object/from16 v30, v20

    move-object/from16 v20, v30

    move-object/from16 v21, v30

    move-object/from16 v22, v2

    move-object/from16 v23, v10

    move-object/from16 v24, v12

    move-object/from16 v25, v14

    move/from16 v26, v3

    move-object/from16 v27, v17

    invoke-direct/range {v21 .. v27}, Lgtandroid/universal/MainActivity$100000023;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;ILandroid/app/AlertDialog;)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    .line 1123
    :cond_2
    const/16 v19, 0x0

    check-cast v19, Lorg/json/JSONObject;

    goto/16 :goto_0

    .line 1184
    :cond_3
    const-string v20, "\u041d\u043e\u0432\u043e\u0435 \u0441\u043e\u0431\u044b\u0442\u0438\u0435"

    goto :goto_1
.end method

.method private showEventEditor()V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 986
    move-object/from16 v2, p0

    move-object/from16 v19, v2

    move-object/from16 v0, v19

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->eventEditorDialog:Landroid/app/AlertDialog;

    move-object/from16 v19, v0

    if-eqz v19, :cond_0

    .line 987
    move-object/from16 v19, v2

    :try_start_0
    move-object/from16 v0, v19

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->eventEditorDialog:Landroid/app/AlertDialog;

    move-object/from16 v19, v0

    invoke-virtual/range {v19 .. v19}, Landroid/app/Dialog;->dismiss()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 988
    :goto_0
    move-object/from16 v19, v2

    const/16 v20, 0x0

    check-cast v20, Landroid/app/AlertDialog;

    move-object/from16 v0, v20

    move-object/from16 v1, v19

    iput-object v0, v1, Lgtandroid/universal/MainActivity;->eventEditorDialog:Landroid/app/AlertDialog;

    .line 991
    :cond_0
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v4, v19

    .line 992
    move-object/from16 v19, v4

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 993
    move-object/from16 v19, v4

    move-object/from16 v20, v2

    const/16 v21, 0xe

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v20

    move-object/from16 v21, v2

    const/16 v22, 0xa

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    move-object/from16 v22, v2

    const/16 v23, 0xe

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-direct/range {v22 .. v23}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v22

    move-object/from16 v23, v2

    const/16 v24, 0xa

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v23 .. v24}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v23

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 995
    move-object/from16 v19, v2

    invoke-direct/range {v19 .. v19}, Lgtandroid/universal/MainActivity;->loadEvents()Lorg/json/JSONArray;

    move-result-object v19

    move-object/from16 v5, v19

    .line 997
    move-object/from16 v19, v5

    invoke-virtual/range {v19 .. v19}, Lorg/json/JSONArray;->length()I

    move-result v19

    const/16 v20, 0x0

    move/from16 v0, v19

    move/from16 v1, v20

    if-ne v0, v1, :cond_1

    .line 998
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v19

    .line 999
    move-object/from16 v19, v6

    const-string v20, "\u0421\u043e\u0431\u044b\u0442\u0438\u0439 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442. \u0414\u043e\u0431\u0430\u0432\u044c \u043f\u0435\u0440\u0432\u043e\u0435 \u043a\u043d\u043e\u043f\u043a\u043e\u0439 \u043d\u0438\u0436\u0435."

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1000
    move-object/from16 v19, v6

    const v20, -0x777778

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1001
    move-object/from16 v19, v6

    const/16 v20, 0x0

    move-object/from16 v21, v2

    const/16 v22, 0xa

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    const/16 v22, 0x0

    move-object/from16 v23, v2

    const/16 v24, 0xe

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v23 .. v24}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v23

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1002
    move-object/from16 v19, v4

    move-object/from16 v20, v6

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1005
    :cond_1
    const/16 v19, 0x0

    move/from16 v6, v19

    :goto_1
    move/from16 v19, v6

    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Lorg/json/JSONArray;->length()I

    move-result v20

    move/from16 v0, v19

    move/from16 v1, v20

    if-lt v0, v1, :cond_2

    .line 1101
    new-instance v19, Landroid/widget/Button;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v19

    .line 1102
    move-object/from16 v19, v6

    const-string v20, "\u2795 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u043e\u0431\u044b\u0442\u0438\u0435"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1103
    move-object/from16 v19, v6

    const v20, -0xff5600

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1104
    move-object/from16 v19, v6

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1105
    move-object/from16 v19, v6

    const/16 v20, 0x0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1106
    move-object/from16 v19, v6

    new-instance v20, Lgtandroid/universal/MainActivity$100000021;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity$100000021;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1109
    move-object/from16 v19, v4

    move-object/from16 v20, v6

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1111
    new-instance v19, Landroid/widget/ScrollView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object/from16 v7, v19

    .line 1112
    move-object/from16 v19, v7

    move-object/from16 v20, v4

    invoke-virtual/range {v19 .. v20}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1114
    move-object/from16 v19, v2

    new-instance v20, Landroid/app/AlertDialog$Builder;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    invoke-direct/range {v21 .. v22}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v21, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0441\u043e\u0431\u044b\u0442\u0438\u0435"

    invoke-virtual/range {v20 .. v21}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v20

    move-object/from16 v21, v7

    invoke-virtual/range {v20 .. v21}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v20

    const-string v21, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/16 v22, 0x0

    check-cast v22, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v20 .. v22}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v20

    move-object/from16 v0, v20

    move-object/from16 v1, v19

    iput-object v0, v1, Lgtandroid/universal/MainActivity;->eventEditorDialog:Landroid/app/AlertDialog;

    return-void

    .line 987
    :catch_0
    move-exception v19

    move-object/from16 v4, v19

    goto/16 :goto_0

    .line 1006
    :cond_2
    move/from16 v19, v6

    move/from16 v7, v19

    .line 1007
    move-object/from16 v19, v5

    move/from16 v20, v6

    invoke-virtual/range {v19 .. v20}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v19

    move-object/from16 v8, v19

    .line 1008
    move-object/from16 v19, v8

    if-nez v19, :cond_3

    .line 1005
    :goto_2
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_1

    .line 1010
    :cond_3
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v9, v19

    .line 1011
    move-object/from16 v19, v9

    const/16 v20, 0x0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1012
    move-object/from16 v19, v9

    const/16 v20, 0x10

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 1013
    move-object/from16 v19, v9

    move-object/from16 v20, v2

    const/16 v21, 0xc

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v20

    move-object/from16 v21, v2

    const/16 v22, 0xa

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    move-object/from16 v22, v2

    const/16 v23, 0xc

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-direct/range {v22 .. v23}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v22

    move-object/from16 v23, v2

    const/16 v24, 0xa

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v23 .. v24}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v23

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 1014
    new-instance v19, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    invoke-direct/range {v20 .. v20}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v10, v19

    .line 1015
    move-object/from16 v19, v10

    const v20, -0xdcd8d2

    invoke-virtual/range {v19 .. v20}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1016
    move-object/from16 v19, v10

    move-object/from16 v20, v2

    const/16 v21, 0xc

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v20

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 1017
    move-object/from16 v19, v9

    move-object/from16 v20, v10

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1018
    new-instance v19, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, -0x1

    const/16 v22, -0x2

    invoke-direct/range {v20 .. v22}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v11, v19

    .line 1020
    move-object/from16 v19, v11

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v22, 0x0

    move-object/from16 v23, v2

    const/16 v24, 0x8

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v23 .. v24}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v23

    invoke-virtual/range {v19 .. v23}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 1021
    move-object/from16 v19, v9

    move-object/from16 v20, v11

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1023
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v12, v19

    .line 1024
    move-object/from16 v19, v12

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1025
    move-object/from16 v19, v12

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, 0x0

    const/16 v23, -0x2

    const/high16 v24, 0x3f800000    # 1.0f

    invoke-direct/range {v21 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1027
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v19

    .line 1028
    move-object/from16 v19, v13

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v22, Ljava/lang/StringBuffer;

    move-object/from16 v26, v22

    move-object/from16 v22, v26

    move-object/from16 v23, v26

    invoke-direct/range {v23 .. v23}, Ljava/lang/StringBuffer;-><init>()V

    const-string v23, "\ud83d\udd50 "

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    move-object/from16 v23, v8

    const-string v24, "from"

    const-string v25, ""

    invoke-virtual/range {v23 .. v25}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    const-string v22, " \u0434\u043e "

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    move-object/from16 v21, v8

    const-string v22, "to"

    const-string v23, ""

    invoke-virtual/range {v21 .. v23}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1029
    move-object/from16 v19, v13

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1030
    move-object/from16 v19, v13

    const/16 v20, 0x10

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1031
    move-object/from16 v19, v13

    const/16 v20, 0x0

    check-cast v20, Landroid/graphics/Typeface;

    const/16 v21, 0x1

    invoke-virtual/range {v19 .. v21}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 1032
    move-object/from16 v19, v12

    move-object/from16 v20, v13

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1034
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v19

    .line 1035
    move-object/from16 v19, v14

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    const-string v22, "\u0420\u0435\u043f\u043e\u0440\u0442: "

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    move-object/from16 v22, v8

    const-string v23, "keyword"

    const-string v24, ""

    invoke-virtual/range {v22 .. v24}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    const-string v21, "   \u270f\ufe0f \u043d\u0430\u0436\u043c\u0438, \u0447\u0442\u043e\u0431\u044b \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u044c"

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1036
    move-object/from16 v19, v14

    const v20, -0x655b4e

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1037
    move-object/from16 v19, v14

    const/16 v20, 0xc

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1038
    move-object/from16 v19, v12

    move-object/from16 v20, v14

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1040
    move-object/from16 v19, v12

    new-instance v20, Lgtandroid/universal/MainActivity$100000017;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    move/from16 v23, v7

    invoke-direct/range {v21 .. v23}, Lgtandroid/universal/MainActivity$100000017;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1043
    move-object/from16 v19, v9

    move-object/from16 v20, v12

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1045
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v19

    .line 1046
    move-object/from16 v19, v15

    const-string v20, "\ud83d\uddd1"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1047
    move-object/from16 v19, v15

    const/16 v20, 0x14

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1048
    move-object/from16 v19, v15

    const/16 v20, 0x11

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setGravity(I)V

    .line 1049
    move-object/from16 v19, v15

    move-object/from16 v20, v2

    const/16 v21, 0x8

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v20

    move-object/from16 v21, v2

    const/16 v22, 0x4

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    move-object/from16 v22, v2

    const/16 v23, 0x8

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-direct/range {v22 .. v23}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v22

    move-object/from16 v23, v2

    const/16 v24, 0x4

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v23 .. v24}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v23

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1050
    new-instance v19, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, -0x2

    const/16 v22, -0x2

    invoke-direct/range {v20 .. v22}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v16, v19

    .line 1052
    move-object/from16 v19, v16

    move-object/from16 v20, v2

    const/16 v21, 0x4

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v20

    const/16 v21, 0x0

    move-object/from16 v22, v2

    const/16 v23, 0x8

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-direct/range {v22 .. v23}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v22

    const/16 v23, 0x0

    invoke-virtual/range {v19 .. v23}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 1053
    move-object/from16 v19, v15

    move-object/from16 v20, v16

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1054
    move-object/from16 v19, v15

    new-instance v20, Lgtandroid/universal/MainActivity$100000019;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    move/from16 v23, v7

    invoke-direct/range {v21 .. v23}, Lgtandroid/universal/MainActivity$100000019;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1074
    move-object/from16 v19, v9

    move-object/from16 v20, v15

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1076
    new-instance v19, Lgtandroid/universal/MainActivity$EventToggle;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity$EventToggle;-><init>(Landroid/content/Context;)V

    move-object/from16 v17, v19

    .line 1077
    move-object/from16 v19, v17

    move-object/from16 v20, v8

    const-string v21, "enabled"

    const/16 v22, 0x0

    invoke-virtual/range {v20 .. v22}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v20

    invoke-virtual/range {v19 .. v20}, Lgtandroid/universal/MainActivity$EventToggle;->setChecked(Z)V

    .line 1078
    move-object/from16 v19, v17

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    const/16 v23, 0x38

    move/from16 v0, v23

    int-to-float v0, v0

    move/from16 v23, v0

    invoke-direct/range {v22 .. v23}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v22

    move-object/from16 v23, v2

    const/16 v24, 0x1e

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v23 .. v24}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v23

    invoke-direct/range {v21 .. v23}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1079
    move-object/from16 v19, v17

    new-instance v20, Lgtandroid/universal/MainActivity$100000020;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    move-object/from16 v23, v17

    move/from16 v24, v7

    invoke-direct/range {v21 .. v24}, Lgtandroid/universal/MainActivity$100000020;-><init>(Lgtandroid/universal/MainActivity;Lgtandroid/universal/MainActivity$EventToggle;I)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1096
    move-object/from16 v19, v9

    move-object/from16 v20, v17

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1098
    move-object/from16 v19, v4

    move-object/from16 v20, v9

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    goto/16 :goto_2
.end method

.method private showFamWarEditor()V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2801
    move-object v0, p0

    new-instance v6, Landroid/widget/LinearLayout;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v6

    .line 2802
    move-object v6, v2

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2803
    move-object v6, v2

    const/16 v7, 0x14

    const/16 v8, 0x14

    const/16 v9, 0x14

    const/16 v10, 0x14

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 2805
    new-instance v6, Landroid/widget/Button;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v3, v6

    .line 2806
    move-object v6, v3

    const-string v7, "\u2795 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043a\u043e\u043c\u0430\u043d\u0434\u0443 FamWar"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2807
    move-object v6, v3

    const v7, -0xff5600

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2808
    move-object v6, v3

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2809
    move-object v6, v3

    new-instance v7, Lgtandroid/universal/MainActivity$100000074;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity$100000074;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2814
    move-object v6, v2

    move-object v7, v3

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2816
    new-instance v6, Landroid/widget/Button;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 2817
    move-object v6, v4

    const-string v7, "\ud83d\udccb \u0421\u043f\u0438\u0441\u043e\u043a \u043a\u043e\u043c\u0430\u043d\u0434 FamWar"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2818
    move-object v6, v4

    const v7, -0xff9934

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2819
    move-object v6, v4

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2820
    move-object v6, v4

    new-instance v7, Lgtandroid/universal/MainActivity$100000075;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity$100000075;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2826
    move-object v6, v2

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2828
    new-instance v6, Landroid/app/AlertDialog$Builder;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v7, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 FamWar"

    invoke-virtual {v6, v7}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    move-object v7, v2

    invoke-virtual {v6, v7}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    const-string v7, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/4 v8, 0x0

    check-cast v8, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v6, v7, v8}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    invoke-virtual {v6}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v6

    return-void
.end method

.method private showFamWarList()V
    .locals 36
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2905
    move-object/from16 v2, p0

    move-object/from16 v25, v2

    :try_start_0
    move-object/from16 v0, v25

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v25, v0

    const-string v26, "famwar_commands"

    const-string v27, "[]"

    invoke-interface/range {v25 .. v27}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    move-object/from16 v4, v25

    .line 2906
    new-instance v25, Lorg/json/JSONArray;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v4

    invoke-direct/range {v26 .. v27}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object/from16 v5, v25

    .line 2908
    move-object/from16 v25, v5

    invoke-virtual/range {v25 .. v25}, Lorg/json/JSONArray;->length()I

    move-result v25

    const/16 v26, 0x0

    move/from16 v0, v25

    move/from16 v1, v26

    if-ne v0, v1, :cond_0

    .line 2909
    new-instance v25, Landroid/app/AlertDialog$Builder;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v26, "\u041a\u043e\u043c\u0430\u043d\u0434\u044b FamWar"

    invoke-virtual/range {v25 .. v26}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v25

    const-string v26, "\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442"

    invoke-virtual/range {v25 .. v26}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v25

    const-string v26, "OK"

    const/16 v27, 0x0

    check-cast v27, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v25 .. v27}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v25

    .line 3002
    :goto_0
    return-void

    .line 2916
    :cond_0
    new-instance v25, Landroid/widget/ScrollView;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v25

    .line 2917
    new-instance v25, Landroid/widget/LinearLayout;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v7, v25

    .line 2918
    move-object/from16 v25, v7

    const/16 v26, 0x1

    invoke-virtual/range {v25 .. v26}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2919
    move-object/from16 v25, v7

    const/16 v26, 0xa

    const/16 v27, 0xa

    const/16 v28, 0xa

    const/16 v29, 0xa

    invoke-virtual/range {v25 .. v29}, Landroid/view/View;->setPadding(IIII)V

    .line 2921
    const/16 v25, 0x0

    move/from16 v8, v25

    :goto_1
    move/from16 v25, v8

    move-object/from16 v26, v5

    invoke-virtual/range {v26 .. v26}, Lorg/json/JSONArray;->length()I

    move-result v26

    move/from16 v0, v25

    move/from16 v1, v26

    if-lt v0, v1, :cond_1

    .line 2993
    move-object/from16 v25, v6

    move-object/from16 v26, v7

    invoke-virtual/range {v25 .. v26}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2995
    new-instance v25, Landroid/app/AlertDialog$Builder;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v26, "\u2550\u2550 \u041a\u041e\u041c\u0410\u041d\u0414\u042b FAMWAR \u2550\u2550"

    invoke-virtual/range {v25 .. v26}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v25

    move-object/from16 v26, v6

    invoke-virtual/range {v25 .. v26}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v25

    const-string v26, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/16 v27, 0x0

    check-cast v27, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v25 .. v27}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v25

    .line 3002
    :goto_2
    goto :goto_0

    .line 2922
    :cond_1
    move/from16 v25, v8

    move/from16 v9, v25

    .line 2923
    move-object/from16 v25, v5

    move/from16 v26, v8

    invoke-virtual/range {v25 .. v26}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v25

    move-object/from16 v10, v25

    .line 2924
    move-object/from16 v25, v10

    const-string v26, "name"

    new-instance v27, Ljava/lang/StringBuffer;

    move-object/from16 v35, v27

    move-object/from16 v27, v35

    move-object/from16 v28, v35

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuffer;-><init>()V

    const-string v28, "\u041a\u043e\u043c\u0430\u043d\u0434\u0430 "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    move/from16 v28, v8

    const/16 v29, 0x1

    add-int/lit8 v28, v28, 0x1

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v27

    invoke-virtual/range {v25 .. v27}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    move-object/from16 v11, v25

    .line 2925
    move-object/from16 v25, v10

    const-string v26, "command"

    const-string v27, ""

    invoke-virtual/range {v25 .. v27}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    move-object/from16 v12, v25

    .line 2926
    move-object/from16 v25, v10

    const-string v26, "time"

    const-string v27, ""

    invoke-virtual/range {v25 .. v27}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    move-object/from16 v13, v25

    .line 2927
    move-object/from16 v25, v10

    const-string v26, "reason"

    const-string v27, ""

    invoke-virtual/range {v25 .. v27}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    move-object/from16 v14, v25

    .line 2928
    move-object/from16 v25, v10

    const-string v26, "minlevel"

    const-string v27, "1"

    invoke-virtual/range {v25 .. v27}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v25

    move-object/from16 v15, v25

    .line 2930
    new-instance v25, Landroid/widget/LinearLayout;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v16, v25

    .line 2931
    move-object/from16 v25, v16

    const/16 v26, 0x1

    invoke-virtual/range {v25 .. v26}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2932
    move-object/from16 v25, v16

    const/16 v26, 0xa

    const/16 v27, 0xa

    const/16 v28, 0xa

    const/16 v29, 0xa

    invoke-virtual/range {v25 .. v29}, Landroid/view/View;->setPadding(IIII)V

    .line 2933
    move-object/from16 v25, v16

    const v26, -0xe4e2d8

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2935
    new-instance v25, Ljava/lang/StringBuilder;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    invoke-direct/range {v26 .. v26}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v17, v25

    .line 2936
    move-object/from16 v25, v17

    move/from16 v26, v8

    const/16 v27, 0x1

    add-int/lit8 v26, v26, 0x1

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, ". "

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v26, v11

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "\n"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    .line 2937
    move-object/from16 v25, v17

    const-string v26, "\ud83d\udcdd \u041a\u043e\u043c\u0430\u043d\u0434\u0430: "

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v26, v12

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "\n"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    .line 2938
    move-object/from16 v25, v13

    invoke-virtual/range {v25 .. v25}, Ljava/lang/String;->isEmpty()Z

    move-result v25

    if-nez v25, :cond_2

    move-object/from16 v25, v17

    const-string v26, "\u23f1\ufe0f \u0412\u0440\u0435\u043c\u044f: "

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v26, v13

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "\n"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    .line 2939
    :cond_2
    move-object/from16 v25, v14

    invoke-virtual/range {v25 .. v25}, Ljava/lang/String;->isEmpty()Z

    move-result v25

    if-nez v25, :cond_3

    move-object/from16 v25, v17

    const-string v26, "\ud83d\udcac \u041f\u0440\u0438\u0447\u0438\u043d\u0430: "

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v26, v14

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    const-string v26, "\n"

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    .line 2940
    :cond_3
    move-object/from16 v25, v17

    const-string v26, "\ud83d\udc51 \u041c\u0438\u043d. \u0443\u0440: "

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    move-object/from16 v26, v15

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v25

    .line 2942
    new-instance v25, Landroid/widget/TextView;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v18, v25

    .line 2943
    move-object/from16 v25, v18

    move-object/from16 v26, v17

    invoke-virtual/range {v26 .. v26}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v26

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2944
    move-object/from16 v25, v18

    const v26, -0x12120b

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2945
    move-object/from16 v25, v16

    move-object/from16 v26, v18

    invoke-virtual/range {v25 .. v26}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2947
    new-instance v25, Landroid/widget/LinearLayout;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v19, v25

    .line 2948
    move-object/from16 v25, v19

    const/16 v26, 0x0

    invoke-virtual/range {v25 .. v26}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2949
    move-object/from16 v25, v19

    const/16 v26, 0x0

    const/16 v27, 0xa

    const/16 v28, 0x0

    const/16 v29, 0x0

    invoke-virtual/range {v25 .. v29}, Landroid/view/View;->setPadding(IIII)V

    .line 2951
    new-instance v25, Landroid/widget/Button;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v20, v25

    .line 2952
    move-object/from16 v25, v20

    const-string v26, "\u270f\ufe0f \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c"

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2953
    move-object/from16 v25, v20

    const v26, -0xff9934

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2954
    move-object/from16 v25, v20

    const/16 v26, -0x1

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2955
    move-object/from16 v25, v20

    new-instance v26, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v35, v26

    move-object/from16 v26, v35

    move-object/from16 v27, v35

    const/16 v28, 0x0

    const/16 v29, -0x2

    const/16 v30, 0x1

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    invoke-direct/range {v27 .. v30}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2956
    move-object/from16 v25, v20

    new-instance v26, Lgtandroid/universal/MainActivity$100000077;

    move-object/from16 v35, v26

    move-object/from16 v26, v35

    move-object/from16 v27, v35

    move-object/from16 v28, v2

    move/from16 v29, v9

    move-object/from16 v30, v11

    move-object/from16 v31, v12

    move-object/from16 v32, v13

    move-object/from16 v33, v14

    move-object/from16 v34, v15

    invoke-direct/range {v27 .. v34}, Lgtandroid/universal/MainActivity$100000077;-><init>(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2962
    new-instance v25, Landroid/widget/Button;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v21, v25

    .line 2963
    move-object/from16 v25, v21

    const-string v26, "\ud83d\uddd1\ufe0f \u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2964
    move-object/from16 v25, v21

    const/high16 v26, -0x340000

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2965
    move-object/from16 v25, v21

    const/16 v26, -0x1

    invoke-virtual/range {v25 .. v26}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2966
    move-object/from16 v25, v21

    new-instance v26, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v35, v26

    move-object/from16 v26, v35

    move-object/from16 v27, v35

    const/16 v28, 0x0

    const/16 v29, -0x2

    const/16 v30, 0x1

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    invoke-direct/range {v27 .. v30}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2967
    move-object/from16 v25, v21

    new-instance v26, Lgtandroid/universal/MainActivity$100000078;

    move-object/from16 v35, v26

    move-object/from16 v26, v35

    move-object/from16 v27, v35

    move-object/from16 v28, v2

    move/from16 v29, v9

    invoke-direct/range {v27 .. v29}, Lgtandroid/universal/MainActivity$100000078;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2975
    move-object/from16 v25, v19

    move-object/from16 v26, v20

    invoke-virtual/range {v25 .. v26}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2977
    new-instance v25, Landroid/view/View;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v22, v25

    .line 2978
    move-object/from16 v25, v22

    new-instance v26, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v35, v26

    move-object/from16 v26, v35

    move-object/from16 v27, v35

    const/16 v28, 0xa

    const/16 v29, -0x1

    invoke-direct/range {v27 .. v29}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2979
    move-object/from16 v25, v19

    move-object/from16 v26, v22

    invoke-virtual/range {v25 .. v26}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2981
    move-object/from16 v25, v19

    move-object/from16 v26, v21

    invoke-virtual/range {v25 .. v26}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2982
    move-object/from16 v25, v16

    move-object/from16 v26, v19

    invoke-virtual/range {v25 .. v26}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2983
    move-object/from16 v25, v7

    move-object/from16 v26, v16

    invoke-virtual/range {v25 .. v26}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2985
    move/from16 v25, v8

    move-object/from16 v26, v5

    invoke-virtual/range {v26 .. v26}, Lorg/json/JSONArray;->length()I

    move-result v26

    const/16 v27, 0x1

    add-int/lit8 v26, v26, -0x1

    move/from16 v0, v25

    move/from16 v1, v26

    if-ge v0, v1, :cond_4

    .line 2986
    new-instance v25, Landroid/view/View;

    move-object/from16 v35, v25

    move-object/from16 v25, v35

    move-object/from16 v26, v35

    move-object/from16 v27, v2

    invoke-direct/range {v26 .. v27}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v23, v25

    .line 2987
    move-object/from16 v25, v23

    new-instance v26, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v35, v26

    move-object/from16 v26, v35

    move-object/from16 v27, v35

    const/16 v28, -0x1

    const/16 v29, 0x5

    invoke-direct/range {v27 .. v29}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v25 .. v26}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2989
    move-object/from16 v25, v7

    move-object/from16 v26, v23

    invoke-virtual/range {v25 .. v26}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2921
    :cond_4
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_1

    .line 2995
    :catch_0
    move-exception v25

    move-object/from16 v4, v25

    .line 3002
    move-object/from16 v25, v2

    new-instance v26, Ljava/lang/StringBuffer;

    move-object/from16 v35, v26

    move-object/from16 v26, v35

    move-object/from16 v27, v35

    invoke-direct/range {v27 .. v27}, Ljava/lang/StringBuffer;-><init>()V

    const-string v27, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v26

    move-object/from16 v27, v4

    invoke-virtual/range {v27 .. v27}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v27

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v26

    invoke-virtual/range {v26 .. v26}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v26

    const/16 v27, 0x0

    invoke-static/range {v25 .. v27}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Landroid/widget/Toast;->show()V

    goto/16 :goto_2
.end method

.method private showKeyboardSizeDialog()V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2745
    move-object/from16 v0, p0

    const/16 v8, 0x8

    new-array v8, v8, [Ljava/lang/String;

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x0

    const-string v11, "50%"

    aput-object v11, v9, v10

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x1

    const-string v11, "80%"

    aput-object v11, v9, v10

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x2

    const-string v11, "100%"

    aput-object v11, v9, v10

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x3

    const-string v11, "120%"

    aput-object v11, v9, v10

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x4

    const-string v11, "140%"

    aput-object v11, v9, v10

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x5

    const-string v11, "160%"

    aput-object v11, v9, v10

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x6

    const-string v11, "180%"

    aput-object v11, v9, v10

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    const/4 v10, 0x7

    const-string v11, "200%"

    aput-object v11, v9, v10

    move-object v2, v8

    .line 2746
    const/16 v8, 0x8

    new-array v8, v8, [I

    fill-array-data v8, :array_0

    move-object v3, v8

    .line 2747
    move-object v8, v0

    const-string v9, "keyboard_size"

    const/4 v10, 0x1

    invoke-direct {v8, v9, v10}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v8

    move v4, v8

    .line 2748
    const/4 v8, 0x2

    move v5, v8

    .line 2749
    const/4 v8, 0x0

    move v6, v8

    :goto_0
    move v8, v6

    move-object v9, v3

    array-length v9, v9

    if-lt v8, v9, :cond_0

    .line 2753
    new-instance v8, Landroid/app/AlertDialog$Builder;

    move-object/from16 v16, v8

    move-object/from16 v8, v16

    move-object/from16 v9, v16

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v9, "\u2550\u2550 \u0420\u0410\u0417\u041c\u0415\u0420 \u041a\u041b\u0410\u0412\u0418\u0410\u0422\u0423\u0420\u042b \u2550\u2550"

    invoke-virtual {v8, v9}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v8

    move-object v9, v2

    move v10, v5

    new-instance v11, Lgtandroid/universal/MainActivity$100000072;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    move-object v14, v3

    move-object v15, v2

    invoke-direct {v12, v13, v14, v15}, Lgtandroid/universal/MainActivity$100000072;-><init>(Lgtandroid/universal/MainActivity;[I[Ljava/lang/String;)V

    invoke-virtual {v8, v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v8

    const-string v9, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v10, 0x0

    check-cast v10, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v8, v9, v10}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v8

    invoke-virtual {v8}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v8

    return-void

    .line 2750
    :cond_0
    move-object v8, v3

    move v9, v6

    aget v8, v8, v9

    move v9, v4

    if-ne v8, v9, :cond_1

    move v8, v6

    move v5, v8

    .line 2749
    :cond_1
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    .line 2746
    nop

    :array_0
    .array-data 4
        0x7
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
    .end array-data
.end method

.method private showMainScreen()V
    .locals 44
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 406
    move-object/from16 v3, p0

    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    invoke-virtual/range {v36 .. v36}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 408
    move-object/from16 v36, v3

    const/16 v37, 0x14

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-direct/range {v36 .. v37}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v36

    move/from16 v5, v36

    .line 410
    new-instance v36, Landroid/widget/LinearLayout;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v36

    .line 411
    move-object/from16 v36, v6

    const/16 v37, 0x1

    invoke-virtual/range {v36 .. v37}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 412
    move-object/from16 v36, v6

    const/16 v37, 0x11

    invoke-virtual/range {v36 .. v37}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 413
    move-object/from16 v36, v6

    move/from16 v37, v5

    move-object/from16 v38, v3

    const/16 v39, 0x1c

    move/from16 v0, v39

    int-to-float v0, v0

    move/from16 v39, v0

    invoke-direct/range {v38 .. v39}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v38

    move/from16 v39, v5

    move-object/from16 v40, v3

    const/16 v41, 0x16

    move/from16 v0, v41

    int-to-float v0, v0

    move/from16 v41, v0

    invoke-direct/range {v40 .. v41}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v40

    invoke-virtual/range {v36 .. v40}, Landroid/view/View;->setPadding(IIII)V

    .line 414
    new-instance v36, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    const/16 v38, -0x1

    const/16 v39, -0x2

    invoke-direct/range {v37 .. v39}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v7, v36

    .line 416
    move-object/from16 v36, v7

    move-object/from16 v37, v3

    const/16 v38, 0x10

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move-object/from16 v38, v3

    const/16 v39, 0x10

    move/from16 v0, v39

    int-to-float v0, v0

    move/from16 v39, v0

    invoke-direct/range {v38 .. v39}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v38

    move-object/from16 v39, v3

    const/16 v40, 0x10

    move/from16 v0, v40

    int-to-float v0, v0

    move/from16 v40, v0

    invoke-direct/range {v39 .. v40}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v39

    move-object/from16 v40, v3

    const/16 v41, 0x8

    move/from16 v0, v41

    int-to-float v0, v0

    move/from16 v41, v0

    invoke-direct/range {v40 .. v41}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v40

    invoke-virtual/range {v36 .. v40}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 417
    move-object/from16 v36, v6

    move-object/from16 v37, v7

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 418
    new-instance v36, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    invoke-direct/range {v37 .. v37}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v8, v36

    .line 419
    move-object/from16 v36, v8

    const v37, -0xedebe3

    invoke-virtual/range {v36 .. v37}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 420
    move-object/from16 v36, v8

    move-object/from16 v37, v3

    const/16 v38, 0x12

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 421
    move-object/from16 v36, v8

    move-object/from16 v37, v3

    const/high16 v38, 0x3fc00000    # 1.5f

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move-object/from16 v38, v3

    const v39, -0xff1a01

    const/16 v40, 0x5a

    invoke-direct/range {v38 .. v40}, Lgtandroid/universal/MainActivity;->withAlpha(II)I

    move-result v38

    invoke-virtual/range {v36 .. v38}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 422
    move-object/from16 v36, v6

    move-object/from16 v37, v8

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 423
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    move-object/from16 v37, v6

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 425
    new-instance v36, Landroid/widget/TextView;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v9, v36

    .line 426
    move-object/from16 v36, v9

    const-string v37, "\u26a1 UNIVERSAL GTANDROID"

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 427
    move-object/from16 v36, v9

    const/16 v37, 0x16

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setTextSize(F)V

    .line 428
    move-object/from16 v36, v9

    const/16 v37, 0x11

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setGravity(I)V

    .line 429
    move-object/from16 v36, v9

    const/16 v37, 0x0

    check-cast v37, Landroid/graphics/Typeface;

    const/16 v38, 0x1

    invoke-virtual/range {v36 .. v38}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 430
    move-object/from16 v36, v9

    const v37, 0x3cf5c28f    # 0.03f

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 431
    move-object/from16 v36, v3

    move-object/from16 v37, v9

    const v38, -0xff1a01

    invoke-direct/range {v36 .. v38}, Lgtandroid/universal/MainActivity;->applyNeonGlow(Landroid/widget/TextView;I)V

    .line 432
    move-object/from16 v36, v6

    move-object/from16 v37, v9

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 434
    new-instance v36, Landroid/widget/TextView;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v36

    .line 435
    move-object/from16 v36, v10

    const/16 v37, 0x11

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setGravity(I)V

    .line 436
    move-object/from16 v36, v10

    const/16 v37, 0xe

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setTextSize(F)V

    .line 437
    move-object/from16 v36, v10

    move-object/from16 v37, v3

    const/16 v38, 0x12

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move-object/from16 v38, v3

    const/16 v39, 0x8

    move/from16 v0, v39

    int-to-float v0, v0

    move/from16 v39, v0

    invoke-direct/range {v38 .. v39}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v38

    move-object/from16 v39, v3

    const/16 v40, 0x12

    move/from16 v0, v40

    int-to-float v0, v0

    move/from16 v40, v0

    invoke-direct/range {v39 .. v40}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v39

    move-object/from16 v40, v3

    const/16 v41, 0x8

    move/from16 v0, v41

    int-to-float v0, v0

    move/from16 v41, v0

    invoke-direct/range {v40 .. v41}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v40

    invoke-virtual/range {v36 .. v40}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 438
    new-instance v36, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    const/16 v38, -0x2

    const/16 v39, -0x2

    invoke-direct/range {v37 .. v39}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v11, v36

    .line 440
    move-object/from16 v36, v11

    move-object/from16 v37, v3

    const/16 v38, 0xe

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 441
    move-object/from16 v36, v10

    move-object/from16 v37, v11

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 443
    move-object/from16 v36, v3

    const-string v37, "GTAndroidSecurity"

    const/16 v38, 0x0

    invoke-virtual/range {v36 .. v38}, Landroid/content/ContextWrapper;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v36

    move-object/from16 v12, v36

    .line 444
    move-object/from16 v36, v12

    const-string v37, "auth_expiry"

    const/16 v38, 0x0

    move/from16 v0, v38

    int-to-long v0, v0

    move-wide/from16 v38, v0

    invoke-interface/range {v36 .. v39}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v36

    move-wide/from16 v13, v36

    .line 445
    move-object/from16 v36, v12

    const-string v37, "auth_status"

    const-string v38, "bronze"

    invoke-interface/range {v36 .. v38}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v36

    move-object/from16 v15, v36

    .line 447
    const-string v36, "premium"

    move-object/from16 v37, v15

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_0

    .line 449
    move-object/from16 v36, v10

    const-string v37, "PREMIUM \u267e\ufe0f  \u0411\u0435\u0441\u043a\u043e\u043d\u0435\u0447\u043d\u043e"

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 450
    const/16 v36, -0x2900

    move/from16 v16, v36

    .line 471
    :goto_0
    move-object/from16 v36, v10

    move/from16 v37, v16

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setTextColor(I)V

    .line 472
    new-instance v36, Landroid/graphics/drawable/GradientDrawable;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    invoke-direct/range {v37 .. v37}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object/from16 v17, v36

    .line 473
    move-object/from16 v36, v17

    move-object/from16 v37, v3

    move/from16 v38, v16

    const/16 v39, 0x1e

    invoke-direct/range {v37 .. v39}, Lgtandroid/universal/MainActivity;->withAlpha(II)I

    move-result v37

    invoke-virtual/range {v36 .. v37}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 474
    move-object/from16 v36, v17

    move-object/from16 v37, v3

    const/16 v38, 0x14

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 475
    move-object/from16 v36, v17

    move-object/from16 v37, v3

    const/16 v38, 0x1

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move-object/from16 v38, v3

    move/from16 v39, v16

    const/16 v40, 0xa0

    invoke-direct/range {v38 .. v40}, Lgtandroid/universal/MainActivity;->withAlpha(II)I

    move-result v38

    invoke-virtual/range {v36 .. v38}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 476
    move-object/from16 v36, v10

    move-object/from16 v37, v17

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 477
    move-object/from16 v36, v6

    move-object/from16 v37, v10

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 479
    new-instance v36, Landroid/widget/LinearLayout;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v18, v36

    .line 480
    move-object/from16 v36, v18

    const/16 v37, 0x0

    invoke-virtual/range {v36 .. v37}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 481
    new-instance v36, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    const/16 v38, -0x1

    const/16 v39, -0x2

    invoke-direct/range {v37 .. v39}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v19, v36

    .line 483
    move-object/from16 v36, v19

    move-object/from16 v37, v3

    const/16 v38, 0x10

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move-object/from16 v38, v3

    const/16 v39, 0xe

    move/from16 v0, v39

    int-to-float v0, v0

    move/from16 v39, v0

    invoke-direct/range {v38 .. v39}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v38

    move-object/from16 v39, v3

    const/16 v40, 0x10

    move/from16 v0, v40

    int-to-float v0, v0

    move/from16 v40, v0

    invoke-direct/range {v39 .. v40}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v39

    move-object/from16 v40, v3

    const/16 v41, 0x8

    move/from16 v0, v41

    int-to-float v0, v0

    move/from16 v41, v0

    invoke-direct/range {v40 .. v41}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v40

    invoke-virtual/range {v36 .. v40}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 484
    move-object/from16 v36, v18

    move-object/from16 v37, v19

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 485
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    move-object/from16 v37, v18

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 487
    new-instance v36, Lgtandroid/universal/MainActivity$100000007;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity$100000007;-><init>(Lgtandroid/universal/MainActivity;)V

    move-object/from16 v20, v36

    .line 495
    new-instance v36, Lgtandroid/universal/MainActivity$100000008;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity$100000008;-><init>(Lgtandroid/universal/MainActivity;)V

    move-object/from16 v21, v36

    .line 510
    move-object/from16 v36, v18

    move-object/from16 v37, v3

    const-string v38, "\u2328\ufe0f"

    const-string v39, "\u041a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0430"

    const-string v40, "\u0410\u043a\u0442\u0438\u0432\u0438\u0440\u043e\u0432\u0430\u0442\u044c"

    const v41, -0xff1a01

    move-object/from16 v42, v20

    invoke-direct/range {v37 .. v42}, Lgtandroid/universal/MainActivity;->buildActionCard(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 511
    new-instance v36, Landroid/view/View;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v22, v36

    .line 512
    move-object/from16 v36, v22

    new-instance v37, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v37

    move-object/from16 v37, v43

    move-object/from16 v38, v43

    move-object/from16 v39, v3

    const/16 v40, 0xc

    move/from16 v0, v40

    int-to-float v0, v0

    move/from16 v40, v0

    invoke-direct/range {v39 .. v40}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v39

    const/16 v40, 0x1

    invoke-direct/range {v38 .. v40}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 513
    move-object/from16 v36, v18

    move-object/from16 v37, v22

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 514
    move-object/from16 v36, v18

    move-object/from16 v37, v3

    const-string v38, "\ud83d\udcd0"

    const-string v39, "\u0427\u0430\u0442-\u0442\u0440\u0435\u043a\u0435\u0440"

    const-string v40, "\u041e\u0442\u0441\u043b\u0435\u0436\u0438\u0432\u0430\u043d\u0438\u0435"

    const v41, -0xd13c

    move-object/from16 v42, v21

    invoke-direct/range {v37 .. v42}, Lgtandroid/universal/MainActivity;->buildActionCard(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 516
    new-instance v36, Lgtandroid/universal/MainActivity$100000009;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity$100000009;-><init>(Lgtandroid/universal/MainActivity;)V

    move-object/from16 v23, v36

    .line 541
    new-instance v36, Landroid/widget/LinearLayout;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v24, v36

    .line 542
    move-object/from16 v36, v24

    const/16 v37, 0x0

    invoke-virtual/range {v36 .. v37}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 543
    new-instance v36, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    const/16 v38, -0x1

    const/16 v39, -0x2

    invoke-direct/range {v37 .. v39}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v25, v36

    .line 545
    move-object/from16 v36, v25

    move-object/from16 v37, v3

    const/16 v38, 0x10

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    const/16 v38, 0x0

    move-object/from16 v39, v3

    const/16 v40, 0x10

    move/from16 v0, v40

    int-to-float v0, v0

    move/from16 v40, v0

    invoke-direct/range {v39 .. v40}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v39

    move-object/from16 v40, v3

    const/16 v41, 0x8

    move/from16 v0, v41

    int-to-float v0, v0

    move/from16 v41, v0

    invoke-direct/range {v40 .. v41}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v40

    invoke-virtual/range {v36 .. v40}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 546
    move-object/from16 v36, v24

    move-object/from16 v37, v25

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 547
    move-object/from16 v36, v24

    move-object/from16 v37, v3

    const-string v38, "\ud83d\udd00"

    const-string v39, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0443"

    const-string v40, "\u041f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u043d\u0430 GTAndroid"

    const v41, -0xc60078

    move-object/from16 v42, v23

    invoke-direct/range {v37 .. v42}, Lgtandroid/universal/MainActivity;->buildActionCard(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILandroid/view/View$OnClickListener;)Landroid/view/View;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 548
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    move-object/from16 v37, v24

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 550
    new-instance v36, Landroid/widget/LinearLayout;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v26, v36

    .line 551
    move-object/from16 v36, v26

    const/16 v37, 0x1

    invoke-virtual/range {v36 .. v37}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 552
    move-object/from16 v36, v26

    const/16 v37, 0x11

    invoke-virtual/range {v36 .. v37}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 553
    new-instance v36, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    const/16 v38, -0x1

    const/16 v39, -0x2

    invoke-direct/range {v37 .. v39}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object/from16 v27, v36

    .line 555
    move-object/from16 v36, v27

    move-object/from16 v37, v3

    const/16 v38, 0x1c

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 556
    move-object/from16 v36, v27

    move-object/from16 v37, v3

    const/16 v38, 0x14

    move/from16 v0, v38

    int-to-float v0, v0

    move/from16 v38, v0

    invoke-direct/range {v37 .. v38}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v37

    move/from16 v0, v37

    move-object/from16 v1, v36

    iput v0, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 557
    move-object/from16 v36, v26

    move-object/from16 v37, v27

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 558
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    move-object/from16 v37, v26

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 560
    move-object/from16 v36, v3

    new-instance v37, Landroid/widget/Button;

    move-object/from16 v43, v37

    move-object/from16 v37, v43

    move-object/from16 v38, v43

    move-object/from16 v39, v3

    invoke-direct/range {v38 .. v39}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v0, v37

    move-object/from16 v1, v36

    iput-object v0, v1, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    .line 561
    move-object/from16 v36, v3

    const/16 v37, 0x96

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-direct/range {v36 .. v37}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v36

    move/from16 v28, v36

    .line 562
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    move-object/from16 v36, v0

    new-instance v37, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v37

    move-object/from16 v37, v43

    move-object/from16 v38, v43

    move/from16 v39, v28

    move/from16 v40, v28

    invoke-direct/range {v38 .. v40}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 563
    move-object/from16 v36, v3

    invoke-direct/range {v36 .. v36}, Lgtandroid/universal/MainActivity;->updateToggleButtonStyle()V

    .line 565
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    move-object/from16 v36, v0

    new-instance v37, Lgtandroid/universal/MainActivity$100000010;

    move-object/from16 v43, v37

    move-object/from16 v37, v43

    move-object/from16 v38, v43

    move-object/from16 v39, v3

    invoke-direct/range {v38 .. v39}, Lgtandroid/universal/MainActivity$100000010;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 571
    move-object/from16 v36, v26

    move-object/from16 v37, v3

    move-object/from16 v0, v37

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    move-object/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 573
    new-instance v36, Landroid/widget/TextView;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v29, v36

    .line 574
    move-object/from16 v36, v29

    const-string v37, "\u041f\u041b\u0410\u0412\u0410\u042e\u0429\u0415\u0415 \u041c\u0415\u041d\u042e"

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 575
    move-object/from16 v36, v29

    const/16 v37, 0xd

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setTextSize(F)V

    .line 576
    move-object/from16 v36, v29

    const v37, 0x3d4ccccd    # 0.05f

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setLetterSpacing(F)V

    .line 577
    move-object/from16 v36, v29

    const v37, -0x655f4c

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setTextColor(I)V

    .line 578
    move-object/from16 v36, v29

    const/16 v37, 0x11

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setGravity(I)V

    .line 579
    move-object/from16 v36, v29

    const/16 v37, 0x0

    move-object/from16 v38, v3

    const/16 v39, 0xe

    move/from16 v0, v39

    int-to-float v0, v0

    move/from16 v39, v0

    invoke-direct/range {v38 .. v39}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v38

    const/16 v39, 0x0

    const/16 v40, 0x0

    invoke-virtual/range {v36 .. v40}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 580
    move-object/from16 v36, v26

    move-object/from16 v37, v29

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 582
    new-instance v36, Landroid/widget/TextView;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v30, v36

    .line 583
    move-object/from16 v36, v30

    const-string v37, "\u2726 \u041d\u041e\u0412\u041e\u0421\u0422\u0418 \u0418 \u041f\u0410\u0420\u0422\u041d\u0401\u0420\u042b \u2726"

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 584
    move-object/from16 v36, v30

    const/16 v37, 0xf

    move/from16 v0, v37

    int-to-float v0, v0

    move/from16 v37, v0

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setTextSize(F)V

    .line 585
    move-object/from16 v36, v30

    const/16 v37, 0x11

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setGravity(I)V

    .line 586
    move-object/from16 v36, v30

    const/16 v37, 0x0

    move-object/from16 v38, v3

    const/16 v39, 0x6

    move/from16 v0, v39

    int-to-float v0, v0

    move/from16 v39, v0

    invoke-direct/range {v38 .. v39}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v38

    const/16 v39, 0x0

    move-object/from16 v40, v3

    const/16 v41, 0xc

    move/from16 v0, v41

    int-to-float v0, v0

    move/from16 v41, v0

    invoke-direct/range {v40 .. v41}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v40

    invoke-virtual/range {v36 .. v40}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 587
    move-object/from16 v36, v30

    const/16 v37, 0x0

    check-cast v37, Landroid/graphics/Typeface;

    const/16 v38, 0x1

    invoke-virtual/range {v36 .. v38}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 588
    move-object/from16 v36, v3

    move-object/from16 v37, v30

    const/16 v38, -0x36c3

    invoke-direct/range {v36 .. v38}, Lgtandroid/universal/MainActivity;->applyNeonGlow(Landroid/widget/TextView;I)V

    .line 589
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    move-object/from16 v37, v30

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 591
    new-instance v36, Landroid/widget/HorizontalScrollView;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    move-object/from16 v31, v36

    .line 592
    move-object/from16 v36, v31

    new-instance v37, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v37

    move-object/from16 v37, v43

    move-object/from16 v38, v43

    const/16 v39, -0x1

    const/16 v40, 0x190

    invoke-direct/range {v38 .. v40}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 596
    move-object/from16 v36, v31

    const/16 v37, 0xa

    const/16 v38, 0xa

    const/16 v39, 0xa

    const/16 v40, 0xa

    invoke-virtual/range {v36 .. v40}, Landroid/view/View;->setPadding(IIII)V

    .line 598
    new-instance v36, Landroid/widget/LinearLayout;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v32, v36

    .line 599
    move-object/from16 v36, v32

    const/16 v37, 0x0

    invoke-virtual/range {v36 .. v37}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 600
    move-object/from16 v36, v32

    const/16 v37, 0xa

    const/16 v38, 0xa

    const/16 v39, 0xa

    const/16 v40, 0xa

    invoke-virtual/range {v36 .. v40}, Landroid/view/View;->setPadding(IIII)V

    .line 601
    move-object/from16 v36, v32

    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v37

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setId(I)V

    .line 603
    new-instance v36, Landroid/widget/TextView;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v33, v36

    .line 604
    move-object/from16 v36, v33

    const-string v37, "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430..."

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 605
    move-object/from16 v36, v33

    const v37, -0x655f4c

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setTextColor(I)V

    .line 606
    move-object/from16 v36, v33

    const/16 v37, 0x14

    const/16 v38, 0x96

    const/16 v39, 0x14

    const/16 v40, 0x96

    invoke-virtual/range {v36 .. v40}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 607
    move-object/from16 v36, v32

    move-object/from16 v37, v33

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 609
    move-object/from16 v36, v31

    move-object/from16 v37, v32

    invoke-virtual/range {v36 .. v37}, Landroid/widget/HorizontalScrollView;->addView(Landroid/view/View;)V

    .line 610
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    move-object/from16 v37, v31

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 612
    new-instance v36, Landroid/view/View;

    move-object/from16 v43, v36

    move-object/from16 v36, v43

    move-object/from16 v37, v43

    move-object/from16 v38, v3

    invoke-direct/range {v37 .. v38}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v34, v36

    .line 613
    move-object/from16 v36, v34

    new-instance v37, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v43, v37

    move-object/from16 v37, v43

    move-object/from16 v38, v43

    const/16 v39, -0x1

    move-object/from16 v40, v3

    const/16 v41, 0x5a

    move/from16 v0, v41

    int-to-float v0, v0

    move/from16 v41, v0

    invoke-direct/range {v40 .. v41}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v40

    invoke-direct/range {v38 .. v40}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v36 .. v37}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 615
    move-object/from16 v36, v3

    move-object/from16 v0, v36

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object/from16 v36, v0

    move-object/from16 v37, v34

    invoke-virtual/range {v36 .. v37}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void

    .line 451
    :cond_0
    move-wide/from16 v36, v13

    const/16 v38, 0x0

    move/from16 v0, v38

    int-to-long v0, v0

    move-wide/from16 v38, v0

    cmp-long v36, v36, v38

    if-lez v36, :cond_4

    .line 452
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v36

    move-wide/from16 v17, v36

    .line 453
    move-wide/from16 v36, v17

    move-wide/from16 v38, v13

    cmp-long v36, v36, v38

    if-gez v36, :cond_3

    .line 454
    move-wide/from16 v36, v13

    move-wide/from16 v38, v17

    sub-long v36, v36, v38

    move-wide/from16 v19, v36

    .line 455
    move-wide/from16 v36, v19

    const v38, 0x5265c00

    move/from16 v0, v38

    int-to-long v0, v0

    move-wide/from16 v38, v0

    div-long v36, v36, v38

    move-wide/from16 v21, v36

    .line 456
    move-wide/from16 v36, v19

    const v38, 0x5265c00

    move/from16 v0, v38

    int-to-long v0, v0

    move-wide/from16 v38, v0

    rem-long v36, v36, v38

    const v38, 0x36ee80

    move/from16 v0, v38

    int-to-long v0, v0

    move-wide/from16 v38, v0

    div-long v36, v36, v38

    move-wide/from16 v23, v36

    .line 458
    const v36, -0xc60078

    move/from16 v16, v36

    .line 459
    const-string v36, "silver"

    move-object/from16 v37, v15

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_1

    const v36, -0x383225

    move/from16 v16, v36

    .line 460
    :cond_1
    const-string v36, "bronze"

    move-object/from16 v37, v15

    invoke-virtual/range {v36 .. v37}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v36

    if-eqz v36, :cond_2

    const v36, -0x1f66a4

    move/from16 v16, v36

    .line 462
    :cond_2
    move-object/from16 v36, v10

    new-instance v37, Ljava/lang/StringBuffer;

    move-object/from16 v43, v37

    move-object/from16 v37, v43

    move-object/from16 v38, v43

    invoke-direct/range {v38 .. v38}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v38, Ljava/lang/StringBuffer;

    move-object/from16 v43, v38

    move-object/from16 v38, v43

    move-object/from16 v39, v43

    invoke-direct/range {v39 .. v39}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v39, Ljava/lang/StringBuffer;

    move-object/from16 v43, v39

    move-object/from16 v39, v43

    move-object/from16 v40, v43

    invoke-direct/range {v40 .. v40}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v40, Ljava/lang/StringBuffer;

    move-object/from16 v43, v40

    move-object/from16 v40, v43

    move-object/from16 v41, v43

    invoke-direct/range {v41 .. v41}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v41, Ljava/lang/StringBuffer;

    move-object/from16 v43, v41

    move-object/from16 v41, v43

    move-object/from16 v42, v43

    invoke-direct/range {v42 .. v42}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v42, v15

    invoke-virtual/range {v42 .. v42}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v42

    invoke-virtual/range {v41 .. v42}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v41

    const-string v42, " \u00b7 \u043e\u0441\u0442\u0430\u043b\u043e\u0441\u044c "

    invoke-virtual/range {v41 .. v42}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v41

    invoke-virtual/range {v41 .. v41}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v41

    invoke-virtual/range {v40 .. v41}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v40

    move-wide/from16 v41, v21

    invoke-virtual/range {v40 .. v42}, Ljava/lang/StringBuffer;->append(J)Ljava/lang/StringBuffer;

    move-result-object v40

    invoke-virtual/range {v40 .. v40}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v40

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    const-string v40, " \u0434\u043d. "

    invoke-virtual/range {v39 .. v40}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v39

    invoke-virtual/range {v39 .. v39}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v39

    invoke-virtual/range {v38 .. v39}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v38

    move-wide/from16 v39, v23

    invoke-virtual/range {v38 .. v40}, Ljava/lang/StringBuffer;->append(J)Ljava/lang/StringBuffer;

    move-result-object v38

    invoke-virtual/range {v38 .. v38}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v38

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    const-string v38, " \u0447."

    invoke-virtual/range {v37 .. v38}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v37

    invoke-virtual/range {v37 .. v37}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v37

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 465
    :goto_1
    goto/16 :goto_0

    .line 464
    :cond_3
    move-object/from16 v36, v10

    const-string v37, "\u041f\u043e\u0434\u043f\u0438\u0441\u043a\u0430 \u0438\u0441\u0442\u0435\u043a\u043b\u0430"

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 465
    const v36, -0xb293

    move/from16 v16, v36

    goto :goto_1

    .line 468
    :cond_4
    move-object/from16 v36, v10

    const-string v37, "\u0421\u0442\u0430\u0442\u0443\u0441: \u043d\u0435 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0451\u043d"

    invoke-virtual/range {v36 .. v37}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 469
    const v36, -0x655f4c

    move/from16 v16, v36

    goto/16 :goto_0
.end method

.method private showNavigatorEditor()V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1751
    move-object v0, p0

    new-instance v8, Landroid/widget/LinearLayout;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v8

    .line 1752
    move-object v8, v2

    const/4 v9, 0x1

    invoke-virtual {v8, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1753
    move-object v8, v2

    move-object v9, v0

    const/16 v10, 0x14

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v9

    move-object v10, v0

    const/16 v11, 0xe

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    move-object v11, v0

    const/16 v12, 0x14

    int-to-float v12, v12

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v11

    move-object v12, v0

    const/4 v13, 0x6

    int-to-float v13, v13

    invoke-direct {v12, v13}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v12

    invoke-virtual {v8, v9, v10, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    .line 1755
    const/4 v8, 0x1

    new-array v8, v8, [Landroid/app/AlertDialog;

    move-object v3, v8

    .line 1757
    new-instance v8, Landroid/widget/Button;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v4, v8

    .line 1758
    move-object v8, v4

    const-string v9, "\ud83d\udce5 \u0418\u043c\u043f\u043e\u0440\u0442"

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1759
    move-object v8, v4

    const/4 v9, 0x0

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1760
    move-object v8, v4

    const v9, -0xff9934

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1761
    move-object v8, v4

    const/4 v9, -0x1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1762
    move-object v8, v4

    new-instance v9, Lgtandroid/universal/MainActivity$100000048;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    move-object v12, v3

    invoke-direct {v10, v11, v12}, Lgtandroid/universal/MainActivity$100000048;-><init>(Lgtandroid/universal/MainActivity;[Landroid/app/AlertDialog;)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1771
    move-object v8, v2

    move-object v9, v4

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1773
    new-instance v8, Landroid/widget/Button;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v5, v8

    .line 1774
    move-object v8, v5

    const-string v9, "\ud83d\udce4 \u042d\u043a\u0441\u043f\u043e\u0440\u0442"

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1775
    move-object v8, v5

    const/4 v9, 0x0

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1776
    move-object v8, v5

    const v9, -0xff559a

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1777
    move-object v8, v5

    const/4 v9, -0x1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1778
    move-object v8, v5

    new-instance v9, Lgtandroid/universal/MainActivity$100000049;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    move-object v12, v3

    invoke-direct {v10, v11, v12}, Lgtandroid/universal/MainActivity$100000049;-><init>(Lgtandroid/universal/MainActivity;[Landroid/app/AlertDialog;)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1788
    move-object v8, v2

    move-object v9, v5

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1790
    new-instance v8, Landroid/widget/Button;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v0

    invoke-direct {v9, v10}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v6, v8

    .line 1791
    move-object v8, v6

    const-string v9, "\ud83d\udccb \u0421\u043f\u0438\u0441\u043e\u043a"

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1792
    move-object v8, v6

    const/4 v9, 0x0

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1793
    move-object v8, v6

    const v9, -0x559a00

    invoke-virtual {v8, v9}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1794
    move-object v8, v6

    const/4 v9, -0x1

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1795
    move-object v8, v6

    new-instance v9, Lgtandroid/universal/MainActivity$100000050;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    move-object v12, v3

    invoke-direct {v10, v11, v12}, Lgtandroid/universal/MainActivity$100000050;-><init>(Lgtandroid/universal/MainActivity;[Landroid/app/AlertDialog;)V

    invoke-virtual {v8, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1801
    move-object v8, v2

    move-object v9, v6

    invoke-virtual {v8, v9}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1803
    move-object v8, v3

    const/4 v9, 0x0

    new-instance v10, Landroid/app/AlertDialog$Builder;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v11, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440\u0430"

    invoke-virtual {v10, v11}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v10

    move-object v11, v2

    invoke-virtual {v10, v11}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v10

    const-string v11, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/4 v12, 0x0

    check-cast v12, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v10, v11, v12}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v10

    invoke-virtual {v10}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v10

    aput-object v10, v8, v9

    return-void
.end method

.method private showNavigatorListDialog()V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1811
    move-object/from16 v0, p0

    new-instance v9, Landroid/widget/LinearLayout;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v9

    .line 1812
    move-object v9, v2

    const/4 v10, 0x1

    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1813
    move-object v9, v2

    move-object v10, v0

    const/16 v11, 0x14

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    move-object v11, v0

    const/16 v12, 0xe

    int-to-float v12, v12

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v11

    move-object v12, v0

    const/16 v13, 0x14

    int-to-float v13, v13

    invoke-direct {v12, v13}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v12

    move-object v13, v0

    const/4 v14, 0x6

    int-to-float v14, v14

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v13

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/view/View;->setPadding(IIII)V

    .line 1815
    new-instance v9, Landroid/widget/EditText;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v3, v9

    .line 1816
    move-object v9, v3

    const v10, 0xa0001

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setInputType(I)V

    .line 1819
    move-object v9, v3

    const/16 v10, 0xa

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setMinLines(I)V

    .line 1820
    move-object v9, v3

    const/16 v10, 0x30

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setGravity(I)V

    .line 1821
    move-object v9, v3

    const/16 v10, 0xd

    int-to-float v10, v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1822
    move-object v9, v3

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-static {v10}, Lgtandroid/universal/NavData;->loadNavigator(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v10

    invoke-static {v10}, Lgtandroid/universal/NavData;->toCfg(Ljava/util/List;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1823
    move-object v9, v2

    move-object v10, v3

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1825
    new-instance v9, Landroid/widget/TextView;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v9

    .line 1826
    move-object v9, v4

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    const-string v11, "\u0420\u0430\u0431\u043e\u0442\u0430\u044e\u0442 \u0442\u043e\u043b\u044c\u043a\u043e \u0441\u0442\u0440\u043e\u043a\u0438 \u0441 \u043d\u043e\u043c\u0435\u0440\u0430\u043c\u0438: \u00ab1. \u041a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u044f\u00bb \u0438 \u00ab1.1. \u041c\u0435\u0441\u0442\u043e\u00bb.\n"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    const-string v11, "\u0421\u0442\u0440\u043e\u043a\u0430 \u0431\u0435\u0437 \u043d\u043e\u043c\u0435\u0440\u0430 (\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440 \u043f\u0440\u043e\u0441\u0442\u043e \u00ab\u0422\u0430\u043a\u0441\u0438\u00bb) \u0438\u0433\u043d\u043e\u0440\u0438\u0440\u0443\u0435\u0442\u0441\u044f. \u041d\u043e\u043c\u0435\u0440\u0430 \u043f\u043e\u0441\u043b\u0435 \u0441\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u0438\u044f \u043f\u0435\u0440\u0435\u0441\u0447\u0438\u0442\u0430\u044e\u0442\u0441\u044f \u0441\u0430\u043c\u0438."

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1828
    move-object v9, v4

    const/16 v10, 0xc

    int-to-float v10, v10

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1829
    move-object v9, v4

    const v10, -0x777778

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1830
    move-object v9, v4

    const/4 v10, 0x0

    move-object v11, v0

    const/16 v12, 0x8

    int-to-float v12, v12

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v11

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v9, v10, v11, v12, v13}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1831
    move-object v9, v2

    move-object v10, v4

    invoke-virtual {v9, v10}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1833
    new-instance v9, Landroid/widget/ScrollView;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v5, v9

    .line 1834
    move-object v9, v5

    move-object v10, v2

    invoke-virtual {v9, v10}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1836
    new-instance v9, Landroid/app/AlertDialog$Builder;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    move-object v11, v0

    invoke-direct {v10, v11}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v10, "\u0421\u043f\u0438\u0441\u043e\u043a \u043d\u0430\u0432\u0438\u0433\u0430\u0442\u043e\u0440\u0430"

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    move-object v10, v5

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    const/4 v11, 0x0

    check-cast v11, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u0421\u0431\u0440\u043e\u0441\u0438\u0442\u044c"

    new-instance v11, Lgtandroid/universal/MainActivity$100000052;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    move-object v13, v0

    invoke-direct {v12, v13}, Lgtandroid/universal/MainActivity$100000052;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v11, 0x0

    check-cast v11, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    move-object v6, v9

    .line 1858
    move-object v9, v6

    invoke-virtual {v9}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v9

    move-object v7, v9

    .line 1859
    move-object v9, v7

    invoke-virtual {v9}, Landroid/app/Dialog;->show()V

    .line 1860
    move-object v9, v7

    const/4 v10, -0x1

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v9

    new-instance v10, Lgtandroid/universal/MainActivity$100000053;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    move-object v13, v3

    move-object v14, v7

    invoke-direct {v11, v12, v13, v14}, Lgtandroid/universal/MainActivity$100000053;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;)V

    invoke-virtual {v9, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method private showNormalButtonsList()V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2553
    move-object/from16 v2, p0

    move-object/from16 v19, v2

    const-string v20, "btn_count"

    const/16 v21, 0x0

    invoke-direct/range {v19 .. v21}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v19

    move/from16 v4, v19

    .line 2555
    move/from16 v19, v4

    const/16 v20, 0x0

    move/from16 v0, v19

    move/from16 v1, v20

    if-ne v0, v1, :cond_0

    .line 2556
    new-instance v19, Landroid/app/AlertDialog$Builder;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v20, "\u041e\u0431\u044b\u0447\u043d\u044b\u0435 \u043a\u043d\u043e\u043f\u043a\u0438"

    invoke-virtual/range {v19 .. v20}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    const-string v20, "\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442"

    invoke-virtual/range {v19 .. v20}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    const-string v20, "OK"

    const/16 v21, 0x0

    check-cast v21, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v19 .. v21}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v19

    .line 2631
    :goto_0
    return-void

    .line 2563
    :cond_0
    new-instance v19, Landroid/widget/ScrollView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object/from16 v5, v19

    .line 2564
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v19

    .line 2565
    move-object/from16 v19, v6

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2566
    move-object/from16 v19, v6

    const/16 v20, 0xa

    const/16 v21, 0xa

    const/16 v22, 0xa

    const/16 v23, 0xa

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 2568
    const/16 v19, 0x0

    move/from16 v7, v19

    :goto_1
    move/from16 v19, v7

    move/from16 v20, v4

    move/from16 v0, v19

    move/from16 v1, v20

    if-lt v0, v1, :cond_1

    .line 2629
    move-object/from16 v19, v5

    move-object/from16 v20, v6

    invoke-virtual/range {v19 .. v20}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2631
    new-instance v19, Landroid/app/AlertDialog$Builder;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v20, "\u2550\u2550 \u041e\u0411\u042b\u0427\u041d\u042b\u0415 \u041a\u041d\u041e\u041f\u041a\u0418 \u2550\u2550"

    invoke-virtual/range {v19 .. v20}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    move-object/from16 v20, v5

    invoke-virtual/range {v19 .. v20}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    const-string v20, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/16 v21, 0x0

    check-cast v21, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v19 .. v21}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v19

    goto :goto_0

    .line 2569
    :cond_1
    move/from16 v19, v7

    move/from16 v8, v19

    .line 2570
    move-object/from16 v19, v2

    move-object/from16 v0, v19

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v19, v0

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    const-string v22, "btn_"

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    move/from16 v22, v7

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    const-string v21, "_name"

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    const-string v21, "\u041a\u043d\u043e\u043f\u043a\u0430"

    invoke-interface/range {v19 .. v21}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    move-object/from16 v9, v19

    .line 2571
    move-object/from16 v19, v2

    move-object/from16 v0, v19

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v19, v0

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    const-string v22, "btn_"

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    move/from16 v22, v7

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    const-string v21, "_text"

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    const-string v21, ""

    invoke-interface/range {v19 .. v21}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    move-object/from16 v10, v19

    .line 2573
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v11, v19

    .line 2574
    move-object/from16 v19, v11

    const/16 v20, 0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2575
    move-object/from16 v19, v11

    const/16 v20, 0xa

    const/16 v21, 0xa

    const/16 v22, 0xa

    const/16 v23, 0xa

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 2576
    move-object/from16 v19, v11

    const v20, -0xe4e2d8

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2578
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v12, v19

    .line 2579
    move-object/from16 v19, v12

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v21, Ljava/lang/StringBuffer;

    move-object/from16 v26, v21

    move-object/from16 v21, v26

    move-object/from16 v22, v26

    invoke-direct/range {v22 .. v22}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v22, Ljava/lang/StringBuffer;

    move-object/from16 v26, v22

    move-object/from16 v22, v26

    move-object/from16 v23, v26

    invoke-direct/range {v23 .. v23}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v23, Ljava/lang/StringBuffer;

    move-object/from16 v26, v23

    move-object/from16 v23, v26

    move-object/from16 v24, v26

    invoke-direct/range {v24 .. v24}, Ljava/lang/StringBuffer;-><init>()V

    move/from16 v24, v7

    const/16 v25, 0x1

    add-int/lit8 v24, v24, 0x1

    invoke-virtual/range {v23 .. v24}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v23

    const-string v24, ". "

    invoke-virtual/range {v23 .. v24}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v23

    invoke-virtual/range {v23 .. v23}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v23

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    move-object/from16 v23, v9

    invoke-virtual/range {v22 .. v23}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v22

    invoke-virtual/range {v22 .. v22}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    const-string v22, "\n\ud83d\udcdd \u041a\u043e\u043c\u0430\u043d\u0434\u0430: "

    invoke-virtual/range {v21 .. v22}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v21

    invoke-virtual/range {v21 .. v21}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v21

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    move-object/from16 v21, v10

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2580
    move-object/from16 v19, v12

    const v20, -0x12120b

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2581
    move-object/from16 v19, v11

    move-object/from16 v20, v12

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2583
    new-instance v19, Landroid/widget/LinearLayout;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v19

    .line 2584
    move-object/from16 v19, v13

    const/16 v20, 0x0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2585
    move-object/from16 v19, v13

    const/16 v20, 0x0

    const/16 v21, 0xa

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 2587
    new-instance v19, Landroid/widget/Button;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v19

    .line 2588
    move-object/from16 v19, v14

    const-string v20, "\u270f\ufe0f \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2589
    move-object/from16 v19, v14

    const v20, -0xff9934

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2590
    move-object/from16 v19, v14

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2591
    move-object/from16 v19, v14

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, 0x0

    const/16 v23, -0x2

    const/16 v24, 0x1

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v21 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2592
    move-object/from16 v19, v14

    new-instance v20, Lgtandroid/universal/MainActivity$100000068;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    move/from16 v23, v8

    move-object/from16 v24, v9

    move-object/from16 v25, v10

    invoke-direct/range {v21 .. v25}, Lgtandroid/universal/MainActivity$100000068;-><init>(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2599
    new-instance v19, Landroid/widget/Button;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v19

    .line 2600
    move-object/from16 v19, v15

    const-string v20, "\ud83d\uddd1\ufe0f \u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2601
    move-object/from16 v19, v15

    const/high16 v20, -0x340000

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2602
    move-object/from16 v19, v15

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2603
    move-object/from16 v19, v15

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, 0x0

    const/16 v23, -0x2

    const/16 v24, 0x1

    move/from16 v0, v24

    int-to-float v0, v0

    move/from16 v24, v0

    invoke-direct/range {v21 .. v24}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2604
    move-object/from16 v19, v15

    new-instance v20, Lgtandroid/universal/MainActivity$100000069;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    move/from16 v23, v8

    invoke-direct/range {v21 .. v23}, Lgtandroid/universal/MainActivity$100000069;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2611
    move-object/from16 v19, v13

    move-object/from16 v20, v14

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2613
    new-instance v19, Landroid/view/View;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v16, v19

    .line 2614
    move-object/from16 v19, v16

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, 0xa

    const/16 v23, -0x1

    invoke-direct/range {v21 .. v23}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2615
    move-object/from16 v19, v13

    move-object/from16 v20, v16

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2617
    move-object/from16 v19, v13

    move-object/from16 v20, v15

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2618
    move-object/from16 v19, v11

    move-object/from16 v20, v13

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2619
    move-object/from16 v19, v6

    move-object/from16 v20, v11

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2621
    move/from16 v19, v7

    move/from16 v20, v4

    const/16 v21, 0x1

    add-int/lit8 v20, v20, -0x1

    move/from16 v0, v19

    move/from16 v1, v20

    if-ge v0, v1, :cond_2

    .line 2622
    new-instance v19, Landroid/view/View;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v17, v19

    .line 2623
    move-object/from16 v19, v17

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, -0x1

    const/16 v23, 0x5

    invoke-direct/range {v21 .. v23}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2625
    move-object/from16 v19, v6

    move-object/from16 v20, v17

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2568
    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_1
.end method

.method private showPunishmentEditor()V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1974
    move-object v0, p0

    const/16 v4, 0xb

    new-array v4, v4, [Ljava/lang/String;

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x0

    const-string v7, "\u041a\u0438\u043a"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x1

    const-string v7, "\u0411\u0430\u043d"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x2

    const-string v7, "\u0412\u0430\u0440\u043d"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x3

    const-string v7, "\u0414\u0436\u0430\u0438\u043b"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x4

    const-string v7, "\u041c\u0443\u0442"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x5

    const-string v7, "Un\u0411\u0430\u043d"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x6

    const-string v7, "Un\u0412\u0430\u0440\u043d"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/4 v6, 0x7

    const-string v7, "Un\u0414\u0436\u0430\u0438\u043b"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/16 v6, 0x8

    const-string v7, "Un\u041c\u0443\u0442"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/16 v6, 0x9

    const-string v7, "R\u041c\u0443\u0442"

    aput-object v7, v5, v6

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    const/16 v6, 0xa

    const-string v7, "UnR\u041c\u0443\u0442"

    aput-object v7, v5, v6

    move-object v2, v4

    .line 1979
    new-instance v4, Landroid/app/AlertDialog$Builder;

    move-object v10, v4

    move-object v4, v10

    move-object v5, v10

    move-object v6, v0

    invoke-direct {v5, v6}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v5, "\u2550\u2550 \u0412\u042b\u0411\u0415\u0420\u0418\u0422\u0415 \u0422\u0418\u041f \u2550\u2550"

    invoke-virtual {v4, v5}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    move-object v5, v2

    new-instance v6, Lgtandroid/universal/MainActivity$100000055;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    move-object v8, v0

    move-object v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/MainActivity$100000055;-><init>(Lgtandroid/universal/MainActivity;[Ljava/lang/String;)V

    invoke-virtual {v4, v5, v6}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v4

    invoke-virtual {v4}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v4

    return-void
.end method

.method private showPunishmentQueueEditor()V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1917
    move-object/from16 v1, p0

    new-instance v14, Landroid/widget/LinearLayout;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v14

    .line 1918
    move-object v14, v3

    const/4 v15, 0x1

    invoke-virtual {v14, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1919
    move-object v14, v3

    move-object v15, v1

    const/16 v16, 0x14

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v15

    move-object/from16 v16, v1

    const/16 v17, 0xe

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v16

    move-object/from16 v17, v1

    const/16 v18, 0x14

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v17

    move-object/from16 v18, v1

    const/16 v19, 0x6

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    invoke-direct/range {v18 .. v19}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v18

    invoke-virtual/range {v14 .. v18}, Landroid/view/View;->setPadding(IIII)V

    .line 1921
    new-instance v14, Landroid/widget/TextView;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v14

    .line 1922
    move-object v14, v4

    const-string v15, "\u041f\u043e \u043e\u0434\u043d\u043e\u0439 \u043a\u043e\u043c\u0430\u043d\u0434\u0435 \u043d\u0430 \u0441\u0442\u0440\u043e\u043a\u0443:"

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1923
    move-object v14, v3

    move-object v15, v4

    invoke-virtual {v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1925
    new-instance v14, Landroid/widget/EditText;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object v5, v14

    .line 1926
    move-object v14, v5

    const-string v15, "/jail Rodik_King 10 dm\n/jail Rodik_King 11 dm\n/unjail Rodik_King"

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 1927
    move-object v14, v5

    const v15, 0xa0001

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setInputType(I)V

    .line 1930
    move-object v14, v5

    const/4 v15, 0x6

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setMinLines(I)V

    .line 1931
    move-object v14, v5

    const/16 v15, 0x30

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setGravity(I)V

    .line 1932
    new-instance v14, Ljava/lang/StringBuilder;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    invoke-direct {v15}, Ljava/lang/StringBuilder;-><init>()V

    move-object v6, v14

    .line 1933
    move-object v14, v1

    invoke-direct {v14}, Lgtandroid/universal/MainActivity;->loadPunishmentQueueLines()Ljava/util/List;

    move-result-object v14

    check-cast v14, Ljava/util/Collection;

    invoke-interface {v14}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v14

    move-object v7, v14

    .line 1935
    :goto_0
    move-object v14, v7

    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-nez v14, :cond_0

    .line 1937
    move-object v14, v5

    move-object v15, v6

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1938
    move-object v14, v3

    move-object v15, v5

    invoke-virtual {v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1940
    new-instance v14, Landroid/widget/TextView;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v9, v14

    .line 1941
    move-object v14, v9

    const-string v15, "\u042d\u0442\u0438 \u043a\u043e\u043c\u0430\u043d\u0434\u044b \u043f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u044e\u0442\u0441\u044f \u043f\u043e \u043e\u0434\u043d\u043e\u0439 \u0432 \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0435 (\u0410\u0414\u041c\u0418\u041d \u2192 \"\u041d\u0430\u043a\u0430\u0437\u0430\u043d\u0438\u044f \u0438\u0437 \u0430\u0434\u043c\u0438\u043d \u0447\u0430\u0442\u0430\"), \u0441 \u043a\u043d\u043e\u043f\u043a\u0430\u043c\u0438 \u041d\u0430\u043a\u0430\u0437\u0430\u0442\u044c / \u0423\u0434\u0430\u0447\u043d\u043e / \u041d\u0435\u0443\u0434\u0430\u0447\u043d\u043e."

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1942
    move-object v14, v9

    const/16 v15, 0xc

    int-to-float v15, v15

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setTextSize(F)V

    .line 1943
    move-object v14, v9

    const v15, -0x777778

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1944
    move-object v14, v9

    const/4 v15, 0x0

    move-object/from16 v16, v1

    const/16 v17, 0x8

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v16

    const/16 v17, 0x0

    const/16 v18, 0x0

    invoke-virtual/range {v14 .. v18}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1945
    move-object v14, v3

    move-object v15, v9

    invoke-virtual {v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1947
    new-instance v14, Landroid/widget/ScrollView;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v10, v14

    .line 1948
    move-object v14, v10

    move-object v15, v3

    invoke-virtual {v14, v15}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1950
    new-instance v14, Landroid/app/AlertDialog$Builder;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v15, "\u041d\u0430\u043a\u0430\u0437\u0430\u043d\u0438\u044f \u0438\u0437 \u0430\u0434\u043c\u0438\u043d \u0447\u0430\u0442\u0430"

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    move-object v15, v10

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    const-string v15, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    const/16 v16, 0x0

    check-cast v16, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v14 .. v16}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    const-string v15, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/16 v16, 0x0

    check-cast v16, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v14 .. v16}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    move-object v11, v14

    .line 1956
    move-object v14, v11

    invoke-virtual {v14}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v14

    move-object v12, v14

    .line 1957
    move-object v14, v12

    invoke-virtual {v14}, Landroid/app/Dialog;->show()V

    .line 1958
    move-object v14, v12

    const/4 v15, -0x1

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v14

    new-instance v15, Lgtandroid/universal/MainActivity$100000054;

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    move-object/from16 v17, v1

    move-object/from16 v18, v5

    move-object/from16 v19, v12

    invoke-direct/range {v16 .. v19}, Lgtandroid/universal/MainActivity$100000054;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/app/AlertDialog;)V

    invoke-virtual {v14, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    .line 1933
    :cond_0
    move-object v14, v7

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    move-object v9, v14

    .line 1934
    move-object v14, v6

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->length()I

    move-result v14

    const/4 v15, 0x0

    if-le v14, v15, :cond_1

    move-object v14, v6

    const-string v15, "\n"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    .line 1935
    :cond_1
    move-object v14, v6

    move-object v15, v9

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    goto/16 :goto_0
.end method

.method private showPunishmentTypeEditor(Ljava/lang/String;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1991
    move-object v0, p0

    move-object v1, p1

    new-instance v7, Landroid/widget/LinearLayout;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v7

    .line 1992
    move-object v7, v3

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1993
    move-object v7, v3

    const/16 v8, 0x14

    const/16 v9, 0x14

    const/16 v10, 0x14

    const/16 v11, 0x14

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/view/View;->setPadding(IIII)V

    .line 1995
    new-instance v7, Landroid/widget/Button;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v4, v7

    .line 1996
    move-object v7, v4

    const-string v8, "\u2795 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c"

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1997
    move-object v7, v4

    const v8, -0xff5600

    invoke-virtual {v7, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1998
    move-object v7, v4

    const/4 v8, -0x1

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1999
    move-object v7, v4

    new-instance v8, Lgtandroid/universal/MainActivity$100000056;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    move-object v10, v0

    move-object v11, v1

    invoke-direct {v9, v10, v11}, Lgtandroid/universal/MainActivity$100000056;-><init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v7, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2004
    move-object v7, v3

    move-object v8, v4

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2006
    new-instance v7, Landroid/widget/Button;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v5, v7

    .line 2007
    move-object v7, v5

    const-string v8, "\ud83d\udccb \u0421\u043f\u0438\u0441\u043e\u043a"

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2008
    move-object v7, v5

    const v8, -0xff9934

    invoke-virtual {v7, v8}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2009
    move-object v7, v5

    const/4 v8, -0x1

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2010
    move-object v7, v5

    new-instance v8, Lgtandroid/universal/MainActivity$100000057;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    move-object v10, v0

    move-object v11, v1

    invoke-direct {v9, v10, v11}, Lgtandroid/universal/MainActivity$100000057;-><init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V

    invoke-virtual {v7, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2016
    move-object v7, v3

    move-object v8, v5

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2018
    new-instance v7, Landroid/app/AlertDialog$Builder;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v1

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    move-object v8, v3

    invoke-virtual {v7, v8}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    const-string v8, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/4 v9, 0x0

    check-cast v9, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v7, v8, v9}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    invoke-virtual {v7}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v7

    return-void
.end method

.method private showPunishmentsListByType(Ljava/lang/String;)V
    .locals 39
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2096
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    :try_start_0
    new-instance v27, Ljava/lang/StringBuffer;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuffer;-><init>()V

    const-string v28, "punishment_"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    move-object/from16 v28, v3

    invoke-virtual/range {v28 .. v28}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v28

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v27

    move-object/from16 v5, v27

    .line 2097
    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v27, v0

    move-object/from16 v28, v5

    const-string v29, "[]"

    invoke-interface/range {v27 .. v29}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v6, v27

    .line 2098
    new-instance v27, Lorg/json/JSONArray;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v6

    invoke-direct/range {v28 .. v29}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object/from16 v7, v27

    .line 2099
    move-object/from16 v27, v7

    invoke-virtual/range {v27 .. v27}, Lorg/json/JSONArray;->length()I

    move-result v27

    const/16 v28, 0x0

    move/from16 v0, v27

    move/from16 v1, v28

    if-ne v0, v1, :cond_0

    .line 2100
    new-instance v27, Landroid/app/AlertDialog$Builder;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    move-object/from16 v28, v3

    invoke-virtual/range {v27 .. v28}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v27

    const-string v28, "\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442"

    invoke-virtual/range {v27 .. v28}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v27

    const-string v28, "OK"

    const/16 v29, 0x0

    check-cast v29, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v27 .. v29}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v27

    .line 2194
    :goto_0
    return-void

    .line 2108
    :cond_0
    new-instance v27, Landroid/widget/ScrollView;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object/from16 v8, v27

    .line 2109
    new-instance v27, Landroid/widget/LinearLayout;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v9, v27

    .line 2110
    move-object/from16 v27, v9

    const/16 v28, 0x1

    invoke-virtual/range {v27 .. v28}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2111
    move-object/from16 v27, v9

    const/16 v28, 0xa

    const/16 v29, 0xa

    const/16 v30, 0xa

    const/16 v31, 0xa

    invoke-virtual/range {v27 .. v31}, Landroid/view/View;->setPadding(IIII)V

    .line 2113
    const/16 v27, 0x0

    move/from16 v10, v27

    :goto_1
    move/from16 v27, v10

    move-object/from16 v28, v7

    invoke-virtual/range {v28 .. v28}, Lorg/json/JSONArray;->length()I

    move-result v28

    move/from16 v0, v27

    move/from16 v1, v28

    if-lt v0, v1, :cond_1

    .line 2185
    move-object/from16 v27, v8

    move-object/from16 v28, v9

    invoke-virtual/range {v27 .. v28}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2187
    new-instance v27, Landroid/app/AlertDialog$Builder;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    new-instance v28, Ljava/lang/StringBuffer;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    invoke-direct/range {v29 .. v29}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v29, Ljava/lang/StringBuffer;

    move-object/from16 v38, v29

    move-object/from16 v29, v38

    move-object/from16 v30, v38

    invoke-direct/range {v30 .. v30}, Ljava/lang/StringBuffer;-><init>()V

    const-string v30, "\u2550\u2550 "

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    move-object/from16 v30, v3

    invoke-virtual/range {v30 .. v30}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v30

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    invoke-virtual/range {v29 .. v29}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    const-string v29, " \u2550\u2550"

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-virtual/range {v27 .. v28}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v27

    move-object/from16 v28, v8

    invoke-virtual/range {v27 .. v28}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v27

    const-string v28, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/16 v29, 0x0

    check-cast v29, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v27 .. v29}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v27

    .line 2194
    :goto_2
    goto/16 :goto_0

    .line 2114
    :cond_1
    move/from16 v27, v10

    move/from16 v11, v27

    .line 2115
    move-object/from16 v27, v7

    move/from16 v28, v10

    invoke-virtual/range {v27 .. v28}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v27

    move-object/from16 v12, v27

    .line 2116
    move-object/from16 v27, v12

    const-string v28, "name"

    new-instance v29, Ljava/lang/StringBuffer;

    move-object/from16 v38, v29

    move-object/from16 v29, v38

    move-object/from16 v30, v38

    invoke-direct/range {v30 .. v30}, Ljava/lang/StringBuffer;-><init>()V

    const-string v30, "\u041d\u0430\u043a\u0430\u0437\u0430\u043d\u0438\u0435 "

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    move/from16 v30, v10

    const/16 v31, 0x1

    add-int/lit8 v30, v30, 0x1

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v29

    invoke-virtual/range {v29 .. v29}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v29

    invoke-virtual/range {v27 .. v29}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v13, v27

    .line 2117
    move-object/from16 v27, v12

    const-string v28, "command"

    const-string v29, ""

    invoke-virtual/range {v27 .. v29}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v14, v27

    .line 2118
    move-object/from16 v27, v12

    const-string v28, "time"

    const-string v29, ""

    invoke-virtual/range {v27 .. v29}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v15, v27

    .line 2119
    move-object/from16 v27, v12

    const-string v28, "reason"

    const-string v29, ""

    invoke-virtual/range {v27 .. v29}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v16, v27

    .line 2120
    move-object/from16 v27, v12

    const-string v28, "minlevel"

    const-string v29, "1"

    invoke-virtual/range {v27 .. v29}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v27

    move-object/from16 v17, v27

    .line 2122
    new-instance v27, Landroid/widget/LinearLayout;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v18, v27

    .line 2123
    move-object/from16 v27, v18

    const/16 v28, 0x1

    invoke-virtual/range {v27 .. v28}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2124
    move-object/from16 v27, v18

    const/16 v28, 0xa

    const/16 v29, 0xa

    const/16 v30, 0xa

    const/16 v31, 0xa

    invoke-virtual/range {v27 .. v31}, Landroid/view/View;->setPadding(IIII)V

    .line 2125
    move-object/from16 v27, v18

    const v28, -0xe4e2d8

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2127
    new-instance v27, Ljava/lang/StringBuilder;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v19, v27

    .line 2128
    move-object/from16 v27, v19

    move/from16 v28, v10

    const/16 v29, 0x1

    add-int/lit8 v28, v28, 0x1

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v27

    const-string v28, ". "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    move-object/from16 v28, v13

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    const-string v28, "\n"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    .line 2129
    move-object/from16 v27, v19

    const-string v28, "\ud83d\udcdd \u041a\u043e\u043c\u0430\u043d\u0434\u0430: "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    move-object/from16 v28, v14

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    const-string v28, "\n"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    .line 2130
    move-object/from16 v27, v15

    invoke-virtual/range {v27 .. v27}, Ljava/lang/String;->isEmpty()Z

    move-result v27

    if-nez v27, :cond_2

    move-object/from16 v27, v19

    const-string v28, "\u23f1\ufe0f \u0412\u0440\u0435\u043c\u044f: "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    move-object/from16 v28, v15

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    const-string v28, "\n"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    .line 2131
    :cond_2
    move-object/from16 v27, v16

    invoke-virtual/range {v27 .. v27}, Ljava/lang/String;->isEmpty()Z

    move-result v27

    if-nez v27, :cond_3

    move-object/from16 v27, v19

    const-string v28, "\ud83d\udcac \u041f\u0440\u0438\u0447\u0438\u043d\u0430: "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    move-object/from16 v28, v16

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    const-string v28, "\n"

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    .line 2132
    :cond_3
    move-object/from16 v27, v19

    const-string v28, "\ud83d\udc51 \u041c\u0438\u043d. \u0443\u0440: "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    move-object/from16 v28, v17

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v27

    .line 2134
    new-instance v27, Landroid/widget/TextView;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v20, v27

    .line 2135
    move-object/from16 v27, v20

    move-object/from16 v28, v19

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-virtual/range {v27 .. v28}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2136
    move-object/from16 v27, v20

    const v28, -0x12120b

    invoke-virtual/range {v27 .. v28}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2137
    move-object/from16 v27, v18

    move-object/from16 v28, v20

    invoke-virtual/range {v27 .. v28}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2139
    new-instance v27, Landroid/widget/LinearLayout;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v21, v27

    .line 2140
    move-object/from16 v27, v21

    const/16 v28, 0x0

    invoke-virtual/range {v27 .. v28}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2141
    move-object/from16 v27, v21

    const/16 v28, 0x0

    const/16 v29, 0xa

    const/16 v30, 0x0

    const/16 v31, 0x0

    invoke-virtual/range {v27 .. v31}, Landroid/view/View;->setPadding(IIII)V

    .line 2143
    new-instance v27, Landroid/widget/Button;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v22, v27

    .line 2144
    move-object/from16 v27, v22

    const-string v28, "\u270f\ufe0f \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c"

    invoke-virtual/range {v27 .. v28}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2145
    move-object/from16 v27, v22

    const v28, -0xff9934

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2146
    move-object/from16 v27, v22

    const/16 v28, -0x1

    invoke-virtual/range {v27 .. v28}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2147
    move-object/from16 v27, v22

    new-instance v28, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    const/16 v30, 0x0

    const/16 v31, -0x2

    const/16 v32, 0x1

    move/from16 v0, v32

    int-to-float v0, v0

    move/from16 v32, v0

    invoke-direct/range {v29 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2148
    move-object/from16 v27, v22

    new-instance v28, Lgtandroid/universal/MainActivity$100000059;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    move-object/from16 v30, v2

    move-object/from16 v31, v3

    move/from16 v32, v11

    move-object/from16 v33, v13

    move-object/from16 v34, v14

    move-object/from16 v35, v15

    move-object/from16 v36, v16

    move-object/from16 v37, v17

    invoke-direct/range {v29 .. v37}, Lgtandroid/universal/MainActivity$100000059;-><init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2154
    new-instance v27, Landroid/widget/Button;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v23, v27

    .line 2155
    move-object/from16 v27, v23

    const-string v28, "\ud83d\uddd1\ufe0f \u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-virtual/range {v27 .. v28}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2156
    move-object/from16 v27, v23

    const/high16 v28, -0x340000

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2157
    move-object/from16 v27, v23

    const/16 v28, -0x1

    invoke-virtual/range {v27 .. v28}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2158
    move-object/from16 v27, v23

    new-instance v28, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    const/16 v30, 0x0

    const/16 v31, -0x2

    const/16 v32, 0x1

    move/from16 v0, v32

    int-to-float v0, v0

    move/from16 v32, v0

    invoke-direct/range {v29 .. v32}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2159
    move-object/from16 v27, v23

    new-instance v28, Lgtandroid/universal/MainActivity$100000060;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    move-object/from16 v30, v2

    move-object/from16 v31, v3

    move/from16 v32, v11

    invoke-direct/range {v29 .. v32}, Lgtandroid/universal/MainActivity$100000060;-><init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;I)V

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2167
    move-object/from16 v27, v21

    move-object/from16 v28, v22

    invoke-virtual/range {v27 .. v28}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2169
    new-instance v27, Landroid/view/View;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v24, v27

    .line 2170
    move-object/from16 v27, v24

    new-instance v28, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    const/16 v30, 0xa

    const/16 v31, -0x1

    invoke-direct/range {v29 .. v31}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2171
    move-object/from16 v27, v21

    move-object/from16 v28, v24

    invoke-virtual/range {v27 .. v28}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2173
    move-object/from16 v27, v21

    move-object/from16 v28, v23

    invoke-virtual/range {v27 .. v28}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2174
    move-object/from16 v27, v18

    move-object/from16 v28, v21

    invoke-virtual/range {v27 .. v28}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2175
    move-object/from16 v27, v9

    move-object/from16 v28, v18

    invoke-virtual/range {v27 .. v28}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2177
    move/from16 v27, v10

    move-object/from16 v28, v7

    invoke-virtual/range {v28 .. v28}, Lorg/json/JSONArray;->length()I

    move-result v28

    const/16 v29, 0x1

    add-int/lit8 v28, v28, -0x1

    move/from16 v0, v27

    move/from16 v1, v28

    if-ge v0, v1, :cond_4

    .line 2178
    new-instance v27, Landroid/view/View;

    move-object/from16 v38, v27

    move-object/from16 v27, v38

    move-object/from16 v28, v38

    move-object/from16 v29, v2

    invoke-direct/range {v28 .. v29}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v25, v27

    .line 2179
    move-object/from16 v27, v25

    new-instance v28, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    const/16 v30, -0x1

    const/16 v31, 0x5

    invoke-direct/range {v29 .. v31}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v27 .. v28}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2181
    move-object/from16 v27, v9

    move-object/from16 v28, v25

    invoke-virtual/range {v27 .. v28}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2113
    :cond_4
    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_1

    .line 2187
    :catch_0
    move-exception v27

    move-object/from16 v5, v27

    .line 2194
    move-object/from16 v27, v2

    new-instance v28, Ljava/lang/StringBuffer;

    move-object/from16 v38, v28

    move-object/from16 v28, v38

    move-object/from16 v29, v38

    invoke-direct/range {v29 .. v29}, Ljava/lang/StringBuffer;-><init>()V

    const-string v29, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    move-object/from16 v29, v5

    invoke-virtual/range {v29 .. v29}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v28

    const/16 v29, 0x0

    invoke-static/range {v27 .. v29}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Landroid/widget/Toast;->show()V

    goto/16 :goto_2
.end method

.method private showQuickAnswersEditor()V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2289
    move-object v0, p0

    new-instance v6, Landroid/widget/LinearLayout;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v6

    .line 2290
    move-object v6, v2

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2291
    move-object v6, v2

    const/16 v7, 0x14

    const/16 v8, 0x14

    const/16 v9, 0x14

    const/16 v10, 0x14

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 2293
    new-instance v6, Landroid/widget/Button;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v3, v6

    .line 2294
    move-object v6, v3

    const-string v7, "\u2795 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u043e\u0442\u0432\u0435\u0442"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2295
    move-object v6, v3

    const v7, -0xff5600

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    move-object v6, v3

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2296
    move-object v6, v3

    new-instance v7, Lgtandroid/universal/MainActivity$100000062;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity$100000062;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2302
    move-object v6, v2

    move-object v7, v3

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2304
    new-instance v6, Landroid/widget/Button;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 2305
    move-object v6, v4

    const-string v7, "\ud83d\udccb \u0421\u043f\u0438\u0441\u043e\u043a \u043e\u0442\u0432\u0435\u0442\u043e\u0432"

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2306
    move-object v6, v4

    const v7, -0xff9934

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2307
    move-object v6, v4

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2308
    move-object v6, v4

    new-instance v7, Lgtandroid/universal/MainActivity$100000063;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity$100000063;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2314
    move-object v6, v2

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2316
    new-instance v6, Landroid/app/AlertDialog$Builder;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v7, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0431\u044b\u0441\u0442\u0440\u044b\u0445 \u043e\u0442\u0432\u0435\u0442\u043e\u0432"

    invoke-virtual {v6, v7}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    move-object v7, v2

    invoke-virtual {v6, v7}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    const-string v7, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/4 v8, 0x0

    check-cast v8, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v6, v7, v8}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v6

    invoke-virtual {v6}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v6

    return-void
.end method

.method private showQuickAnswersList()V
    .locals 34
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2379
    move-object/from16 v2, p0

    move-object/from16 v23, v2

    :try_start_0
    move-object/from16 v0, v23

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v23, v0

    const-string v24, "quick_answers"

    const-string v25, "[]"

    invoke-interface/range {v23 .. v25}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    move-object/from16 v4, v23

    .line 2380
    new-instance v23, Lorg/json/JSONArray;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v4

    invoke-direct/range {v24 .. v25}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object/from16 v5, v23

    .line 2382
    move-object/from16 v23, v5

    invoke-virtual/range {v23 .. v23}, Lorg/json/JSONArray;->length()I

    move-result v23

    const/16 v24, 0x0

    move/from16 v0, v23

    move/from16 v1, v24

    if-ne v0, v1, :cond_0

    .line 2383
    new-instance v23, Landroid/app/AlertDialog$Builder;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v24, "\u0411\u044b\u0441\u0442\u0440\u044b\u0435 \u043e\u0442\u0432\u0435\u0442\u044b"

    invoke-virtual/range {v23 .. v24}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v23

    const-string v24, "\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442"

    invoke-virtual/range {v23 .. v24}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v23

    const-string v24, "OK"

    const/16 v25, 0x0

    check-cast v25, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v23 .. v25}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v23

    invoke-virtual/range {v23 .. v23}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v23

    .line 2468
    :goto_0
    return-void

    .line 2391
    :cond_0
    new-instance v23, Landroid/widget/ScrollView;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v23

    .line 2392
    new-instance v23, Landroid/widget/LinearLayout;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v7, v23

    .line 2393
    move-object/from16 v23, v7

    const/16 v24, 0x1

    invoke-virtual/range {v23 .. v24}, Landroid/widget/LinearLayout;->setOrientation(I)V

    move-object/from16 v23, v7

    const/16 v24, 0xa

    const/16 v25, 0xa

    const/16 v26, 0xa

    const/16 v27, 0xa

    invoke-virtual/range {v23 .. v27}, Landroid/view/View;->setPadding(IIII)V

    .line 2395
    const/16 v23, 0x0

    move/from16 v8, v23

    :goto_1
    move/from16 v23, v8

    move-object/from16 v24, v5

    invoke-virtual/range {v24 .. v24}, Lorg/json/JSONArray;->length()I

    move-result v24

    move/from16 v0, v23

    move/from16 v1, v24

    if-lt v0, v1, :cond_1

    .line 2459
    move-object/from16 v23, v6

    move-object/from16 v24, v7

    invoke-virtual/range {v23 .. v24}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2461
    new-instance v23, Landroid/app/AlertDialog$Builder;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v24, "\u2550\u2550 \u0411\u042b\u0421\u0422\u0420\u042b\u0415 \u041e\u0422\u0412\u0415\u0422\u042b \u2550\u2550"

    invoke-virtual/range {v23 .. v24}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v23

    move-object/from16 v24, v6

    invoke-virtual/range {v23 .. v24}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v23

    const-string v24, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/16 v25, 0x0

    check-cast v25, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v23 .. v25}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v23

    invoke-virtual/range {v23 .. v23}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v23

    .line 2468
    :goto_2
    goto :goto_0

    .line 2396
    :cond_1
    move/from16 v23, v8

    move/from16 v9, v23

    .line 2397
    move-object/from16 v23, v5

    move/from16 v24, v8

    invoke-virtual/range {v23 .. v24}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v23

    move-object/from16 v10, v23

    .line 2398
    move-object/from16 v23, v10

    const-string v24, "name"

    new-instance v25, Ljava/lang/StringBuffer;

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    invoke-direct/range {v26 .. v26}, Ljava/lang/StringBuffer;-><init>()V

    const-string v26, "\u041e\u0442\u0432\u0435\u0442 "

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v25

    move/from16 v26, v8

    const/16 v27, 0x1

    add-int/lit8 v26, v26, 0x1

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v25

    invoke-virtual/range {v23 .. v25}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    move-object/from16 v11, v23

    .line 2399
    move-object/from16 v23, v10

    const-string v24, "command"

    const-string v25, ""

    invoke-virtual/range {v23 .. v25}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    move-object/from16 v12, v23

    .line 2400
    move-object/from16 v23, v10

    const-string v24, "answer"

    const-string v25, ""

    invoke-virtual/range {v23 .. v25}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    move-object/from16 v13, v23

    .line 2402
    new-instance v23, Landroid/widget/LinearLayout;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v23

    .line 2403
    move-object/from16 v23, v14

    const/16 v24, 0x1

    invoke-virtual/range {v23 .. v24}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2404
    move-object/from16 v23, v14

    const/16 v24, 0xa

    const/16 v25, 0xa

    const/16 v26, 0xa

    const/16 v27, 0xa

    invoke-virtual/range {v23 .. v27}, Landroid/view/View;->setPadding(IIII)V

    .line 2405
    move-object/from16 v23, v14

    const v24, -0xe4e2d8

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2407
    new-instance v23, Landroid/widget/TextView;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v23

    .line 2408
    move-object/from16 v23, v12

    invoke-virtual/range {v23 .. v23}, Ljava/lang/String;->isEmpty()Z

    move-result v23

    if-eqz v23, :cond_3

    const-string v23, "(\u0431\u0435\u0437 \u043a\u043e\u043c\u0430\u043d\u0434\u044b)"

    :goto_3
    move-object/from16 v16, v23

    .line 2409
    move-object/from16 v23, v15

    new-instance v24, Ljava/lang/StringBuffer;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v25, Ljava/lang/StringBuffer;

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    invoke-direct/range {v26 .. v26}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v26, Ljava/lang/StringBuffer;

    move-object/from16 v33, v26

    move-object/from16 v26, v33

    move-object/from16 v27, v33

    invoke-direct/range {v27 .. v27}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v27, Ljava/lang/StringBuffer;

    move-object/from16 v33, v27

    move-object/from16 v27, v33

    move-object/from16 v28, v33

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v28, Ljava/lang/StringBuffer;

    move-object/from16 v33, v28

    move-object/from16 v28, v33

    move-object/from16 v29, v33

    invoke-direct/range {v29 .. v29}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v29, Ljava/lang/StringBuffer;

    move-object/from16 v33, v29

    move-object/from16 v29, v33

    move-object/from16 v30, v33

    invoke-direct/range {v30 .. v30}, Ljava/lang/StringBuffer;-><init>()V

    move/from16 v30, v8

    const/16 v31, 0x1

    add-int/lit8 v30, v30, 0x1

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v29

    const-string v30, ". "

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    invoke-virtual/range {v29 .. v29}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    move-object/from16 v29, v11

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    const-string v28, "\n\ud83d\udcdd \u041a\u043e\u043c\u0430\u043d\u0434\u0430: "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v27

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v26

    move-object/from16 v27, v16

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v26

    invoke-virtual/range {v26 .. v26}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v26

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v25

    const-string v26, "\n\ud83d\udcac \u041e\u0442\u0432\u0435\u0442: "

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v25

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    move-object/from16 v25, v13

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    invoke-virtual/range {v24 .. v24}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v24

    invoke-virtual/range {v23 .. v24}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2410
    move-object/from16 v23, v15

    const v24, -0x12120b

    invoke-virtual/range {v23 .. v24}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2411
    move-object/from16 v23, v14

    move-object/from16 v24, v15

    invoke-virtual/range {v23 .. v24}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2413
    new-instance v23, Landroid/widget/LinearLayout;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v17, v23

    .line 2414
    move-object/from16 v23, v17

    const/16 v24, 0x0

    invoke-virtual/range {v23 .. v24}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2415
    move-object/from16 v23, v17

    const/16 v24, 0x0

    const/16 v25, 0xa

    const/16 v26, 0x0

    const/16 v27, 0x0

    invoke-virtual/range {v23 .. v27}, Landroid/view/View;->setPadding(IIII)V

    .line 2417
    new-instance v23, Landroid/widget/Button;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v18, v23

    .line 2418
    move-object/from16 v23, v18

    const-string v24, "\u270f\ufe0f \u0420\u0435\u0434\u0430\u043a\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c"

    invoke-virtual/range {v23 .. v24}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2419
    move-object/from16 v23, v18

    const v24, -0xff9934

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2420
    move-object/from16 v23, v18

    const/16 v24, -0x1

    invoke-virtual/range {v23 .. v24}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2421
    move-object/from16 v23, v18

    new-instance v24, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    const/16 v26, 0x0

    const/16 v27, -0x2

    const/16 v28, 0x1

    move/from16 v0, v28

    int-to-float v0, v0

    move/from16 v28, v0

    invoke-direct/range {v25 .. v28}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2422
    move-object/from16 v23, v18

    new-instance v24, Lgtandroid/universal/MainActivity$100000065;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    move-object/from16 v26, v2

    move/from16 v27, v9

    move-object/from16 v28, v11

    move-object/from16 v29, v12

    move-object/from16 v30, v13

    invoke-direct/range {v25 .. v30}, Lgtandroid/universal/MainActivity$100000065;-><init>(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2429
    new-instance v23, Landroid/widget/Button;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v19, v23

    .line 2430
    move-object/from16 v23, v19

    const-string v24, "\ud83d\uddd1\ufe0f \u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    invoke-virtual/range {v23 .. v24}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2431
    move-object/from16 v23, v19

    const/high16 v24, -0x340000

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2432
    move-object/from16 v23, v19

    const/16 v24, -0x1

    invoke-virtual/range {v23 .. v24}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2433
    move-object/from16 v23, v19

    new-instance v24, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    const/16 v26, 0x0

    const/16 v27, -0x2

    const/16 v28, 0x1

    move/from16 v0, v28

    int-to-float v0, v0

    move/from16 v28, v0

    invoke-direct/range {v25 .. v28}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2434
    move-object/from16 v23, v19

    new-instance v24, Lgtandroid/universal/MainActivity$100000066;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    move-object/from16 v26, v2

    move/from16 v27, v9

    invoke-direct/range {v25 .. v27}, Lgtandroid/universal/MainActivity$100000066;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2442
    move-object/from16 v23, v17

    move-object/from16 v24, v18

    invoke-virtual/range {v23 .. v24}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2443
    new-instance v23, Landroid/view/View;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v20, v23

    .line 2444
    move-object/from16 v23, v20

    new-instance v24, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    const/16 v26, 0xa

    const/16 v27, -0x1

    invoke-direct/range {v25 .. v27}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2445
    move-object/from16 v23, v17

    move-object/from16 v24, v20

    invoke-virtual/range {v23 .. v24}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2447
    move-object/from16 v23, v17

    move-object/from16 v24, v19

    invoke-virtual/range {v23 .. v24}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2448
    move-object/from16 v23, v14

    move-object/from16 v24, v17

    invoke-virtual/range {v23 .. v24}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2449
    move-object/from16 v23, v7

    move-object/from16 v24, v14

    invoke-virtual/range {v23 .. v24}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2451
    move/from16 v23, v8

    move-object/from16 v24, v5

    invoke-virtual/range {v24 .. v24}, Lorg/json/JSONArray;->length()I

    move-result v24

    const/16 v25, 0x1

    add-int/lit8 v24, v24, -0x1

    move/from16 v0, v23

    move/from16 v1, v24

    if-ge v0, v1, :cond_2

    .line 2452
    new-instance v23, Landroid/view/View;

    move-object/from16 v33, v23

    move-object/from16 v23, v33

    move-object/from16 v24, v33

    move-object/from16 v25, v2

    invoke-direct/range {v24 .. v25}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v21, v23

    .line 2453
    move-object/from16 v23, v21

    new-instance v24, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    const/16 v26, -0x1

    const/16 v27, 0x5

    invoke-direct/range {v25 .. v27}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v23 .. v24}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2455
    move-object/from16 v23, v7

    move-object/from16 v24, v21

    invoke-virtual/range {v23 .. v24}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2395
    :cond_2
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_1

    .line 2408
    :cond_3
    move-object/from16 v23, v12

    goto/16 :goto_3

    .line 2461
    :catch_0
    move-exception v23

    move-object/from16 v4, v23

    .line 2468
    move-object/from16 v23, v2

    new-instance v24, Ljava/lang/StringBuffer;

    move-object/from16 v33, v24

    move-object/from16 v24, v33

    move-object/from16 v25, v33

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuffer;-><init>()V

    const-string v25, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    move-object/from16 v25, v4

    invoke-virtual/range {v25 .. v25}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v25

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    invoke-virtual/range {v24 .. v24}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v24

    const/16 v25, 0x0

    invoke-static/range {v23 .. v25}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v23

    invoke-virtual/range {v23 .. v23}, Landroid/widget/Toast;->show()V

    goto/16 :goto_2
.end method

.method private showSettingsScreen()V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1333
    move-object v0, p0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    invoke-virtual {v6}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 1334
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v0

    const-string v8, "\u2699"

    const-string v9, "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    const v10, -0x57aa01

    invoke-direct {v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->buildScreenHeaderCard(Ljava/lang/String;Ljava/lang/String;I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1336
    new-instance v6, Landroid/widget/LinearLayout;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v6

    .line 1337
    move-object v6, v2

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1338
    move-object v6, v2

    move-object v7, v0

    const/16 v8, 0x14

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v7

    move-object v8, v0

    const/16 v9, 0x8

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    move-object v9, v0

    const/16 v10, 0x14

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v9

    move-object v10, v0

    const/16 v11, 0x14

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 1339
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v2

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1341
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u041a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0430"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1343
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\ud83c\udfa8 \u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u044b"

    const v9, -0x66ff34

    new-instance v10, Lgtandroid/universal/MainActivity$100000032;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000032;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1347
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u0414\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u043e"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1349
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u267f \u0421\u043f\u0435\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0435 \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u0438"

    const v9, -0xff8695

    new-instance v10, Lgtandroid/universal/MainActivity$100000033;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000033;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1353
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u042d\u043a\u0441\u043f\u043e\u0440\u0442/\u0418\u043c\u043f\u043e\u0440\u0442"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1355
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\ud83d\udce5 \u0418\u043c\u043f\u043e\u0440\u0442 CFG"

    const v9, -0xff9934

    new-instance v10, Lgtandroid/universal/MainActivity$100000034;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000034;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1359
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\ud83d\udce4 \u042d\u043a\u0441\u043f\u043e\u0440\u0442 CFG"

    const v9, -0xff5600

    new-instance v10, Lgtandroid/universal/MainActivity$100000035;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000035;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1363
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u0414\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u043a\u0430"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1365
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\ud83d\udc1e \u041b\u043e\u0433\u0438 \u043e\u0448\u0438\u0431\u043e\u043a"

    const v9, -0x33cccd

    new-instance v10, Lgtandroid/universal/MainActivity$100000036;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000036;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1369
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u0410\u0434\u043c\u0438\u043d \u043b\u0432\u043b"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1371
    move-object v6, v0

    const-string v7, "admin_level"

    const/4 v8, 0x1

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v6

    move v3, v6

    .line 1372
    move-object v6, v0

    move-object v7, v2

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v13, v8

    move-object v8, v13

    move-object v9, v13

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "\ud83d\udc51 \u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0430\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440\u0430: "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move v9, v3

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v9, -0x36c3

    new-instance v10, Lgtandroid/universal/MainActivity$100000037;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000037;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1376
    new-instance v6, Landroid/view/View;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 1377
    move-object v6, v4

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    const/4 v9, -0x1

    move-object v10, v0

    const/16 v11, 0x5a

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1378
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method private showSpecialFeaturesScreen()V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1382
    move-object v0, p0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    invoke-virtual {v6}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 1383
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v0

    const-string v8, "\u267f"

    const-string v9, "\u0421\u043f\u0435\u0446. \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u0438"

    const v10, -0xc60078

    invoke-direct {v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->buildScreenHeaderCard(Ljava/lang/String;Ljava/lang/String;I)Landroid/view/View;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1385
    new-instance v6, Landroid/widget/LinearLayout;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v6

    .line 1386
    move-object v6, v2

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1387
    move-object v6, v2

    move-object v7, v0

    const/16 v8, 0x14

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v7

    move-object v8, v0

    const/16 v9, 0x8

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v8

    move-object v9, v0

    const/16 v10, 0x14

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v9

    move-object v10, v0

    const/16 v11, 0x14

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 1388
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v2

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1390
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u041a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0430"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1392
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\ud83d\udccf \u0420\u0430\u0437\u043c\u0435\u0440 \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u044b"

    const v9, -0x66cc34

    new-instance v10, Lgtandroid/universal/MainActivity$100000038;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000038;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1396
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0437\u0430\u0446\u0438\u044f"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1398
    move-object v6, v0

    move-object v7, v2

    invoke-direct {v6, v7}, Lgtandroid/universal/MainActivity;->addAutoReportAndAutoFormToggles(Landroid/widget/LinearLayout;)V

    .line 1400
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u26a1 \u0422\u0440\u0438\u0433\u0433\u0435\u0440\u044b"

    const-string v9, "triggers_enabled"

    const/4 v10, 0x1

    const v11, -0xe161b1    # -2.1084E38f

    invoke-direct/range {v6 .. v11}, Lgtandroid/universal/MainActivity;->addPrefToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 1401
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\ud83d\udfe2 \u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043d\u0430 \u043e\u0442\u0432\u0435\u0447\u0435\u043d\u043d\u044b\u0435 \u0440\u0435\u043f\u043e\u0440\u0442\u044b"

    const-string v9, "trigger_on_answered"

    const/4 v10, 0x0

    const v11, -0xd182ce

    invoke-direct/range {v6 .. v11}, Lgtandroid/universal/MainActivity;->addPrefToggle(Landroid/widget/LinearLayout;Ljava/lang/String;Ljava/lang/String;ZI)V

    .line 1403
    move-object v6, v0

    move-object v7, v2

    const-string v8, "Android"

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MainActivity;->addSectionTitle(Landroid/widget/LinearLayout;Ljava/lang/String;)V

    .line 1405
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\ud83d\udee0\ufe0f \u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0441\u043f\u0435\u0446. \u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e\u0441\u0442\u0438 Android"

    const v9, -0xbaa59c

    new-instance v10, Lgtandroid/universal/MainActivity$100000039;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000039;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1418
    new-instance v6, Landroid/view/View;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v3, v6

    .line 1419
    move-object v6, v3

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    const/4 v9, -0x1

    move-object v10, v0

    const/4 v11, 0x6

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1421
    move-object v6, v2

    move-object v7, v3

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1423
    move-object v6, v0

    move-object v7, v2

    const-string v8, "\u2b05\ufe0f \u041d\u0430\u0437\u0430\u0434 \u0432 \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438"

    const v9, -0x655f4c

    new-instance v10, Lgtandroid/universal/MainActivity$100000040;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    move-object v12, v0

    invoke-direct {v11, v12}, Lgtandroid/universal/MainActivity$100000040;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/MainActivity;->createSettingButton(Landroid/widget/LinearLayout;Ljava/lang/String;ILandroid/view/View$OnClickListener;)V

    .line 1427
    new-instance v6, Landroid/view/View;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v4, v6

    .line 1428
    move-object v6, v4

    new-instance v7, Landroid/widget/LinearLayout$LayoutParams;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    const/4 v9, -0x1

    move-object v10, v0

    const/16 v11, 0x5a

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v10

    invoke-direct {v8, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1429
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void
.end method

.method private showT9Editor()V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 3192
    move-object/from16 v0, p0

    new-instance v11, Landroid/widget/LinearLayout;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v2, v11

    .line 3193
    move-object v11, v2

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3194
    move-object v11, v2

    const/16 v12, 0x14

    const/16 v13, 0x14

    const/16 v14, 0x14

    const/16 v15, 0x14

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/view/View;->setPadding(IIII)V

    .line 3196
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "t9_enabled"

    const/4 v13, 0x1

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v11

    move v3, v11

    .line 3197
    new-instance v11, Landroid/widget/CheckBox;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    move-object v4, v11

    .line 3198
    move-object v11, v4

    const-string v12, "\u04229 \u0432\u043a\u043b\u044e\u0447\u0435\u043d (\u0438\u0441\u043f\u0440\u0430\u0432\u043b\u044f\u0442\u044c \u043e\u0448\u0438\u0431\u043a\u0438 \u043f\u0440\u0438 \u043d\u0430\u0431\u043e\u0440\u0435)"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3199
    move-object v11, v4

    move v12, v3

    invoke-virtual {v11, v12}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 3200
    move-object v11, v4

    new-instance v12, Lgtandroid/universal/MainActivity$100000080;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    move-object v14, v0

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity$100000080;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v11, v12}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 3207
    move-object v11, v2

    move-object v12, v4

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3209
    new-instance v11, Landroid/view/View;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v5, v11

    .line 3210
    move-object v11, v5

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    const/4 v14, -0x1

    const/16 v15, 0xf

    invoke-direct {v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3211
    move-object v11, v2

    move-object v12, v5

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3213
    new-instance v11, Landroid/widget/Button;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v6, v11

    .line 3214
    move-object v11, v6

    const-string v12, "\u2795 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u043b\u043e\u0432\u043e"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3215
    move-object v11, v6

    const v12, -0xff5600

    invoke-virtual {v11, v12}, Landroid/view/View;->setBackgroundColor(I)V

    .line 3216
    move-object v11, v6

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3217
    move-object v11, v6

    new-instance v12, Lgtandroid/universal/MainActivity$100000081;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    move-object v14, v0

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity$100000081;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3223
    move-object v11, v2

    move-object v12, v6

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3225
    new-instance v11, Landroid/widget/Button;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v7, v11

    .line 3226
    move-object v11, v7

    const-string v12, "\ud83d\udccb \u0421\u043f\u0438\u0441\u043e\u043a \u0441\u043b\u043e\u0432"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3227
    move-object v11, v7

    const v12, -0xff9934

    invoke-virtual {v11, v12}, Landroid/view/View;->setBackgroundColor(I)V

    .line 3228
    move-object v11, v7

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3229
    move-object v11, v7

    new-instance v12, Lgtandroid/universal/MainActivity$100000082;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    move-object v14, v0

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity$100000082;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3235
    move-object v11, v2

    move-object v12, v7

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3237
    new-instance v11, Landroid/widget/Button;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v8, v11

    .line 3238
    move-object v11, v8

    const-string v12, "\ud83d\udce5 \u0418\u043c\u043f\u043e\u0440\u0442 \u0441\u043b\u043e\u0432\u0430\u0440\u044f \u04229"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3239
    move-object v11, v8

    const v12, -0x66cc34

    invoke-virtual {v11, v12}, Landroid/view/View;->setBackgroundColor(I)V

    .line 3240
    move-object v11, v8

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3241
    move-object v11, v8

    new-instance v12, Lgtandroid/universal/MainActivity$100000083;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    move-object v14, v0

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity$100000083;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3247
    move-object v11, v2

    move-object v12, v8

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3249
    new-instance v11, Landroid/widget/Button;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v9, v11

    .line 3250
    move-object v11, v9

    const-string v12, "\ud83d\udce4 \u042d\u043a\u0441\u043f\u043e\u0440\u0442 \u0441\u043b\u043e\u0432\u0430\u0440\u044f \u04229"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3251
    move-object v11, v9

    const v12, -0xff7685

    invoke-virtual {v11, v12}, Landroid/view/View;->setBackgroundColor(I)V

    .line 3252
    move-object v11, v9

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3253
    move-object v11, v9

    new-instance v12, Lgtandroid/universal/MainActivity$100000084;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    move-object v14, v0

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity$100000084;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3259
    move-object v11, v2

    move-object v12, v9

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3261
    new-instance v11, Landroid/app/AlertDialog$Builder;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v12, "\u04229 (\u0430\u0432\u0442\u043e\u043a\u043e\u0440\u0440\u0435\u043a\u0446\u0438\u044f)"

    invoke-virtual {v11, v12}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v11

    move-object v12, v2

    invoke-virtual {v11, v12}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v11

    const-string v12, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/4 v13, 0x0

    check-cast v13, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v11, v12, v13}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v11

    invoke-virtual {v11}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v11

    return-void
.end method

.method private showT9WordsList()V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 3318
    move-object/from16 v1, p0

    move-object v14, v1

    invoke-direct {v14}, Lgtandroid/universal/MainActivity;->getT9WordsArray()Lorg/json/JSONArray;

    move-result-object v14

    move-object v3, v14

    .line 3320
    move-object v14, v3

    invoke-virtual {v14}, Lorg/json/JSONArray;->length()I

    move-result v14

    const/4 v15, 0x0

    if-ne v14, v15, :cond_0

    .line 3321
    new-instance v14, Landroid/app/AlertDialog$Builder;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v15, "\u0421\u043b\u043e\u0432\u0430 \u04229"

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    const-string v15, "\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442"

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    const-string v15, "OK"

    const/16 v16, 0x0

    check-cast v16, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v14 .. v16}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    invoke-virtual {v14}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v14

    .line 3374
    :goto_0
    return-void

    .line 3329
    :cond_0
    new-instance v14, Landroid/widget/ScrollView;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v4, v14

    .line 3330
    new-instance v14, Landroid/widget/LinearLayout;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v14

    .line 3331
    move-object v14, v5

    const/4 v15, 0x1

    invoke-virtual {v14, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3332
    move-object v14, v5

    const/16 v15, 0xa

    const/16 v16, 0xa

    const/16 v17, 0xa

    const/16 v18, 0xa

    invoke-virtual/range {v14 .. v18}, Landroid/view/View;->setPadding(IIII)V

    .line 3334
    const/4 v14, 0x0

    move v6, v14

    :goto_1
    move v14, v6

    move-object v15, v3

    invoke-virtual {v15}, Lorg/json/JSONArray;->length()I

    move-result v15

    if-lt v14, v15, :cond_1

    .line 3372
    move-object v14, v4

    move-object v15, v5

    invoke-virtual {v14, v15}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 3374
    new-instance v14, Landroid/app/AlertDialog$Builder;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v20, v16

    move-object/from16 v16, v20

    move-object/from16 v17, v20

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    const-string v17, "\u2550\u2550 \u0421\u041b\u041e\u0412\u0410 \u04229 ("

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    move-object/from16 v17, v3

    invoke-virtual/range {v17 .. v17}, Lorg/json/JSONArray;->length()I

    move-result v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    const-string v16, ") \u2550\u2550"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    move-object v15, v4

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    const-string v15, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/16 v16, 0x0

    check-cast v16, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v14 .. v16}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    invoke-virtual {v14}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v14

    goto/16 :goto_0

    .line 3335
    :cond_1
    move v14, v6

    move v7, v14

    .line 3336
    move-object v14, v3

    move v15, v6

    const-string v16, ""

    invoke-virtual/range {v14 .. v16}, Lorg/json/JSONArray;->optString(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object v8, v14

    .line 3338
    new-instance v14, Landroid/widget/LinearLayout;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v9, v14

    .line 3339
    move-object v14, v9

    const/4 v15, 0x0

    invoke-virtual {v14, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3340
    move-object v14, v9

    const/16 v15, 0xa

    const/16 v16, 0xa

    const/16 v17, 0xa

    const/16 v18, 0xa

    invoke-virtual/range {v14 .. v18}, Landroid/view/View;->setPadding(IIII)V

    .line 3341
    move-object v14, v9

    const v15, -0xe4e2d8

    invoke-virtual {v14, v15}, Landroid/view/View;->setBackgroundColor(I)V

    .line 3343
    new-instance v14, Landroid/widget/TextView;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v10, v14

    .line 3344
    move-object v14, v10

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v20, v16

    move-object/from16 v16, v20

    move-object/from16 v17, v20

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    move/from16 v17, v6

    const/16 v18, 0x1

    add-int/lit8 v17, v17, 0x1

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, ". "

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move-object/from16 v16, v8

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3345
    move-object v14, v10

    const v15, -0x12120b

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3346
    move-object v14, v10

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    const/16 v17, 0x0

    const/16 v18, -0x2

    const/16 v19, 0x1

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    invoke-direct/range {v16 .. v19}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v14, v15}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3347
    move-object v14, v9

    move-object v15, v10

    invoke-virtual {v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3349
    new-instance v14, Landroid/widget/Button;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v11, v14

    .line 3350
    move-object v14, v11

    const-string v15, "\ud83d\uddd1\ufe0f"

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3351
    move-object v14, v11

    const/high16 v15, -0x340000

    invoke-virtual {v14, v15}, Landroid/view/View;->setBackgroundColor(I)V

    .line 3352
    move-object v14, v11

    const/4 v15, -0x1

    invoke-virtual {v14, v15}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3353
    move-object v14, v11

    new-instance v15, Lgtandroid/universal/MainActivity$100000086;

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    move-object/from16 v17, v1

    move/from16 v18, v7

    invoke-direct/range {v16 .. v18}, Lgtandroid/universal/MainActivity$100000086;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual {v14, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3360
    move-object v14, v9

    move-object v15, v11

    invoke-virtual {v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3362
    move-object v14, v5

    move-object v15, v9

    invoke-virtual {v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3364
    move v14, v6

    move-object v15, v3

    invoke-virtual {v15}, Lorg/json/JSONArray;->length()I

    move-result v15

    const/16 v16, 0x1

    add-int/lit8 v15, v15, -0x1

    if-ge v14, v15, :cond_2

    .line 3365
    new-instance v14, Landroid/view/View;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v12, v14

    .line 3366
    move-object v14, v12

    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v20, v15

    move-object/from16 v15, v20

    move-object/from16 v16, v20

    const/16 v17, -0x1

    const/16 v18, 0x5

    invoke-direct/range {v16 .. v18}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v14, v15}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3368
    move-object v14, v5

    move-object v15, v12

    invoke-virtual {v14, v15}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 3334
    :cond_2
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_1
.end method

.method private showTransparencyDialog()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 2701
    move-object v0, p0

    move-object v7, v0

    const-string v8, "keyboard_transparency"

    const/16 v9, 0x64

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/MainActivity;->getIntPref(Ljava/lang/String;I)I

    move-result v7

    move v2, v7

    .line 2703
    new-instance v7, Landroid/widget/LinearLayout;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v7

    .line 2704
    move-object v7, v3

    const/4 v8, 0x1

    invoke-virtual {v7, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2705
    move-object v7, v3

    const/16 v8, 0x1e

    const/16 v9, 0x14

    const/16 v10, 0x1e

    const/16 v11, 0x14

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/view/View;->setPadding(IIII)V

    .line 2707
    new-instance v7, Landroid/widget/TextView;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v4, v7

    .line 2708
    move-object v7, v4

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v12, v9

    move-object v9, v12

    move-object v10, v12

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "\u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move v10, v2

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "%"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2709
    move-object v7, v4

    const/16 v8, 0x12

    int-to-float v8, v8

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextSize(F)V

    move-object v7, v4

    const/16 v8, 0x11

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setGravity(I)V

    .line 2710
    move-object v7, v4

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v11, 0x14

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2711
    move-object v7, v3

    move-object v8, v4

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2713
    new-instance v7, Landroid/widget/SeekBar;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    move-object v5, v7

    .line 2714
    move-object v7, v5

    const/16 v8, 0x64

    invoke-virtual {v7, v8}, Landroid/widget/AbsSeekBar;->setMax(I)V

    .line 2715
    move-object v7, v5

    move v8, v2

    invoke-virtual {v7, v8}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 2716
    move-object v7, v5

    const/16 v8, 0x14

    const/16 v9, 0xa

    const/16 v10, 0x14

    const/16 v11, 0xa

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/view/View;->setPadding(IIII)V

    .line 2717
    move-object v7, v3

    move-object v8, v5

    invoke-virtual {v7, v8}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 2719
    move-object v7, v5

    new-instance v8, Lgtandroid/universal/MainActivity$100000071;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    move-object v10, v0

    move-object v11, v4

    invoke-direct {v9, v10, v11}, Lgtandroid/universal/MainActivity$100000071;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/TextView;)V

    invoke-virtual {v7, v8}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 2736
    new-instance v7, Landroid/app/AlertDialog$Builder;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v8, "\u2550\u2550 \u041f\u0420\u041e\u0417\u0420\u0410\u0427\u041d\u041e\u0421\u0422\u042c \u041a\u041b\u0410\u0412\u0418\u0410\u0422\u0423\u0420\u042b \u2550\u2550"

    invoke-virtual {v7, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    move-object v8, v3

    invoke-virtual {v7, v8}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    const-string v8, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/4 v9, 0x0

    check-cast v9, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v7, v8, v9}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    invoke-virtual {v7}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v7

    return-void
.end method

.method private showTriggerEditDialog(I)V
    .locals 34
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 1601
    move-object/from16 v2, p0

    move/from16 v3, p1

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-object v0, v0, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v17, v0

    invoke-static/range {v17 .. v17}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v17

    move-object/from16 v5, v17

    .line 1602
    move/from16 v17, v3

    const/16 v18, 0x0

    move/from16 v0, v17

    move/from16 v1, v18

    if-lt v0, v1, :cond_4

    move/from16 v17, v3

    move-object/from16 v18, v5

    invoke-interface/range {v18 .. v18}, Ljava/util/List;->size()I

    move-result v18

    move/from16 v0, v17

    move/from16 v1, v18

    if-ge v0, v1, :cond_4

    move-object/from16 v17, v5

    move/from16 v18, v3

    invoke-interface/range {v17 .. v18}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Lgtandroid/universal/TriggerData$Trigger;

    :goto_0
    move-object/from16 v6, v17

    .line 1604
    new-instance v17, Landroid/widget/LinearLayout;

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    move-object/from16 v19, v2

    invoke-direct/range {v18 .. v19}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object/from16 v7, v17

    .line 1605
    move-object/from16 v17, v7

    const/16 v18, 0x1

    invoke-virtual/range {v17 .. v18}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1606
    move-object/from16 v17, v7

    move-object/from16 v18, v2

    const/16 v19, 0x14

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    invoke-direct/range {v18 .. v19}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v18

    move-object/from16 v19, v2

    const/16 v20, 0xe

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v19

    move-object/from16 v20, v2

    const/16 v21, 0x14

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    invoke-direct/range {v20 .. v21}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v20

    move-object/from16 v21, v2

    const/16 v22, 0x6

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-direct/range {v21 .. v22}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v21

    invoke-virtual/range {v17 .. v21}, Landroid/view/View;->setPadding(IIII)V

    .line 1608
    new-instance v17, Landroid/widget/CheckBox;

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    move-object/from16 v19, v2

    invoke-direct/range {v18 .. v19}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    move-object/from16 v8, v17

    .line 1609
    move-object/from16 v17, v8

    const-string v18, "\u0417\u0430\u0445\u043e\u0434\u0438\u0442\u044c \u0432 \u0441\u043b\u0435\u0436\u043a\u0443?"

    invoke-virtual/range {v17 .. v18}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1610
    move-object/from16 v17, v8

    move-object/from16 v18, v6

    if-eqz v18, :cond_0

    move-object/from16 v18, v6

    move-object/from16 v0, v18

    iget-boolean v0, v0, Lgtandroid/universal/TriggerData$Trigger;->follow:Z

    move/from16 v18, v0

    if-nez v18, :cond_5

    :cond_0
    const/16 v18, 0x0

    :goto_1
    invoke-virtual/range {v17 .. v18}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 1611
    move-object/from16 v17, v7

    move-object/from16 v18, v8

    invoke-virtual/range {v17 .. v18}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1613
    new-instance v17, Landroid/widget/TextView;

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    move-object/from16 v19, v2

    invoke-direct/range {v18 .. v19}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v9, v17

    .line 1614
    move-object/from16 v17, v9

    const-string v18, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0441\u043b\u043e\u0432\u043e \u0442\u0440\u0438\u0433\u0433\u0435\u0440:"

    invoke-virtual/range {v17 .. v18}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1615
    move-object/from16 v17, v9

    const/16 v18, 0x0

    move-object/from16 v19, v2

    const/16 v20, 0xa

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v19

    const/16 v20, 0x0

    const/16 v21, 0x0

    invoke-virtual/range {v17 .. v21}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 1616
    move-object/from16 v17, v7

    move-object/from16 v18, v9

    invoke-virtual/range {v17 .. v18}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1618
    new-instance v17, Landroid/widget/EditText;

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    move-object/from16 v19, v2

    invoke-direct/range {v18 .. v19}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v17

    .line 1619
    move-object/from16 v17, v10

    const-string v18, "\u043d\u0430\u043f\u0440\u0438\u043c\u0435\u0440: \u0425\u0435\u043b\u043f"

    invoke-virtual/range {v17 .. v18}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    .line 1620
    move-object/from16 v17, v10

    const/16 v18, 0x1

    invoke-virtual/range {v17 .. v18}, Landroid/widget/TextView;->setSingleLine(Z)V

    .line 1621
    move-object/from16 v17, v6

    if-eqz v17, :cond_1

    move-object/from16 v17, v10

    move-object/from16 v18, v6

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    move-object/from16 v18, v0

    invoke-virtual/range {v17 .. v18}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1622
    :cond_1
    move-object/from16 v17, v7

    move-object/from16 v18, v10

    invoke-virtual/range {v17 .. v18}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1624
    const/16 v17, 0x1

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/String;

    move-object/from16 v17, v0

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    const/16 v19, 0x0

    move-object/from16 v20, v6

    if-eqz v20, :cond_6

    move-object/from16 v20, v6

    move-object/from16 v0, v20

    iget-object v0, v0, Lgtandroid/universal/TriggerData$Trigger;->answerName:Ljava/lang/String;

    move-object/from16 v20, v0

    :goto_2
    aput-object v20, v18, v19

    move-object/from16 v11, v17

    .line 1625
    const/16 v17, 0x1

    move/from16 v0, v17

    new-array v0, v0, [Ljava/lang/String;

    move-object/from16 v17, v0

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    const/16 v19, 0x0

    move-object/from16 v20, v6

    if-eqz v20, :cond_7

    move-object/from16 v20, v6

    move-object/from16 v0, v20

    iget-object v0, v0, Lgtandroid/universal/TriggerData$Trigger;->answerText:Ljava/lang/String;

    move-object/from16 v20, v0

    :goto_3
    aput-object v20, v18, v19

    move-object/from16 v12, v17

    .line 1627
    new-instance v17, Landroid/widget/Button;

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    move-object/from16 v19, v2

    invoke-direct/range {v18 .. v19}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v17

    .line 1628
    move-object/from16 v17, v13

    const/16 v18, 0x0

    invoke-virtual/range {v17 .. v18}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1629
    move-object/from16 v17, v13

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v33, v18

    move-object/from16 v18, v33

    move-object/from16 v19, v33

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    const-string v19, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442: "

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    move-object/from16 v19, v11

    const/16 v20, 0x0

    aget-object v19, v19, v20

    if-eqz v19, :cond_2

    move-object/from16 v19, v11

    const/16 v20, 0x0

    aget-object v19, v19, v20

    invoke-virtual/range {v19 .. v19}, Ljava/lang/String;->isEmpty()Z

    move-result v19

    if-eqz v19, :cond_8

    :cond_2
    const-string v19, "\u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d"

    :goto_4
    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1630
    move-object/from16 v17, v13

    new-instance v18, Lgtandroid/universal/MainActivity$100000045;

    move-object/from16 v33, v18

    move-object/from16 v18, v33

    move-object/from16 v19, v33

    move-object/from16 v20, v2

    move-object/from16 v21, v11

    move-object/from16 v22, v12

    move-object/from16 v23, v13

    invoke-direct/range {v19 .. v23}, Lgtandroid/universal/MainActivity$100000045;-><init>(Lgtandroid/universal/MainActivity;[Ljava/lang/String;[Ljava/lang/String;Landroid/widget/Button;)V

    invoke-virtual/range {v17 .. v18}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1657
    move-object/from16 v17, v7

    move-object/from16 v18, v13

    invoke-virtual/range {v17 .. v18}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1659
    new-instance v17, Landroid/app/AlertDialog$Builder;

    move-object/from16 v33, v17

    move-object/from16 v17, v33

    move-object/from16 v18, v33

    move-object/from16 v19, v2

    invoke-direct/range {v18 .. v19}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    move/from16 v18, v3

    const/16 v19, 0x0

    move/from16 v0, v18

    move/from16 v1, v19

    if-lt v0, v1, :cond_9

    const-string v18, "\u0418\u0437\u043c\u0435\u043d\u0438\u0442\u044c \u0442\u0440\u0438\u0433\u0433\u0435\u0440"

    :goto_5
    invoke-virtual/range {v17 .. v18}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v17

    move-object/from16 v18, v7

    invoke-virtual/range {v17 .. v18}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v17

    const-string v18, "\u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c"

    const/16 v19, 0x0

    check-cast v19, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v17 .. v19}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v17

    const-string v18, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/16 v19, 0x0

    check-cast v19, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v17 .. v19}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v17

    move-object/from16 v14, v17

    .line 1664
    move/from16 v17, v3

    const/16 v18, 0x0

    move/from16 v0, v17

    move/from16 v1, v18

    if-lt v0, v1, :cond_3

    .line 1665
    move-object/from16 v17, v14

    const-string v18, "\u0423\u0434\u0430\u043b\u0438\u0442\u044c"

    new-instance v19, Lgtandroid/universal/MainActivity$100000046;

    move-object/from16 v33, v19

    move-object/from16 v19, v33

    move-object/from16 v20, v33

    move-object/from16 v21, v2

    move/from16 v22, v3

    invoke-direct/range {v20 .. v22}, Lgtandroid/universal/MainActivity$100000046;-><init>(Lgtandroid/universal/MainActivity;I)V

    invoke-virtual/range {v17 .. v19}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v17

    .line 1676
    :cond_3
    move-object/from16 v17, v14

    invoke-virtual/range {v17 .. v17}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object v17

    move-object/from16 v15, v17

    .line 1677
    move-object/from16 v17, v15

    invoke-virtual/range {v17 .. v17}, Landroid/app/Dialog;->show()V

    .line 1678
    move-object/from16 v17, v15

    const/16 v18, -0x1

    invoke-virtual/range {v17 .. v18}, Landroid/app/AlertDialog;->getButton(I)Landroid/widget/Button;

    move-result-object v17

    new-instance v18, Lgtandroid/universal/MainActivity$100000047;

    move-object/from16 v33, v18

    move-object/from16 v18, v33

    move-object/from16 v19, v33

    move-object/from16 v20, v2

    move-object/from16 v21, v10

    move-object/from16 v22, v11

    move-object/from16 v23, v8

    move-object/from16 v24, v12

    move/from16 v25, v3

    move-object/from16 v26, v15

    invoke-direct/range {v19 .. v26}, Lgtandroid/universal/MainActivity$100000047;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;[Ljava/lang/String;Landroid/widget/CheckBox;[Ljava/lang/String;ILandroid/app/AlertDialog;)V

    invoke-virtual/range {v17 .. v18}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    .line 1602
    :cond_4
    const/16 v17, 0x0

    check-cast v17, Lgtandroid/universal/TriggerData$Trigger;

    goto/16 :goto_0

    .line 1610
    :cond_5
    const/16 v18, 0x1

    goto/16 :goto_1

    .line 1624
    :cond_6
    const/16 v20, 0x0

    check-cast v20, Ljava/lang/String;

    goto/16 :goto_2

    .line 1625
    :cond_7
    const/16 v20, 0x0

    check-cast v20, Ljava/lang/String;

    goto/16 :goto_3

    .line 1629
    :cond_8
    move-object/from16 v19, v11

    const/16 v20, 0x0

    aget-object v19, v19, v20

    goto/16 :goto_4

    .line 1659
    :cond_9
    const-string v18, "\u041d\u043e\u0432\u044b\u0439 \u0442\u0440\u0438\u0433\u0433\u0435\u0440"

    goto/16 :goto_5
.end method

.method private showTriggerEditor()V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1515
    move-object/from16 v1, p0

    new-instance v12, Landroid/widget/LinearLayout;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move-object v14, v1

    invoke-direct {v13, v14}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v3, v12

    .line 1516
    move-object v12, v3

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 1517
    move-object v12, v3

    move-object v13, v1

    const/16 v14, 0x14

    int-to-float v14, v14

    invoke-direct {v13, v14}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v13

    move-object v14, v1

    const/16 v15, 0xe

    int-to-float v15, v15

    invoke-direct {v14, v15}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v14

    move-object v15, v1

    const/16 v16, 0x14

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v15

    move-object/from16 v16, v1

    const/16 v17, 0x6

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v16

    invoke-virtual/range {v12 .. v16}, Landroid/view/View;->setPadding(IIII)V

    .line 1519
    const/4 v12, 0x1

    new-array v12, v12, [Landroid/app/AlertDialog;

    move-object v4, v12

    .line 1520
    new-instance v12, Landroid/widget/Button;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move-object v14, v1

    invoke-direct {v13, v14}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v5, v12

    .line 1521
    move-object v12, v5

    const/4 v13, 0x0

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1522
    move-object v12, v5

    const/4 v13, -0x1

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1523
    move-object v12, v1

    move-object v13, v5

    invoke-direct {v12, v13}, Lgtandroid/universal/MainActivity;->updateTriggerMasterButton(Landroid/widget/Button;)V

    .line 1524
    move-object v12, v5

    new-instance v13, Lgtandroid/universal/MainActivity$100000041;

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    move-object v15, v1

    move-object/from16 v16, v5

    invoke-direct/range {v14 .. v16}, Lgtandroid/universal/MainActivity$100000041;-><init>(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V

    invoke-virtual {v12, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1530
    move-object v12, v3

    move-object v13, v5

    invoke-virtual {v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1531
    const/4 v12, 0x4

    new-array v12, v12, [Ljava/lang/String;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    const/4 v14, 0x0

    const-string v15, "\u2795 \u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0441\u043b\u043e\u0432\u043e \u0442\u0440\u0438\u0433\u0433\u0435\u0440"

    aput-object v15, v13, v14

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    const/4 v14, 0x1

    const-string v15, "\ud83d\udccb \u0421\u043f\u0438\u0441\u043e\u043a"

    aput-object v15, v13, v14

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    const/4 v14, 0x2

    const-string v15, "\ud83d\udce5 \u0418\u043c\u043f\u043e\u0440\u0442"

    aput-object v15, v13, v14

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    const/4 v14, 0x3

    const-string v15, "\ud83d\udce4 \u042d\u043a\u0441\u043f\u043e\u0440\u0442"

    aput-object v15, v13, v14

    move-object v6, v12

    .line 1532
    const/4 v12, 0x4

    new-array v12, v12, [I

    fill-array-data v12, :array_0

    move-object v7, v12

    .line 1533
    const/4 v12, 0x0

    move v8, v12

    :goto_0
    move v12, v8

    move-object v13, v6

    array-length v13, v13

    if-lt v12, v13, :cond_0

    .line 1564
    move-object v12, v4

    const/4 v13, 0x0

    new-instance v14, Landroid/app/AlertDialog$Builder;

    move-object/from16 v18, v14

    move-object/from16 v14, v18

    move-object/from16 v15, v18

    move-object/from16 v16, v1

    invoke-direct/range {v15 .. v16}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v15, "\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0442\u0440\u0438\u0433\u0433\u0435\u0440-\u0441\u043b\u043e\u0432\u0430"

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    move-object v15, v3

    invoke-virtual {v14, v15}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    const-string v15, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/16 v16, 0x0

    check-cast v16, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual/range {v14 .. v16}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v14

    invoke-virtual {v14}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v14

    aput-object v14, v12, v13

    return-void

    .line 1534
    :cond_0
    move v12, v8

    move v9, v12

    .line 1535
    new-instance v12, Landroid/widget/Button;

    move-object/from16 v18, v12

    move-object/from16 v12, v18

    move-object/from16 v13, v18

    move-object v14, v1

    invoke-direct {v13, v14}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v10, v12

    .line 1536
    move-object v12, v10

    move-object v13, v6

    move v14, v8

    aget-object v13, v13, v14

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1537
    move-object v12, v10

    const/4 v13, 0x0

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 1538
    move-object v12, v10

    move-object v13, v7

    move v14, v8

    aget v13, v13, v14

    invoke-virtual {v12, v13}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1539
    move-object v12, v10

    const/4 v13, -0x1

    invoke-virtual {v12, v13}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1540
    move-object v12, v10

    new-instance v13, Lgtandroid/universal/MainActivity$100000042;

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    move-object v15, v1

    move-object/from16 v16, v4

    move/from16 v17, v9

    invoke-direct/range {v14 .. v17}, Lgtandroid/universal/MainActivity$100000042;-><init>(Lgtandroid/universal/MainActivity;[Landroid/app/AlertDialog;I)V

    invoke-virtual {v12, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1561
    move-object v12, v3

    move-object v13, v10

    invoke-virtual {v12, v13}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 1533
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    .line 1532
    :array_0
    .array-data 4
        -0xff5600
        -0x559a00
        -0xff9934
        -0xff559a
    .end array-data
.end method

.method private showTriggerList()V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 1578
    move-object v0, p0

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-static {v7}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v7

    move-object v2, v7

    .line 1579
    move-object v7, v2

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_0

    .line 1580
    move-object v7, v0

    const-string v8, "\u0422\u0440\u0438\u0433\u0433\u0435\u0440\u043e\u0432 \u043f\u043e\u043a\u0430 \u043d\u0435\u0442. \u0414\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u043f\u0435\u0440\u0432\u044b\u0439."

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    .line 1581
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/MainActivity;->showTriggerEditor()V

    .line 1589
    :goto_0
    return-void

    .line 1584
    :cond_0
    move-object v7, v2

    invoke-interface {v7}, Ljava/util/List;->size()I

    move-result v7

    new-array v7, v7, [Ljava/lang/String;

    move-object v3, v7

    .line 1585
    const/4 v7, 0x0

    move v4, v7

    :goto_1
    move v7, v4

    move-object v8, v2

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-lt v7, v8, :cond_1

    .line 1589
    new-instance v7, Landroid/app/AlertDialog$Builder;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v8, "\u0421\u043f\u0438\u0441\u043e\u043a \u0442\u0440\u0438\u0433\u0433\u0435\u0440\u043e\u0432 (\u043d\u0430\u0436\u043c\u0438\u0442\u0435, \u0447\u0442\u043e\u0431\u044b \u0438\u0437\u043c\u0435\u043d\u0438\u0442\u044c)"

    invoke-virtual {v7, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    move-object v8, v3

    new-instance v9, Lgtandroid/universal/MainActivity$100000043;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    move-object v11, v0

    invoke-direct {v10, v11}, Lgtandroid/universal/MainActivity$100000043;-><init>(Lgtandroid/universal/MainActivity;)V

    invoke-virtual {v7, v8, v9}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    const-string v8, "\u0417\u0430\u043a\u0440\u044b\u0442\u044c"

    const/4 v9, 0x0

    check-cast v9, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v7, v8, v9}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v7

    invoke-virtual {v7}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v7

    goto :goto_0

    .line 1586
    :cond_1
    move-object v7, v2

    move v8, v4

    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lgtandroid/universal/TriggerData$Trigger;

    move-object v5, v7

    .line 1587
    move-object v7, v3

    move v8, v4

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v13, v10

    move-object v10, v13

    move-object v11, v13

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v13, v11

    move-object v11, v13

    move-object v12, v13

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    move-object v12, v5

    iget-object v12, v12, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, "  \u2192  "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v5

    iget-object v11, v11, Lgtandroid/universal/TriggerData$Trigger;->answerName:Ljava/lang/String;

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move-object v10, v5

    iget-boolean v10, v10, Lgtandroid/universal/TriggerData$Trigger;->follow:Z

    if-eqz v10, :cond_2

    const-string v10, "   \ud83d\udc41 \u0441\u043b\u0435\u0436\u043a\u0430"

    :goto_2
    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    aput-object v9, v7, v8

    .line 1585
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_1

    .line 1587
    :cond_2
    const-string v10, ""

    goto :goto_2
.end method

.method private toggleFloatingMenu()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 834
    move-object v0, p0

    move-object v4, v0

    iget-boolean v4, v4, Lgtandroid/universal/MainActivity;->isFloatingMenuEnabled:Z

    if-eqz v4, :cond_0

    .line 835
    move-object v4, v0

    new-instance v5, Landroid/content/Intent;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move-object v7, v0

    :try_start_0
    const-string v8, "gtandroid.universal.FloatingService"

    invoke-static {v8}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v8

    invoke-direct {v6, v7, v8}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->stopService(Landroid/content/Intent;)Z

    move-result v4

    .line 836
    move-object v4, v0

    const/4 v5, 0x0

    iput-boolean v5, v4, Lgtandroid/universal/MainActivity;->isFloatingMenuEnabled:Z

    .line 846
    :goto_0
    move-object v4, v0

    invoke-direct {v4}, Lgtandroid/universal/MainActivity;->updateToggleButtonStyle()V

    return-void

    .line 835
    :catch_0
    move-exception v4

    move-object v2, v4

    new-instance v4, Ljava/lang/NoClassDefFoundError;

    move-object v12, v4

    move-object v4, v12

    move-object v5, v12

    move-object v6, v2

    invoke-virtual {v6}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v4

    .line 838
    :cond_0
    move-object v4, v0

    invoke-static {v4}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v4

    if-nez v4, :cond_1

    .line 839
    new-instance v4, Landroid/content/Intent;

    move-object v12, v4

    move-object v4, v12

    move-object v5, v12

    const-string v6, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v12, v7

    move-object v7, v12

    move-object v8, v12

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "package:"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    invoke-virtual {v8}, Landroid/content/ContextWrapper;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v7

    invoke-direct {v5, v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    move-object v2, v4

    .line 841
    move-object v4, v0

    move-object v5, v2

    const/16 v6, 0x3e7

    invoke-virtual {v4, v5, v6}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    goto :goto_0

    .line 842
    :cond_1
    move-object v4, v0

    new-instance v5, Landroid/content/Intent;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move-object v7, v0

    :try_start_1
    const-string v8, "gtandroid.universal.FloatingService"

    invoke-static {v8}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    move-result-object v8

    invoke-direct {v6, v7, v8}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v4, v5}, Landroid/content/ContextWrapper;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object v4

    .line 843
    move-object v4, v0

    const/4 v5, 0x1

    iput-boolean v5, v4, Lgtandroid/universal/MainActivity;->isFloatingMenuEnabled:Z

    goto :goto_0

    .line 842
    :catch_1
    move-exception v4

    move-object v2, v4

    new-instance v4, Ljava/lang/NoClassDefFoundError;

    move-object v12, v4

    move-object v4, v12

    move-object v5, v12

    move-object v6, v2

    invoke-virtual {v6}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v4
.end method

.method private updateFamWarCommand(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 3064
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    :try_start_0
    new-instance v11, Lorg/json/JSONArray;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v14, "famwar_commands"

    const-string v15, "[]"

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-direct {v12, v13}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v8, v11

    .line 3066
    new-instance v11, Lorg/json/JSONObject;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    move-object v9, v11

    .line 3067
    move-object v11, v9

    const-string v12, "name"

    move-object v13, v2

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v11

    .line 3068
    move-object v11, v9

    const-string v12, "command"

    move-object v13, v3

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v11

    .line 3069
    move-object v11, v9

    const-string v12, "time"

    move-object v13, v4

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v11

    .line 3070
    move-object v11, v9

    const-string v12, "reason"

    move-object v13, v5

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v11

    .line 3071
    move-object v11, v9

    const-string v12, "minlevel"

    move-object v13, v6

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v11

    .line 3073
    move-object v11, v8

    move v12, v1

    move-object v13, v9

    invoke-virtual {v11, v12, v13}, Lorg/json/JSONArray;->put(ILjava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v11

    .line 3074
    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const-string v12, "famwar_commands"

    move-object v13, v8

    invoke-virtual {v13}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 3076
    :goto_0
    return-void

    .line 3074
    :catch_0
    move-exception v11

    move-object v8, v11

    .line 3076
    move-object v11, v0

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move-object v13, v8

    invoke-virtual {v13}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v13, 0x0

    invoke-static {v11, v12, v13}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v11

    invoke-virtual {v11}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private updateNormalButton(ILjava/lang/String;Ljava/lang/String;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2675
    move-object v0, p0

    move v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    move-object v5, v7

    .line 2676
    move-object v7, v5

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "btn_"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "_name"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    move-object v9, v2

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    .line 2677
    move-object v7, v5

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v11, v8

    move-object v8, v11

    move-object v9, v11

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    const-string v10, "btn_"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    move v10, v1

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "_text"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    move-object v9, v3

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    .line 2678
    move-object v7, v5

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method private updatePunishment(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2259
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    :try_start_0
    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    const-string v14, "punishment_"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v1

    invoke-virtual {v14}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    move-object v9, v13

    .line 2260
    new-instance v13, Lorg/json/JSONArray;

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    move-object v15, v0

    iget-object v15, v15, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object/from16 v16, v9

    const-string v17, "[]"

    invoke-interface/range {v15 .. v17}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-direct {v14, v15}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v10, v13

    .line 2262
    new-instance v13, Lorg/json/JSONObject;

    move-object/from16 v18, v13

    move-object/from16 v13, v18

    move-object/from16 v14, v18

    invoke-direct {v14}, Lorg/json/JSONObject;-><init>()V

    move-object v11, v13

    .line 2263
    move-object v13, v11

    const-string v14, "name"

    move-object v15, v3

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v13

    .line 2264
    move-object v13, v11

    const-string v14, "command"

    move-object v15, v4

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v13

    .line 2265
    move-object v13, v11

    const-string v14, "time"

    move-object v15, v5

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v13

    .line 2266
    move-object v13, v11

    const-string v14, "reason"

    move-object v15, v6

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v13

    .line 2267
    move-object v13, v11

    const-string v14, "minlevel"

    move-object v15, v7

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v13

    .line 2269
    move-object v13, v10

    move v14, v2

    move-object v15, v11

    invoke-virtual {v13, v14, v15}, Lorg/json/JSONArray;->put(ILjava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v13

    .line 2270
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v13}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v13

    move-object v14, v9

    move-object v15, v10

    invoke-virtual {v15}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v13

    invoke-interface {v13}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2272
    :goto_0
    return-void

    .line 2270
    :catch_0
    move-exception v13

    move-object v9, v13

    .line 2272
    move-object v13, v0

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v18, v14

    move-object/from16 v14, v18

    move-object/from16 v15, v18

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    const-string v15, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move-object v15, v9

    invoke-virtual {v15}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x0

    invoke-static {v13, v14, v15}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v13

    invoke-virtual {v13}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private updateQuickAnswer(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 2518
    move-object v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    :try_start_0
    new-instance v9, Lorg/json/JSONArray;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v12, "quick_answers"

    const-string v13, "[]"

    invoke-interface {v11, v12, v13}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-direct {v10, v11}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    move-object v6, v9

    .line 2520
    new-instance v9, Lorg/json/JSONObject;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    move-object v7, v9

    .line 2521
    move-object v9, v7

    const-string v10, "name"

    move-object v11, v2

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v9

    .line 2522
    move-object v9, v7

    const-string v10, "command"

    move-object v11, v3

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v9

    .line 2523
    move-object v9, v7

    const-string v10, "answer"

    move-object v11, v4

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    move-result-object v9

    .line 2525
    move-object v9, v6

    move v10, v1

    move-object v11, v7

    invoke-virtual {v9, v10, v11}, Lorg/json/JSONArray;->put(ILjava/lang/Object;)Lorg/json/JSONArray;

    move-result-object v9

    .line 2526
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const-string v10, "quick_answers"

    move-object v11, v6

    invoke-virtual {v11}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    invoke-interface {v9}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 2528
    :goto_0
    return-void

    .line 2526
    :catch_0
    move-exception v9

    move-object v6, v9

    .line 2528
    move-object v9, v0

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    const-string v11, "\u041e\u0448\u0438\u0431\u043a\u0430: "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v6

    invoke-virtual {v11}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    const/4 v11, 0x0

    invoke-static {v9, v10, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method

.method private updateToggleButtonStyle()V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 811
    move-object v0, p0

    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v2, v5

    .line 812
    move-object v5, v2

    const/4 v6, 0x1

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 813
    move-object v5, v2

    const v6, -0xedebe3

    invoke-virtual {v5, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 815
    move-object v5, v0

    iget-boolean v5, v5, Lgtandroid/universal/MainActivity;->isFloatingMenuEnabled:Z

    if-eqz v5, :cond_0

    .line 817
    const v5, -0xc60078

    move v3, v5

    .line 818
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    const-string v6, "ON"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 823
    :goto_0
    move-object v5, v2

    move-object v6, v0

    const/4 v7, 0x4

    int-to-float v7, v7

    invoke-direct {v6, v7}, Lgtandroid/universal/MainActivity;->dp(F)I

    move-result v6

    move v7, v3

    invoke-virtual {v5, v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 825
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    move-object v6, v2

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 826
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    move v6, v3

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 827
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    const/16 v6, 0x1c

    int-to-float v6, v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 828
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    const/4 v6, 0x0

    check-cast v6, Landroid/graphics/Typeface;

    const/4 v7, 0x1

    invoke-virtual {v5, v6, v7}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 829
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    const/16 v6, 0x11

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 830
    move-object v5, v0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    move v7, v3

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/MainActivity;->applyNeonGlow(Landroid/widget/TextView;I)V

    return-void

    .line 820
    :cond_0
    const v5, -0xb293

    move v3, v5

    .line 821
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->btnToggleMenu:Landroid/widget/Button;

    const-string v6, "OFF"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_0
.end method

.method private updateTriggerMasterButton(Landroid/widget/Button;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/Button;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1572
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "triggers_enabled"

    const/4 v7, 0x1

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    move v3, v5

    .line 1573
    move-object v5, v1

    move v6, v3

    if-eqz v6, :cond_0

    const-string v6, "\u0422\u0440\u0438\u0433\u0433\u0435\u0440\u044b: \u0412\u041a\u041b"

    :goto_0
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1574
    move-object v5, v1

    move v6, v3

    if-eqz v6, :cond_1

    const v6, -0xe161b1    # -2.1084E38f

    :goto_1
    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    return-void

    .line 1573
    :cond_0
    const-string v6, "\u0422\u0440\u0438\u0433\u0433\u0435\u0440\u044b: \u0412\u042b\u041a\u041b"

    goto :goto_0

    .line 1574
    :cond_1
    const v6, -0x4fcfd0

    goto :goto_1
.end method

.method private withAlpha(II)I
    .locals 7

    .prologue
    .line 99
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v4, v2

    const/16 v5, 0x18

    shl-int/lit8 v4, v4, 0x18

    move v5, v1

    const v6, 0xffffff

    and-int/2addr v5, v6

    or-int/2addr v4, v5

    move v0, v4

    return v0
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 851
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object v7, v0

    move v8, v1

    move v9, v2

    move-object v10, v3

    invoke-super {v7, v8, v9, v10}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    .line 853
    move v7, v1

    const/16 v8, 0x28e

    if-ne v7, v8, :cond_1

    .line 854
    move v7, v2

    const/4 v8, -0x1

    if-ne v7, v8, :cond_0

    .line 855
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/MainActivity;->initUI()V

    .line 892
    :goto_0
    return-void

    .line 857
    :cond_0
    move-object v7, v0

    invoke-virtual {v7}, Landroid/app/Activity;->finish()V

    goto :goto_0

    .line 862
    :cond_1
    move v7, v1

    const/16 v8, 0x3e7

    if-ne v7, v8, :cond_3

    .line 863
    move-object v7, v0

    invoke-static {v7}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v7

    if-eqz v7, :cond_2

    .line 864
    move-object v7, v0

    new-instance v8, Landroid/content/Intent;

    move-object v15, v8

    move-object v8, v15

    move-object v9, v15

    move-object v10, v0

    :try_start_0
    const-string v11, "gtandroid.universal.FloatingService"

    invoke-static {v11}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v11

    invoke-direct {v9, v10, v11}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {v7, v8}, Landroid/content/ContextWrapper;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object v7

    .line 865
    move-object v7, v0

    const/4 v8, 0x1

    iput-boolean v8, v7, Lgtandroid/universal/MainActivity;->isFloatingMenuEnabled:Z

    .line 866
    move-object v7, v0

    invoke-direct {v7}, Lgtandroid/universal/MainActivity;->updateToggleButtonStyle()V

    .line 867
    move-object v7, v0

    const-string v8, "\u041f\u043b\u0430\u0432\u0430\u044e\u0449\u0435\u0435 \u043c\u0435\u043d\u044e \u0432\u043a\u043b\u044e\u0447\u0435\u043d\u043e"

    const/4 v9, 0x0

    invoke-static {v7, v8, v9}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v7

    invoke-virtual {v7}, Landroid/widget/Toast;->show()V

    .line 869
    :cond_2
    goto :goto_0

    .line 864
    :catch_0
    move-exception v7

    move-object v5, v7

    new-instance v7, Ljava/lang/NoClassDefFoundError;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    move-object v9, v5

    invoke-virtual {v9}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v9

    invoke-direct {v8, v9}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v7

    .line 872
    :cond_3
    move v7, v2

    const/4 v8, -0x1

    if-ne v7, v8, :cond_4

    move-object v7, v3

    if-eqz v7, :cond_4

    move-object v7, v3

    invoke-virtual {v7}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v7

    if-eqz v7, :cond_4

    .line 873
    move-object v7, v3

    invoke-virtual {v7}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v7

    move-object v5, v7

    .line 875
    move v7, v1

    const/16 v8, 0x309

    if-ne v7, v8, :cond_5

    .line 876
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->importFromFile(Landroid/net/Uri;)V

    .line 892
    :cond_4
    :goto_1
    goto :goto_0

    .line 877
    :cond_5
    move v7, v1

    const/16 v8, 0x378

    if-ne v7, v8, :cond_6

    .line 878
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->exportToFile(Landroid/net/Uri;)V

    goto :goto_1

    .line 879
    :cond_6
    move v7, v1

    const/16 v8, 0x303

    if-ne v7, v8, :cond_7

    .line 880
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->importT9FromFile(Landroid/net/Uri;)V

    goto :goto_1

    .line 881
    :cond_7
    move v7, v1

    const/16 v8, 0x371

    if-ne v7, v8, :cond_8

    .line 882
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->exportT9ToFile(Landroid/net/Uri;)V

    goto :goto_1

    .line 883
    :cond_8
    move v7, v1

    const/16 v8, 0x3df

    if-ne v7, v8, :cond_9

    .line 884
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->exportLogToFile(Landroid/net/Uri;)V

    goto :goto_1

    .line 885
    :cond_9
    move v7, v1

    const/16 v8, 0x295

    if-ne v7, v8, :cond_a

    .line 886
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->importNavigatorFromFile(Landroid/net/Uri;)V

    goto :goto_1

    .line 887
    :cond_a
    move v7, v1

    const/16 v8, 0x296

    if-ne v7, v8, :cond_b

    .line 888
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->exportNavigatorToFile(Landroid/net/Uri;)V

    goto :goto_1

    .line 889
    :cond_b
    move v7, v1

    const/16 v8, 0x297

    if-ne v7, v8, :cond_c

    .line 890
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->importTriggersFromFile(Landroid/net/Uri;)V

    goto :goto_1

    .line 891
    :cond_c
    move v7, v1

    const/16 v8, 0x298

    if-ne v7, v8, :cond_4

    .line 892
    move-object v7, v0

    move-object v8, v5

    invoke-direct {v7, v8}, Lgtandroid/universal/MainActivity;->exportTriggersToFile(Landroid/net/Uri;)V

    goto :goto_1
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Bundle;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 119
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-super {v3, v4}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 120
    move-object v3, v0

    const-string v4, "MainActivity"

    invoke-static {v3, v4}, Lgtandroid/universal/AppLogger;->installCrashHandler(Landroid/content/Context;Ljava/lang/String;)V

    .line 121
    move-object v3, v0

    move-object v4, v0

    const-string v5, "GTAndroidData"

    const/4 v6, 0x0

    invoke-virtual {v4, v5, v6}, Landroid/content/ContextWrapper;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v4

    iput-object v4, v3, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    .line 122
    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->loadCustomButtons()V

    .line 124
    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/MainActivity;->initUI()V

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 6
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 385
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-virtual {v3}, Landroid/app/Activity;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v3

    const/high16 v4, 0x7f080000

    move-object v5, v1

    invoke-virtual {v3, v4, v5}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 386
    const/4 v3, 0x1

    move v0, v3

    return v0
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 7
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 391
    move-object v0, p0

    move-object v1, p1

    move-object v5, v1

    invoke-interface {v5}, Landroid/view/MenuItem;->getItemId()I

    move-result v5

    move v3, v5

    .line 392
    move v5, v3

    const v6, 0x7f09007a

    if-ne v5, v6, :cond_0

    .line 393
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/MainActivity;->showMainScreen()V

    .line 394
    const/4 v5, 0x1

    move v0, v5

    .line 402
    :goto_0
    return v0

    .line 395
    :cond_0
    move v5, v3

    const v6, 0x7f09007b

    if-ne v5, v6, :cond_1

    .line 396
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/MainActivity;->showEditorScreen()V

    .line 397
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 398
    :cond_1
    move v5, v3

    const v6, 0x7f09007c

    if-ne v5, v6, :cond_2

    .line 399
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/MainActivity;->showSettingsScreen()V

    .line 400
    const/4 v5, 0x1

    move v0, v5

    goto :goto_0

    .line 402
    :cond_2
    move-object v5, v0

    move-object v6, v1

    invoke-super {v5, v6}, Landroid/app/Activity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result v5

    move v0, v5

    goto :goto_0
.end method
