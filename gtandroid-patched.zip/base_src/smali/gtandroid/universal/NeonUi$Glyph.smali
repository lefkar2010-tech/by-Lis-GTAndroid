.class public Lgtandroid/universal/NeonUi$Glyph;
.super Landroid/graphics/drawable/Drawable;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "Glyph"
.end annotation


# instance fields
.field private final color:I

.field private final p:Landroid/graphics/Paint;

.field private final path:Landroid/graphics/Path;

.field private final rf:Landroid/graphics/RectF;

.field private final sizePx:I

.field private final type:I


# direct methods
.method public constructor <init>(III)V
    .locals 10

    .prologue
    .line 860
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v3, p3

    move-object v5, v0

    invoke-direct {v5}, Landroid/graphics/drawable/Drawable;-><init>()V

    move-object v5, v0

    new-instance v6, Landroid/graphics/Paint;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    const/4 v8, 0x1

    invoke-direct {v7, v8}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v6, v5, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    move-object v5, v0

    new-instance v6, Landroid/graphics/RectF;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Landroid/graphics/RectF;-><init>()V

    iput-object v6, v5, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    move-object v5, v0

    new-instance v6, Landroid/graphics/Path;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Landroid/graphics/Path;-><init>()V

    iput-object v6, v5, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    .line 861
    move-object v5, v0

    move v6, v1

    iput v6, v5, Lgtandroid/universal/NeonUi$Glyph;->type:I

    .line 862
    move-object v5, v0

    move v6, v2

    iput v6, v5, Lgtandroid/universal/NeonUi$Glyph;->sizePx:I

    .line 863
    move-object v5, v0

    move v6, v3

    iput v6, v5, Lgtandroid/universal/NeonUi$Glyph;->color:I

    return-void
.end method

.method private fillCircle(Landroid/graphics/Canvas;FFFZ)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            "FFFZ)V"
        }
    .end annotation

    .prologue
    .line 890
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move v7, v5

    if-eqz v7, :cond_0

    .line 895
    :goto_0
    return-void

    .line 891
    :cond_0
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    sget-object v8, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 892
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/NeonUi$Glyph;->color:I

    const/16 v9, 0x3c

    invoke-static {v8, v9}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v8

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    .line 893
    move-object v7, v1

    move v8, v2

    move v9, v3

    move v10, v4

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 894
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    sget-object v8, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 895
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/NeonUi$Glyph;->color:I

    invoke-virtual {v7, v8}, Landroid/graphics/Paint;->setColor(I)V

    goto :goto_0
.end method

.method private fillPath(Landroid/graphics/Canvas;Z)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            "Z)V"
        }
    .end annotation

    .prologue
    .line 899
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v4, v2

    if-eqz v4, :cond_0

    .line 904
    :goto_0
    return-void

    .line 900
    :cond_0
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 901
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/NeonUi$Glyph;->color:I

    const/16 v6, 0x3c

    invoke-static {v5, v6}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 902
    move-object v4, v1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v4, v5, v6}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 903
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 904
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/NeonUi$Glyph;->color:I

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    goto :goto_0
.end method

.method private shape(Landroid/graphics/Canvas;Z)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            "Z)V"
        }
    .end annotation

    .prologue
    .line 908
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->reset()V

    .line 909
    move-object v7, v0

    iget v7, v7, Lgtandroid/universal/NeonUi$Glyph;->type:I

    packed-switch v7, :pswitch_data_0

    .line 1129
    :goto_0
    return-void

    .line 911
    :pswitch_0
    move-object v7, v0

    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41200000    # 10.0f

    move v12, v2

    invoke-direct/range {v7 .. v12}, Lgtandroid/universal/NeonUi$Glyph;->fillCircle(Landroid/graphics/Canvas;FFFZ)V

    .line 912
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41200000    # 10.0f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 913
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x4119999a    # 9.6f

    const v10, 0x40466666    # 3.1f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 914
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v8, 0x40c66666    # 6.2f

    const v9, 0x41666666    # 14.4f

    const v10, 0x418e6666    # 17.8f

    const/high16 v11, 0x41d00000    # 26.0f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 915
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x43570000    # 215.0f

    const/high16 v10, 0x42dc0000    # 110.0f

    const/4 v11, 0x0

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 916
    goto :goto_0

    .line 919
    :pswitch_1
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40200000    # 2.5f

    const/high16 v9, 0x41400000    # 12.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 920
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40c00000    # 6.0f

    const v9, 0x40c66666    # 6.2f

    const/high16 v10, 0x41900000    # 18.0f

    const v11, 0x40c66666    # 6.2f

    const/high16 v12, 0x41ac0000    # 21.5f

    const/high16 v13, 0x41400000    # 12.0f

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 921
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41900000    # 18.0f

    const v9, 0x418e6666    # 17.8f

    const/high16 v10, 0x40c00000    # 6.0f

    const v11, 0x418e6666    # 17.8f

    const/high16 v12, 0x40200000    # 2.5f

    const/high16 v13, 0x41400000    # 12.0f

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 922
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$Glyph;->fillPath(Landroid/graphics/Canvas;Z)V

    .line 923
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 924
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x40400000    # 3.0f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 925
    move-object v7, v1

    const/high16 v8, 0x40900000    # 4.5f

    const/high16 v9, 0x41a00000    # 20.0f

    const/high16 v10, 0x419c0000    # 19.5f

    const/high16 v11, 0x40800000    # 4.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 926
    goto/16 :goto_0

    .line 929
    :pswitch_2
    move-object v7, v1

    invoke-virtual {v7}, Landroid/graphics/Canvas;->save()I

    move-result v7

    .line 930
    move-object v7, v1

    const/high16 v8, -0x3dcc0000    # -45.0f

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41400000    # 12.0f

    invoke-virtual {v7, v8, v9, v10}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 931
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40c00000    # 6.0f

    const v9, 0x40866666    # 4.2f

    const/high16 v10, 0x41900000    # 18.0f

    const v11, 0x4119999a    # 9.6f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 932
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3fb33333    # 1.4f

    const v10, 0x3fb33333    # 1.4f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 933
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x4119999a    # 9.6f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x419c0000    # 19.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 934
    move-object v7, v1

    invoke-virtual {v7}, Landroid/graphics/Canvas;->restore()V

    .line 935
    move-object v7, v1

    const/high16 v8, 0x40900000    # 4.5f

    const/high16 v9, 0x41a80000    # 21.0f

    const/high16 v10, 0x41600000    # 14.0f

    const/high16 v11, 0x41a80000    # 21.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 936
    goto/16 :goto_0

    .line 939
    :pswitch_3
    move-object v7, v1

    const v8, 0x4099999a    # 4.8f

    const v9, 0x4199999a    # 19.2f

    const v10, 0x41466666    # 12.4f

    const v11, 0x4139999a    # 11.6f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 940
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v8, 0x41366666    # 11.4f

    const v9, 0x40333333    # 2.8f

    const v10, 0x41a4cccd    # 20.6f

    const/high16 v11, 0x41400000    # 12.0f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 941
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x41700000    # 15.0f

    const/high16 v10, 0x43700000    # 240.0f

    const/4 v11, 0x0

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 942
    goto/16 :goto_0

    .line 945
    :pswitch_4
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40400000    # 3.0f

    const/high16 v9, 0x41300000    # 11.0f

    const/high16 v10, 0x41a80000    # 21.0f

    const/high16 v11, 0x41900000    # 18.0f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 946
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$Glyph;->fillPath(Landroid/graphics/Canvas;Z)V

    .line 947
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x40200000    # 2.5f

    const/high16 v10, 0x40200000    # 2.5f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 948
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x40c66666    # 6.2f

    const/high16 v9, 0x41300000    # 11.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 949
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x41066666    # 8.4f

    const v9, 0x40d33333    # 6.6f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 950
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x4179999a    # 15.6f

    const v9, 0x40d33333    # 6.6f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 951
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x418e6666    # 17.8f

    const/high16 v9, 0x41300000    # 11.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 952
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 953
    move-object v7, v1

    const v8, 0x40f33333    # 7.6f

    const v9, 0x4191999a    # 18.2f

    const v10, 0x3ff33333    # 1.9f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 954
    move-object v7, v1

    const v8, 0x41833333    # 16.4f

    const v9, 0x4191999a    # 18.2f

    const v10, 0x3ff33333    # 1.9f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 955
    goto/16 :goto_0

    .line 958
    :pswitch_5
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41a00000    # 20.0f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x40a00000    # 5.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 959
    move-object v7, v1

    const v8, 0x40c66666    # 6.2f

    const v9, 0x4129999a    # 10.6f

    const/high16 v10, 0x41400000    # 12.0f

    const v11, 0x4099999a    # 4.8f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 960
    move-object v7, v1

    const v8, 0x418e6666    # 17.8f

    const v9, 0x4129999a    # 10.6f

    const/high16 v10, 0x41400000    # 12.0f

    const v11, 0x4099999a    # 4.8f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 961
    goto/16 :goto_0

    .line 964
    :pswitch_6
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x40400000    # 3.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 965
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41a00000    # 20.0f

    const/high16 v9, 0x40f00000    # 7.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 966
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41a00000    # 20.0f

    const/high16 v9, 0x41840000    # 16.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 967
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41a80000    # 21.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 968
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40800000    # 4.0f

    const/high16 v9, 0x41840000    # 16.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 969
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40800000    # 4.0f

    const/high16 v9, 0x40f00000    # 7.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 970
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->close()V

    .line 971
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$Glyph;->fillPath(Landroid/graphics/Canvas;Z)V

    .line 972
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 973
    move-object v7, v1

    const/high16 v8, 0x40800000    # 4.0f

    const/high16 v9, 0x40f00000    # 7.5f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41400000    # 12.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 974
    move-object v7, v1

    const/high16 v8, 0x41a00000    # 20.0f

    const/high16 v9, 0x40f00000    # 7.5f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41400000    # 12.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 975
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41a80000    # 21.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 976
    goto/16 :goto_0

    .line 979
    :pswitch_7
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40600000    # 3.5f

    const/high16 v9, 0x41600000    # 14.0f

    const/high16 v10, 0x40d00000    # 6.5f

    const/high16 v11, 0x41a40000    # 20.5f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 980
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3f4ccccd    # 0.8f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 981
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x41080000    # 8.5f

    const/high16 v9, 0x41280000    # 10.5f

    const/high16 v10, 0x41380000    # 11.5f

    const/high16 v11, 0x41a40000    # 20.5f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 982
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3f4ccccd    # 0.8f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 983
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x41580000    # 13.5f

    const/high16 v9, 0x40e00000    # 7.0f

    const/high16 v10, 0x41840000    # 16.5f

    const/high16 v11, 0x41a40000    # 20.5f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 984
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3f4ccccd    # 0.8f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 985
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x41940000    # 18.5f

    const/high16 v9, 0x40600000    # 3.5f

    const/high16 v10, 0x41ac0000    # 21.5f

    const/high16 v11, 0x41a40000    # 20.5f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 986
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3f4ccccd    # 0.8f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 987
    goto/16 :goto_0

    .line 990
    :pswitch_8
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40900000    # 4.5f

    const/high16 v9, 0x40600000    # 3.5f

    const/high16 v10, 0x41680000    # 14.5f

    const/high16 v11, 0x41a40000    # 20.5f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 991
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3fe66666    # 1.8f

    const v10, 0x3fe66666    # 1.8f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 992
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v8, 0x40d9999a    # 6.8f

    const/high16 v9, 0x40d00000    # 6.5f

    const v10, 0x41433333    # 12.2f

    const/high16 v11, 0x41300000    # 11.0f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 993
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3f4ccccd    # 0.8f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 994
    move-object v7, v1

    const/high16 v8, 0x40400000    # 3.0f

    const/high16 v9, 0x41a40000    # 20.5f

    const/high16 v10, 0x41800000    # 16.0f

    const/high16 v11, 0x41a40000    # 20.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 995
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41680000    # 14.5f

    const/high16 v9, 0x41100000    # 9.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 996
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41900000    # 18.0f

    const/high16 v9, 0x41100000    # 9.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 997
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41900000    # 18.0f

    const/high16 v9, 0x41840000    # 16.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 998
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41a00000    # 20.0f

    const/high16 v9, 0x41840000    # 16.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 999
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41a00000    # 20.0f

    const/high16 v9, 0x41000000    # 8.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1000
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x418c0000    # 17.5f

    const/high16 v9, 0x40b00000    # 5.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1001
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1002
    goto/16 :goto_0

    .line 1005
    :pswitch_9
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40200000    # 2.5f

    const/high16 v9, 0x40b00000    # 5.5f

    const/high16 v10, 0x41ac0000    # 21.5f

    const/high16 v11, 0x41940000    # 18.5f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1006
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x400ccccd    # 2.2f

    const v10, 0x400ccccd    # 2.2f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1007
    move-object v7, v1

    const v8, 0x41033333    # 8.2f

    const v9, 0x412ccccd    # 10.8f

    const/high16 v10, 0x40000000    # 2.0f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1008
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v8, 0x4099999a    # 4.8f

    const/high16 v9, 0x41500000    # 13.0f

    const v10, 0x4139999a    # 11.6f

    const v11, 0x419e6666    # 19.8f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1009
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x434d0000    # 205.0f

    const/high16 v10, 0x43020000    # 130.0f

    const/4 v11, 0x0

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 1010
    move-object v7, v1

    const/high16 v8, 0x41580000    # 13.5f

    const/high16 v9, 0x41200000    # 10.0f

    const/high16 v10, 0x41940000    # 18.5f

    const/high16 v11, 0x41200000    # 10.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1011
    move-object v7, v1

    const/high16 v8, 0x41580000    # 13.5f

    const v9, 0x4159999a    # 13.6f

    const/high16 v10, 0x41940000    # 18.5f

    const v11, 0x4159999a    # 13.6f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1012
    goto/16 :goto_0

    .line 1015
    :pswitch_a
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40b00000    # 5.5f

    const/high16 v9, 0x40900000    # 4.5f

    const/high16 v10, 0x41940000    # 18.5f

    const/high16 v11, 0x41a80000    # 21.0f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1016
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x40000000    # 2.0f

    const/high16 v10, 0x40000000    # 2.0f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1017
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x41100000    # 9.0f

    const v9, 0x40333333    # 2.8f

    const/high16 v10, 0x41700000    # 15.0f

    const v11, 0x40cccccd    # 6.4f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1018
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x3f800000    # 1.0f

    const/high16 v10, 0x3f800000    # 1.0f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1019
    const/4 v7, 0x0

    move v4, v7

    :goto_1
    move v7, v4

    const/4 v8, 0x3

    if-lt v7, v8, :cond_0

    .line 1024
    goto/16 :goto_0

    .line 1020
    :cond_0
    const v7, 0x412ccccd    # 10.8f

    move v8, v4

    int-to-float v8, v8

    const/high16 v9, 0x40600000    # 3.5f

    mul-float/2addr v8, v9

    add-float/2addr v7, v8

    move v5, v7

    .line 1021
    move-object v7, v1

    const/high16 v8, 0x41100000    # 9.0f

    move v9, v5

    const v10, 0x3f19999a    # 0.6f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1022
    move-object v7, v1

    const/high16 v8, 0x41380000    # 11.5f

    move v9, v5

    const/high16 v10, 0x41800000    # 16.0f

    move v11, v5

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1019
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    .line 1027
    :pswitch_b
    const/4 v7, 0x0

    move v4, v7

    :goto_2
    move v7, v4

    const/4 v8, 0x3

    if-lt v7, v8, :cond_1

    .line 1037
    goto/16 :goto_0

    .line 1028
    :cond_1
    move-object v7, v1

    invoke-virtual {v7}, Landroid/graphics/Canvas;->save()I

    move-result v7

    .line 1029
    move-object v7, v1

    move v8, v4

    int-to-float v8, v8

    const/high16 v9, 0x42700000    # 60.0f

    mul-float/2addr v8, v9

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41400000    # 12.0f

    invoke-virtual {v7, v8, v9, v10}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 1030
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x40200000    # 2.5f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41ac0000    # 21.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1031
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x40b33333    # 5.6f

    const v10, 0x411e6666    # 9.9f

    const/high16 v11, 0x40600000    # 3.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1032
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x40b33333    # 5.6f

    const v10, 0x4161999a    # 14.1f

    const/high16 v11, 0x40600000    # 3.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1033
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x41933333    # 18.4f

    const v10, 0x411e6666    # 9.9f

    const/high16 v11, 0x41a40000    # 20.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1034
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x41933333    # 18.4f

    const v10, 0x4161999a    # 14.1f

    const/high16 v11, 0x41a40000    # 20.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1035
    move-object v7, v1

    invoke-virtual {v7}, Landroid/graphics/Canvas;->restore()V

    .line 1027
    add-int/lit8 v4, v4, 0x1

    goto :goto_2

    .line 1040
    :pswitch_c
    move-object v7, v0

    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41400000    # 12.0f

    const v11, 0x4119999a    # 9.6f

    move v12, v2

    invoke-direct/range {v7 .. v12}, Lgtandroid/universal/NeonUi$Glyph;->fillCircle(Landroid/graphics/Canvas;FFFZ)V

    .line 1041
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41400000    # 12.0f

    const v10, 0x4119999a    # 9.6f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1042
    move-object v7, v1

    const v8, 0x40f33333    # 7.6f

    const v9, 0x40f33333    # 7.6f

    const v10, 0x41833333    # 16.4f

    const v11, 0x41833333    # 16.4f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1043
    move-object v7, v1

    const v8, 0x41833333    # 16.4f

    const v9, 0x40f33333    # 7.6f

    const v10, 0x40f33333    # 7.6f

    const v11, 0x41833333    # 16.4f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1044
    goto/16 :goto_0

    .line 1047
    :pswitch_d
    move-object v7, v0

    move-object v8, v1

    const/high16 v9, 0x41400000    # 12.0f

    const/high16 v10, 0x41180000    # 9.5f

    const v11, 0x40c66666    # 6.2f

    move v12, v2

    invoke-direct/range {v7 .. v12}, Lgtandroid/universal/NeonUi$Glyph;->fillCircle(Landroid/graphics/Canvas;FFFZ)V

    .line 1048
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41180000    # 9.5f

    const v10, 0x40c66666    # 6.2f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1049
    move-object v7, v1

    const v8, 0x40f33333    # 7.6f

    const v9, 0x41633333    # 14.2f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41ac0000    # 21.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1050
    move-object v7, v1

    const v8, 0x41833333    # 16.4f

    const v9, 0x41633333    # 14.2f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41ac0000    # 21.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1051
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41180000    # 9.5f

    const v10, 0x400ccccd    # 2.2f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1052
    goto/16 :goto_0

    .line 1055
    :pswitch_e
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40400000    # 3.0f

    const/high16 v9, 0x40f00000    # 7.5f

    const/high16 v10, 0x41a40000    # 20.5f

    const/high16 v11, 0x41480000    # 12.5f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1056
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v9, 0x3f99999a    # 1.2f

    const v10, 0x3f99999a    # 1.2f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1057
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40d00000    # 6.5f

    const/high16 v9, 0x41480000    # 12.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1058
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40d00000    # 6.5f

    const/high16 v9, 0x41980000    # 19.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1059
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x412ccccd    # 10.8f

    const/high16 v9, 0x41980000    # 19.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1060
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x4139999a    # 11.6f

    const/high16 v9, 0x41480000    # 12.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1061
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1062
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const v8, 0x4139999a    # 11.6f

    const/high16 v9, 0x41280000    # 10.5f

    const v10, 0x41833333    # 16.4f

    const/high16 v11, 0x41800000    # 16.0f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1063
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/4 v9, 0x0

    const/high16 v10, 0x43340000    # 180.0f

    const/4 v11, 0x0

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 1064
    goto/16 :goto_0

    .line 1067
    :pswitch_f
    move-object v7, v1

    const v8, 0x40e66666    # 7.2f

    const v9, 0x416ccccd    # 14.8f

    const v10, 0x40866666    # 4.2f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1068
    move-object v7, v1

    const v8, 0x41866666    # 16.8f

    const v9, 0x416ccccd    # 14.8f

    const v10, 0x40866666    # 4.2f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1069
    move-object v7, v1

    const v8, 0x4109999a    # 8.6f

    const v9, 0x412e6666    # 10.9f

    const v10, 0x4129999a    # 10.6f

    const v11, 0x40eccccd    # 7.4f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1070
    move-object v7, v1

    const v8, 0x41766666    # 15.4f

    const v9, 0x412e6666    # 10.9f

    const v10, 0x41566666    # 13.4f

    const v11, 0x40eccccd    # 7.4f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1071
    move-object v7, v1

    const v8, 0x4129999a    # 10.6f

    const v9, 0x40eccccd    # 7.4f

    const v10, 0x41566666    # 13.4f

    const v11, 0x40eccccd    # 7.4f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1072
    goto/16 :goto_0

    .line 1075
    :pswitch_10
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x40400000    # 3.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1076
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x419c0000    # 19.5f

    const/high16 v9, 0x40c00000    # 6.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1077
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x419c0000    # 19.5f

    const/high16 v9, 0x41400000    # 12.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1078
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x419c0000    # 19.5f

    const/high16 v9, 0x41840000    # 16.5f

    const/high16 v10, 0x41800000    # 16.0f

    const/high16 v11, 0x419c0000    # 19.5f

    const/high16 v12, 0x41400000    # 12.0f

    const/high16 v13, 0x41a80000    # 21.0f

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 1079
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41000000    # 8.0f

    const/high16 v9, 0x419c0000    # 19.5f

    const/high16 v10, 0x40900000    # 4.5f

    const/high16 v11, 0x41840000    # 16.5f

    const/high16 v12, 0x40900000    # 4.5f

    const/high16 v13, 0x41400000    # 12.0f

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 1080
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40900000    # 4.5f

    const/high16 v9, 0x40c00000    # 6.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1081
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->close()V

    .line 1082
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$Glyph;->fillPath(Landroid/graphics/Canvas;Z)V

    .line 1083
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1084
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x4139999a    # 11.6f

    const v10, 0x40266666    # 2.6f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1085
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const v9, 0x40f33333    # 7.6f

    const/high16 v10, 0x41400000    # 12.0f

    const v11, 0x4179999a    # 15.6f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1086
    goto/16 :goto_0

    .line 1089
    :pswitch_11
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40400000    # 3.0f

    const v9, 0x41333333    # 11.2f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1090
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41a80000    # 21.0f

    const/high16 v9, 0x40600000    # 3.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1091
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x417ccccd    # 15.8f

    const/high16 v9, 0x41a40000    # 20.5f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1092
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x4139999a    # 11.6f

    const v9, 0x4159999a    # 13.6f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1093
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->close()V

    .line 1094
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$Glyph;->fillPath(Landroid/graphics/Canvas;Z)V

    .line 1095
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1096
    move-object v7, v1

    const v8, 0x4139999a    # 11.6f

    const v9, 0x4159999a    # 13.6f

    const/high16 v10, 0x41a80000    # 21.0f

    const/high16 v11, 0x40600000    # 3.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1097
    goto/16 :goto_0

    .line 1100
    :pswitch_12
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v8, 0x40d00000    # 6.5f

    const/high16 v9, 0x40600000    # 3.5f

    const/high16 v10, 0x418c0000    # 17.5f

    const/high16 v11, 0x41500000    # 13.0f

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1101
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$Glyph;->fillPath(Landroid/graphics/Canvas;Z)V

    .line 1102
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->rf:Landroid/graphics/RectF;

    const/high16 v9, 0x40000000    # 2.0f

    const/high16 v10, 0x40000000    # 2.0f

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9, v10, v11}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1103
    move-object v7, v1

    const/high16 v8, 0x41100000    # 9.0f

    const v9, 0x40e66666    # 7.2f

    const/high16 v10, 0x41700000    # 15.0f

    const v11, 0x40e66666    # 7.2f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1104
    move-object v7, v1

    const/high16 v8, 0x41100000    # 9.0f

    const v9, 0x411ccccd    # 9.8f

    const/high16 v10, 0x41700000    # 15.0f

    const v11, 0x411ccccd    # 9.8f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1105
    move-object v7, v1

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x41500000    # 13.0f

    const/high16 v10, 0x41400000    # 12.0f

    const/high16 v11, 0x41880000    # 17.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1106
    move-object v7, v1

    const/high16 v8, 0x40f00000    # 7.5f

    const/high16 v9, 0x41a40000    # 20.5f

    const/high16 v10, 0x41840000    # 16.5f

    const/high16 v11, 0x41a40000    # 20.5f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1107
    move-object v7, v1

    const/high16 v8, 0x41100000    # 9.0f

    const/high16 v9, 0x41a40000    # 20.5f

    const/high16 v10, 0x41100000    # 9.0f

    const/high16 v11, 0x41880000    # 17.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1108
    move-object v7, v1

    const/high16 v8, 0x41700000    # 15.0f

    const/high16 v9, 0x41a40000    # 20.5f

    const/high16 v10, 0x41700000    # 15.0f

    const/high16 v11, 0x41880000    # 17.0f

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual/range {v7 .. v12}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1109
    goto/16 :goto_0

    .line 1112
    :pswitch_13
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41400000    # 12.0f

    const/high16 v9, 0x40400000    # 3.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1113
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x419c0000    # 19.5f

    const/high16 v9, 0x40c00000    # 6.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1114
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x419c0000    # 19.5f

    const/high16 v9, 0x41400000    # 12.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1115
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x419c0000    # 19.5f

    const/high16 v9, 0x41840000    # 16.5f

    const/high16 v10, 0x41800000    # 16.0f

    const/high16 v11, 0x419c0000    # 19.5f

    const/high16 v12, 0x41400000    # 12.0f

    const/high16 v13, 0x41a80000    # 21.0f

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 1116
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x41000000    # 8.0f

    const/high16 v9, 0x419c0000    # 19.5f

    const/high16 v10, 0x40900000    # 4.5f

    const/high16 v11, 0x41840000    # 16.5f

    const/high16 v12, 0x40900000    # 4.5f

    const/high16 v13, 0x41400000    # 12.0f

    invoke-virtual/range {v7 .. v13}, Landroid/graphics/Path;->cubicTo(FFFFFF)V

    .line 1117
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const/high16 v8, 0x40900000    # 4.5f

    const/high16 v9, 0x40c00000    # 6.0f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1118
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->close()V

    .line 1119
    move-object v7, v0

    move-object v8, v1

    move v9, v2

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/NeonUi$Glyph;->fillPath(Landroid/graphics/Canvas;Z)V

    .line 1120
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1121
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    invoke-virtual {v7}, Landroid/graphics/Path;->reset()V

    .line 1122
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x41066666    # 8.4f

    const v9, 0x41433333    # 12.2f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1123
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x412ccccd    # 10.8f

    const v9, 0x4169999a    # 14.6f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1124
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    const v8, 0x4179999a    # 15.6f

    const v9, 0x41133333    # 9.2f

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1125
    move-object v7, v1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->path:Landroid/graphics/Path;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    invoke-virtual {v7, v8, v9}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1126
    goto/16 :goto_0

    .line 909
    :pswitch_data_0
    .packed-switch 0x65
        :pswitch_0
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_a
        :pswitch_b
        :pswitch_c
        :pswitch_d
        :pswitch_e
        :pswitch_f
        :pswitch_10
        :pswitch_11
        :pswitch_12
        :pswitch_13
    .end packed-switch
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 871
    move-object v0, p0

    move-object v1, p1

    move-object v8, v0

    invoke-virtual {v8}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v8

    move-object v3, v8

    .line 872
    move-object v8, v3

    invoke-virtual {v8}, Landroid/graphics/Rect;->width()I

    move-result v8

    move-object v9, v3

    invoke-virtual {v9}, Landroid/graphics/Rect;->height()I

    move-result v9

    invoke-static {v8, v9}, Ljava/lang/Math;->min(II)I

    move-result v8

    int-to-float v8, v8

    move v4, v8

    .line 873
    move v8, v4

    const/4 v9, 0x0

    cmpg-float v8, v8, v9

    if-gtz v8, :cond_0

    .line 886
    :goto_0
    return-void

    .line 874
    :cond_0
    move-object v8, v1

    invoke-virtual {v8}, Landroid/graphics/Canvas;->save()I

    move-result v8

    .line 875
    move-object v8, v1

    move-object v9, v3

    invoke-virtual {v9}, Landroid/graphics/Rect;->exactCenterX()F

    move-result v9

    move v10, v4

    const/high16 v11, 0x40000000    # 2.0f

    div-float/2addr v10, v11

    sub-float/2addr v9, v10

    move-object v10, v3

    invoke-virtual {v10}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v10

    move v11, v4

    const/high16 v12, 0x40000000    # 2.0f

    div-float/2addr v11, v12

    sub-float/2addr v10, v11

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->translate(FF)V

    .line 876
    move-object v8, v1

    move v9, v4

    const/high16 v10, 0x41c00000    # 24.0f

    div-float/2addr v9, v10

    move v10, v4

    const/high16 v11, 0x41c00000    # 24.0f

    div-float/2addr v10, v11

    invoke-virtual {v8, v9, v10}, Landroid/graphics/Canvas;->scale(FF)V

    .line 877
    const/4 v8, 0x0

    move v5, v8

    :goto_1
    move v8, v5

    const/4 v9, 0x2

    if-lt v8, v9, :cond_1

    .line 886
    move-object v8, v1

    invoke-virtual {v8}, Landroid/graphics/Canvas;->restore()V

    goto :goto_0

    .line 878
    :cond_1
    move v8, v5

    const/4 v9, 0x0

    if-eq v8, v9, :cond_2

    const/4 v8, 0x0

    :goto_2
    move v6, v8

    .line 879
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 880
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 881
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    sget-object v9, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 882
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    move v9, v6

    if-eqz v9, :cond_3

    const v9, 0x408ccccd    # 4.4f

    :goto_3
    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 883
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/NeonUi$Glyph;->p:Landroid/graphics/Paint;

    move v9, v6

    if-eqz v9, :cond_4

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Glyph;->color:I

    const/16 v10, 0x30

    invoke-static {v9, v10}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v9

    :goto_4
    invoke-virtual {v8, v9}, Landroid/graphics/Paint;->setColor(I)V

    .line 884
    move-object v8, v0

    move-object v9, v1

    move v10, v6

    invoke-direct {v8, v9, v10}, Lgtandroid/universal/NeonUi$Glyph;->shape(Landroid/graphics/Canvas;Z)V

    .line 877
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 878
    :cond_2
    const/4 v8, 0x1

    goto :goto_2

    .line 882
    :cond_3
    const v9, 0x3fd9999a    # 1.7f

    goto :goto_3

    .line 883
    :cond_4
    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/NeonUi$Glyph;->color:I

    goto :goto_4
.end method

.method public getIntrinsicHeight()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 867
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/NeonUi$Glyph;->sizePx:I

    move v0, v2

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 866
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/NeonUi$Glyph;->sizePx:I

    move v0, v2

    return v0
.end method

.method public getOpacity()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1135
    move-object v0, p0

    const/4 v2, -0x3

    move v0, v2

    return v0
.end method

.method public setAlpha(I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/ColorFilter;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method
