.class Lgtandroid/universal/KeyboardService$100000139;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000139"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$isViolator:Z

.field private final val$playerId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;ZLjava/lang/String;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000139;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    move v6, v2

    iput-boolean v6, v5, Lgtandroid/universal/KeyboardService$100000139;->val$isViolator:Z

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000139;->val$playerId:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000139;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000139;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4900
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-boolean v3, v3, Lgtandroid/universal/KeyboardService$100000139;->val$isViolator:Z

    if-eqz v3, :cond_0

    .line 4901
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000139;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000139;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$L1000039(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v4

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000139;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$L1000040(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v4, v5}, Lgtandroid/universal/KeyboardService;->access$1000402(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;)V

    .line 4903
    :goto_0
    return-void

    :cond_0
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000139;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000139;->val$playerId:Ljava/lang/String;

    invoke-static {v3, v4}, Lgtandroid/universal/KeyboardService;->access$1000388(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    goto :goto_0
.end method
