.class Lgtandroid/universal/MyAccessibilityService$100000000;
.super Ljava/lang/Object;
.source "MyAccessibilityService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MyAccessibilityService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final val$svc:Lgtandroid/universal/MyAccessibilityService;

.field private final val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MyAccessibilityService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MyAccessibilityService$100000000;->val$svc:Lgtandroid/universal/MyAccessibilityService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MyAccessibilityService$100000000;->val$text:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public run()V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 64
    move-object/from16 v1, p0

    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/MyAccessibilityService$100000000;->val$svc:Lgtandroid/universal/MyAccessibilityService;

    invoke-virtual {v12}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v12

    move-object v3, v12

    .line 65
    move-object v12, v3

    if-nez v12, :cond_0

    .line 100
    :goto_0
    return-void

    .line 67
    :cond_0
    move-object v12, v3

    invoke-static {v12}, Lgtandroid/universal/MyAccessibilityService;->access$1000004(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v12

    move-object v4, v12

    .line 69
    move-object v12, v4

    if-eqz v12, :cond_3

    .line 70
    move-object v12, v4

    const/4 v13, 0x1

    invoke-virtual {v12, v13}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result v12

    .line 73
    const/16 v12, 0x32

    int-to-long v12, v12

    :try_start_0
    invoke-static {v12, v13}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 76
    :goto_1
    new-instance v12, Landroid/os/Bundle;

    move-object v15, v12

    move-object v12, v15

    move-object v13, v15

    invoke-direct {v13}, Landroid/os/Bundle;-><init>()V

    move-object v5, v12

    .line 77
    move-object v12, v5

    const-string v13, "ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE"

    move-object v14, v1

    iget-object v14, v14, Lgtandroid/universal/MyAccessibilityService$100000000;->val$text:Ljava/lang/String;

    invoke-virtual {v12, v13, v14}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 78
    move-object v12, v4

    const/high16 v13, 0x200000

    move-object v14, v5

    invoke-virtual {v12, v13, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z

    move-result v12

    move v6, v12

    .line 80
    move v12, v6

    if-nez v12, :cond_2

    .line 81
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/MyAccessibilityService$100000000;->val$svc:Lgtandroid/universal/MyAccessibilityService;

    const-string v13, "clipboard"

    invoke-virtual {v12, v13}, Landroid/accessibilityservice/AccessibilityService;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/content/ClipboardManager;

    move-object v7, v12

    .line 83
    const-string v12, "GTAndroid"

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/MyAccessibilityService$100000000;->val$text:Ljava/lang/String;

    invoke-static {v12, v13}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v12

    move-object v8, v12

    .line 85
    move-object v12, v7

    move-object v13, v8

    invoke-virtual {v12, v13}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 88
    move-object v12, v4

    :try_start_1
    invoke-virtual {v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    move-result-object v12

    move-object v9, v12

    .line 89
    move-object v12, v9

    if-eqz v12, :cond_1

    move-object v12, v9

    invoke-interface {v12}, Ljava/lang/CharSequence;->length()I

    move-result v12

    const/4 v13, 0x0

    if-le v12, v13, :cond_1

    .line 90
    new-instance v12, Landroid/os/Bundle;

    move-object v15, v12

    move-object v12, v15

    move-object v13, v15

    invoke-direct {v13}, Landroid/os/Bundle;-><init>()V

    move-object v10, v12

    .line 91
    move-object v12, v10

    const-string v13, "ACTION_ARGUMENT_SELECTION_START_INT"

    const/4 v14, 0x0

    invoke-virtual {v12, v13, v14}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 92
    move-object v12, v10

    const-string v13, "ACTION_ARGUMENT_SELECTION_END_INT"

    move-object v14, v9

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    invoke-virtual {v12, v13, v14}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 93
    move-object v12, v4

    const/high16 v13, 0x20000

    move-object v14, v10

    invoke-virtual {v12, v13, v14}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(ILandroid/os/Bundle;)Z
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    move-result v12

    .line 97
    :cond_1
    :goto_2
    move-object v12, v4

    const v13, 0x8000

    invoke-virtual {v12, v13}, Landroid/view/accessibility/AccessibilityNodeInfo;->performAction(I)Z

    move-result v12

    .line 100
    :cond_2
    move-object v12, v3

    invoke-virtual {v12}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    :cond_3
    goto/16 :goto_0

    .line 73
    :catch_0
    move-exception v12

    move-object v5, v12

    goto :goto_1

    .line 93
    :catch_1
    move-exception v12

    move-object v9, v12

    goto :goto_2
.end method
