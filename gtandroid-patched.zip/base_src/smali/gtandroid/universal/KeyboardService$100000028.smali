.class Lgtandroid/universal/KeyboardService$100000028;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000028"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$command:Ljava/lang/String;

.field private final val$idInput:Landroid/widget/EditText;

.field private final val$reason:Ljava/lang/String;

.field private final val$requiredLevel:I

.field private final val$time:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Landroid/widget/EditText;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object/from16 v6, p6

    move-object v8, v0

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    move-object v8, v0

    move-object v9, v1

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000028;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v8, v0

    move-object v9, v2

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000028;->val$idInput:Landroid/widget/EditText;

    move-object v8, v0

    move v9, v3

    iput v9, v8, Lgtandroid/universal/KeyboardService$100000028;->val$requiredLevel:I

    move-object v8, v0

    move-object v9, v4

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000028;->val$command:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v5

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000028;->val$time:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v6

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000028;->val$reason:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000028;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000028;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1565
    move-object v0, p0

    move-object v1, p1

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000028;->val$idInput:Landroid/widget/EditText;

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    invoke-interface {v7}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    move-object v3, v7

    .line 1566
    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_0

    .line 1595
    :goto_0
    return-void

    .line 1571
    :cond_0
    new-instance v7, Ljava/lang/StringBuilder;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move-object v4, v7

    .line 1573
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000028;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$L1000014(Lgtandroid/universal/KeyboardService;)I

    move-result v7

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/KeyboardService$100000028;->val$requiredLevel:I

    if-ge v7, v8, :cond_1

    .line 1574
    move-object v7, v4

    const-string v8, "/a "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 1577
    :cond_1
    move-object v7, v4

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000028;->val$command:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v3

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 1579
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000028;->val$time:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_2

    .line 1580
    move-object v7, v4

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000028;->val$time:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 1582
    :cond_2
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000028;->val$reason:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_3

    .line 1583
    move-object v7, v4

    const-string v8, " "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000028;->val$reason:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 1586
    :cond_3
    move-object v7, v4

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v5, v7

    .line 1587
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000028;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v8, v5

    invoke-static {v7, v8}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 1589
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000028;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$L1000014(Lgtandroid/universal/KeyboardService;)I

    move-result v7

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/KeyboardService$100000028;->val$requiredLevel:I

    if-ge v7, v8, :cond_4

    .line 1595
    :cond_4
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000028;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$1000091(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0
.end method
