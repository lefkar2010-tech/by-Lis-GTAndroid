.class Lgtandroid/universal/MainActivity$100000012$100000011;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity$100000012;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000011"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity$100000012;

.field private final val$adsArray:Lorg/json/JSONArray;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity$100000012;Lorg/json/JSONArray;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000012$100000011;->this$0:Lgtandroid/universal/MainActivity$100000012;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000012$100000011;->val$adsArray:Lorg/json/JSONArray;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000012$100000011;)Lgtandroid/universal/MainActivity$100000012;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000012$100000011;->this$0:Lgtandroid/universal/MainActivity$100000012;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 666
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/MainActivity$100000012$100000011;->this$0:Lgtandroid/universal/MainActivity$100000012;

    invoke-static {v2}, Lgtandroid/universal/MainActivity$100000012;->access$0(Lgtandroid/universal/MainActivity$100000012;)Lgtandroid/universal/MainActivity;

    move-result-object v2

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000012$100000011;->val$adsArray:Lorg/json/JSONArray;

    invoke-static {v2, v3}, Lgtandroid/universal/MainActivity;->access$1000052(Lgtandroid/universal/MainActivity;Lorg/json/JSONArray;)V

    return-void
.end method
