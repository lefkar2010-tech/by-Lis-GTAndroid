.class Lgtandroid/universal/KeyboardService$TileSpec;
.super Ljava/lang/Object;
.source "KeyboardService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "TileSpec"
.end annotation


# instance fields
.field final action:I

.field final color:I

.field final glyph:I

.field final name:Ljava/lang/String;

.field final req:I

.field final style:I

.field final tpl:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;IIIIILjava/lang/String;)V
    .locals 11

    .prologue
    .line 3552
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move-object/from16 v7, p7

    move-object v9, v0

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    .line 3553
    move-object v9, v0

    move-object v10, v1

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$TileSpec;->name:Ljava/lang/String;

    move-object v9, v0

    move v10, v2

    iput v10, v9, Lgtandroid/universal/KeyboardService$TileSpec;->glyph:I

    move-object v9, v0

    move v10, v3

    iput v10, v9, Lgtandroid/universal/KeyboardService$TileSpec;->color:I

    move-object v9, v0

    move v10, v4

    iput v10, v9, Lgtandroid/universal/KeyboardService$TileSpec;->action:I

    .line 3554
    move-object v9, v0

    move v10, v5

    iput v10, v9, Lgtandroid/universal/KeyboardService$TileSpec;->req:I

    move-object v9, v0

    move v10, v6

    iput v10, v9, Lgtandroid/universal/KeyboardService$TileSpec;->style:I

    move-object v9, v0

    move-object v10, v7

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$TileSpec;->tpl:Ljava/lang/String;

    return-void
.end method
