.class Lgtandroid/universal/FloatingService$100000014;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000014"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;

.field private final val$btn:Landroid/widget/Button;

.field private final val$jailAlertExtra:Ljava/lang/String;

.field private final val$label:Ljava/lang/String;

.field private final val$prefKey:Ljava/lang/String;

.field private final val$state:[Z


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;[ZLjava/lang/String;Landroid/widget/Button;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object/from16 v6, p6

    move-object v8, v0

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    move-object v8, v0

    move-object v9, v1

    iput-object v9, v8, Lgtandroid/universal/FloatingService$100000014;->this$0:Lgtandroid/universal/FloatingService;

    move-object v8, v0

    move-object v9, v2

    iput-object v9, v8, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    move-object v8, v0

    move-object v9, v3

    iput-object v9, v8, Lgtandroid/universal/FloatingService$100000014;->val$prefKey:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v4

    iput-object v9, v8, Lgtandroid/universal/FloatingService$100000014;->val$btn:Landroid/widget/Button;

    move-object v8, v0

    move-object v9, v5

    iput-object v9, v8, Lgtandroid/universal/FloatingService$100000014;->val$label:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v6

    iput-object v9, v8, Lgtandroid/universal/FloatingService$100000014;->val$jailAlertExtra:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000014;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000014;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 920
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    const/4 v7, 0x0

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    const/4 v9, 0x0

    aget-boolean v8, v8, v9

    if-eqz v8, :cond_1

    const/4 v8, 0x0

    :goto_0
    aput-boolean v8, v6, v7

    .line 921
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000014;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v6}, Lgtandroid/universal/FloatingService;->access$L1000013(Lgtandroid/universal/FloatingService;)Landroid/content/SharedPreferences;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService$100000014;->val$prefKey:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    const/4 v9, 0x0

    aget-boolean v8, v8, v9

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 922
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000014;->val$btn:Landroid/widget/Button;

    new-instance v7, Ljava/lang/StringBuffer;

    move-object/from16 v17, v7

    move-object/from16 v7, v17

    move-object/from16 v8, v17

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object/from16 v17, v8

    move-object/from16 v8, v17

    move-object/from16 v9, v17

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/FloatingService$100000014;->val$label:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, ": "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    const/4 v9, 0x0

    aget-boolean v8, v8, v9

    if-eqz v8, :cond_2

    const-string v8, "\u0412\u043a\u043b"

    :goto_1
    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 923
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000014;->val$btn:Landroid/widget/Button;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    const/4 v8, 0x0

    aget-boolean v7, v7, v8

    if-eqz v7, :cond_3

    const v7, -0xff5600

    :goto_2
    invoke-virtual {v6, v7}, Landroid/view/View;->setBackgroundColor(I)V

    .line 924
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000014;->this$0:Lgtandroid/universal/FloatingService;

    new-instance v7, Ljava/lang/StringBuffer;

    move-object/from16 v17, v7

    move-object/from16 v7, v17

    move-object/from16 v8, v17

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object/from16 v17, v8

    move-object/from16 v8, v17

    move-object/from16 v9, v17

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/FloatingService$100000014;->val$label:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, ": "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    const/4 v9, 0x0

    aget-boolean v8, v8, v9

    if-eqz v8, :cond_4

    const-string v8, "\u0412\u043a\u043b"

    :goto_3
    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 926
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000014;->val$jailAlertExtra:Ljava/lang/String;

    if-eqz v6, :cond_0

    .line 927
    new-instance v6, Landroid/content/Intent;

    move-object/from16 v17, v6

    move-object/from16 v6, v17

    move-object/from16 v7, v17

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/FloatingService$100000014;->this$0:Lgtandroid/universal/FloatingService;

    :try_start_0
    const-string v9, "gtandroid.universal.JailAlertService"

    invoke-static {v9}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    move-result-object v9

    invoke-direct {v7, v8, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    move-object v3, v6

    .line 928
    move-object v6, v3

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService$100000014;->val$jailAlertExtra:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/FloatingService$100000014;->val$state:[Z

    const/4 v9, 0x0

    aget-boolean v8, v8, v9

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v6

    .line 929
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000014;->this$0:Lgtandroid/universal/FloatingService;

    move-object v7, v3

    invoke-virtual {v6, v7}, Landroid/content/ContextWrapper;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object v6

    :cond_0
    return-void

    .line 920
    :cond_1
    const/4 v8, 0x1

    goto/16 :goto_0

    .line 922
    :cond_2
    const-string v8, "\u0412\u044b\u043a\u043b"

    goto/16 :goto_1

    .line 923
    :cond_3
    const v7, -0x99999a

    goto/16 :goto_2

    .line 924
    :cond_4
    const-string v8, "\u0412\u044b\u043a\u043b"

    goto :goto_3

    .line 927
    :catch_0
    move-exception v6

    move-object v4, v6

    new-instance v6, Ljava/lang/NoClassDefFoundError;

    move-object/from16 v17, v6

    move-object/from16 v6, v17

    move-object/from16 v7, v17

    move-object v8, v4

    invoke-virtual {v8}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/lang/NoClassDefFoundError;-><init>(Ljava/lang/String;)V

    throw v6
.end method
