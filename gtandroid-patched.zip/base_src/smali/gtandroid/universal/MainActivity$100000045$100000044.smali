.class Lgtandroid/universal/MainActivity$100000045$100000044;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity$100000045;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000044"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity$100000045;

.field private final val$btnPick:Landroid/widget/Button;

.field private final val$pairs:Ljava/util/List;

.field private final val$selName:[Ljava/lang/String;

.field private final val$selText:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity$100000045;[Ljava/lang/String;Ljava/util/List;[Ljava/lang/String;Landroid/widget/Button;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/MainActivity$100000045$100000044;->this$0:Lgtandroid/universal/MainActivity$100000045;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/MainActivity$100000045$100000044;->val$selName:[Ljava/lang/String;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/MainActivity$100000045$100000044;->val$pairs:Ljava/util/List;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/MainActivity$100000045$100000044;->val$selText:[Ljava/lang/String;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/MainActivity$100000045$100000044;->val$btnPick:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000045$100000044;)Lgtandroid/universal/MainActivity$100000045;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000045$100000044;->this$0:Lgtandroid/universal/MainActivity$100000045;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1647
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000045$100000044;->val$selName:[Ljava/lang/String;

    const/4 v5, 0x0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000045$100000044;->val$pairs:Ljava/util/List;

    move v7, v2

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/String;

    const/4 v7, 0x0

    aget-object v6, v6, v7

    aput-object v6, v4, v5

    .line 1648
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000045$100000044;->val$selText:[Ljava/lang/String;

    const/4 v5, 0x0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000045$100000044;->val$pairs:Ljava/util/List;

    move v7, v2

    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, [Ljava/lang/String;

    const/4 v7, 0x1

    aget-object v6, v6, v7

    aput-object v6, v4, v5

    .line 1649
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000045$100000044;->val$btnPick:Landroid/widget/Button;

    new-instance v5, Ljava/lang/StringBuffer;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Ljava/lang/StringBuffer;-><init>()V

    const-string v6, "\u0412\u044b\u0431\u0440\u0430\u0442\u044c \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000045$100000044;->val$selName:[Ljava/lang/String;

    const/4 v7, 0x0

    aget-object v6, v6, v7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1650
    move-object v4, v1

    invoke-interface {v4}, Landroid/content/DialogInterface;->dismiss()V

    return-void
.end method
