.class public final Lgtandroid/universal/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "id"
.end annotation


# static fields
.field public static final btnAdmin:I = 0x7f090002

.field public static final btnAutoReport:I = 0x7f090005

.field public static final btnBackspaceEn:I = 0x7f090073

.field public static final btnBackspaceNum:I = 0x7f090053

.field public static final btnBackspace_ru:I = 0x7f09002e

.field public static final btnCommaEn:I = 0x7f090076

.field public static final btnComma_ru:I = 0x7f090031

.field public static final btnDigit0:I = 0x7f09003f

.field public static final btnDigit1:I = 0x7f090036

.field public static final btnDigit2:I = 0x7f090037

.field public static final btnDigit3:I = 0x7f090038

.field public static final btnDigit4:I = 0x7f090039

.field public static final btnDigit5:I = 0x7f09003a

.field public static final btnDigit6:I = 0x7f09003b

.field public static final btnDigit7:I = 0x7f09003c

.field public static final btnDigit8:I = 0x7f09003d

.field public static final btnDigit9:I = 0x7f09003e

.field public static final btnEnterEn:I = 0x7f090079

.field public static final btnEnterNum:I = 0x7f090056

.field public static final btnEnter_ru:I = 0x7f090034

.field public static final btnFamWar:I = 0x7f090004

.field public static final btnNormal:I = 0x7f090003

.field public static final btnPeriodEn:I = 0x7f090078

.field public static final btnPeriod_ru:I = 0x7f090033

.field public static final btnQuickAnswer:I = 0x7f090006

.field public static final btnShiftEn:I = 0x7f09006b

.field public static final btnShiftNum:I = 0x7f09004a

.field public static final btnShift_ru:I = 0x7f090024

.field public static final btnSpaceEn:I = 0x7f090077

.field public static final btnSpaceNum:I = 0x7f090055

.field public static final btnSpace_ru:I = 0x7f090032

.field public static final btnSwitchLangEn:I = 0x7f090075

.field public static final btnSwitchLang_ru:I = 0x7f090030

.field public static final btnSymAmp:I = 0x7f090040

.field public static final btnSymAposNum:I = 0x7f09004e

.field public static final btnSymAt:I = 0x7f09004b

.field public static final btnSymColonNum:I = 0x7f09004f

.field public static final btnSymExclaimNum:I = 0x7f090051

.field public static final btnSymHashNum:I = 0x7f090041

.field public static final btnSymLParen:I = 0x7f090047

.field public static final btnSymMinus:I = 0x7f090045

.field public static final btnSymPercentNum:I = 0x7f090043

.field public static final btnSymPlus:I = 0x7f090046

.field public static final btnSymQuestionNum:I = 0x7f090052

.field public static final btnSymQuoteNum:I = 0x7f09004d

.field public static final btnSymRParen:I = 0x7f090048

.field public static final btnSymRub:I = 0x7f090042

.field public static final btnSymSemicolonNum:I = 0x7f090050

.field public static final btnSymSlashNum:I = 0x7f090049

.field public static final btnSymStar:I = 0x7f09004c

.field public static final btnSymUnderscore:I = 0x7f090044

.field public static final btnTeleport:I = 0x7f090007

.field public static final btnToggleLetters:I = 0x7f090054

.field public static final btnToggleSymbols_en:I = 0x7f090074

.field public static final btnToggleSymbols_ru:I = 0x7f09002f

.field public static final btna_en:I = 0x7f090062

.field public static final btnb_en:I = 0x7f090070

.field public static final btnc_en:I = 0x7f09006e

.field public static final btnd_en:I = 0x7f090064

.field public static final btne_en:I = 0x7f09005a

.field public static final btne_ru:I = 0x7f090012

.field public static final btnf_en:I = 0x7f090065

.field public static final btng_en:I = 0x7f090066

.field public static final btnh_en:I = 0x7f090067

.field public static final btni_en:I = 0x7f09005f

.field public static final btnj_en:I = 0x7f090068

.field public static final btnk_en:I = 0x7f090069

.field public static final btnl_en:I = 0x7f09006a

.field public static final btnm_en:I = 0x7f090072

.field public static final btnn_en:I = 0x7f090071

.field public static final btno_en:I = 0x7f090060

.field public static final btnp_en:I = 0x7f090061

.field public static final btnq_en:I = 0x7f090058

.field public static final btnr_en:I = 0x7f09005b

.field public static final btns_en:I = 0x7f090063

.field public static final btnt_en:I = 0x7f09005c

.field public static final btnu_en:I = 0x7f09005e

.field public static final btnv_en:I = 0x7f09006f

.field public static final btnw_en:I = 0x7f090059

.field public static final btnx_en:I = 0x7f09006d

.field public static final btny_en:I = 0x7f09005d

.field public static final btnz_en:I = 0x7f09006c

.field public static final btnа_ru:I = 0x7f09001c

.field public static final btnб_ru:I = 0x7f09002c

.field public static final btnв_ru:I = 0x7f09001b

.field public static final btnг_ru:I = 0x7f090014

.field public static final btnд_ru:I = 0x7f090021

.field public static final btnж_ru:I = 0x7f090022

.field public static final btnз_ru:I = 0x7f090017

.field public static final btnи_ru:I = 0x7f090029

.field public static final btnй_ru:I = 0x7f09000e

.field public static final btnк_ru:I = 0x7f090011

.field public static final btnл_ru:I = 0x7f090020

.field public static final btnм_ru:I = 0x7f090028

.field public static final btnн_ru:I = 0x7f090013

.field public static final btnо_ru:I = 0x7f09001f

.field public static final btnп_ru:I = 0x7f09001d

.field public static final btnр_ru:I = 0x7f09001e

.field public static final btnс_ru:I = 0x7f090027

.field public static final btnт_ru:I = 0x7f09002a

.field public static final btnу_ru:I = 0x7f090010

.field public static final btnф_ru:I = 0x7f090019

.field public static final btnх_ru:I = 0x7f090018

.field public static final btnц_ru:I = 0x7f09000f

.field public static final btnч_ru:I = 0x7f090026

.field public static final btnш_ru:I = 0x7f090015

.field public static final btnщ_ru:I = 0x7f090016

.field public static final btnы_ru:I = 0x7f09001a

.field public static final btnь_ru:I = 0x7f09002b

.field public static final btnэ_ru:I = 0x7f090023

.field public static final btnю_ru:I = 0x7f09002d

.field public static final btnя_ru:I = 0x7f090025

.field public static final englishLayout:I = 0x7f090057

.field public static final keyboardContainer:I = 0x7f090000

.field public static final keyboardLayout:I = 0x7f09000a

.field public static final keyboardTitle:I = 0x7f090001

.field public static final menuContainer:I = 0x7f090009

.field public static final menuScrollView:I = 0x7f090008

.field public static final menu_editor:I = 0x7f09007b

.field public static final menu_main:I = 0x7f09007a

.field public static final menu_settings:I = 0x7f09007c

.field public static final numbersLayout:I = 0x7f090035

.field public static final russianLayout:I = 0x7f09000d

.field public static final t9SuggestionsBar:I = 0x7f09000b

.field public static final t9SuggestionsContainer:I = 0x7f09000c


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 144
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
