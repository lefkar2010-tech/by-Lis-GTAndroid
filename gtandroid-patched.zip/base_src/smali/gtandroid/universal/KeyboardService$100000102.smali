.class Lgtandroid/universal/KeyboardService$100000102;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000102"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$answerButtons:Ljava/util/List;

.field private final val$b:Landroid/widget/Button;

.field private final val$name:Ljava/lang/String;

.field private final val$selName:[Ljava/lang/String;

.field private final val$selText:[Ljava/lang/String;

.field private final val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Landroid/widget/Button;)V
    .locals 11

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object v9, v0

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    move-object v9, v0

    move-object v10, v1

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$100000102;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v9, v0

    move-object v10, v2

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$100000102;->val$selName:[Ljava/lang/String;

    move-object v9, v0

    move-object v10, v3

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$100000102;->val$name:Ljava/lang/String;

    move-object v9, v0

    move-object v10, v4

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$100000102;->val$selText:[Ljava/lang/String;

    move-object v9, v0

    move-object v10, v5

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$100000102;->val$text:Ljava/lang/String;

    move-object v9, v0

    move-object v10, v6

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$100000102;->val$answerButtons:Ljava/util/List;

    move-object v9, v0

    move-object v10, v7

    iput-object v10, v9, Lgtandroid/universal/KeyboardService$100000102;->val$b:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000102;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000102;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4094
    move-object v0, p0

    move-object v1, p1

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000102;->val$selName:[Ljava/lang/String;

    const/4 v8, 0x0

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000102;->val$name:Ljava/lang/String;

    aput-object v9, v7, v8

    .line 4095
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000102;->val$selText:[Ljava/lang/String;

    const/4 v8, 0x0

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000102;->val$text:Ljava/lang/String;

    aput-object v9, v7, v8

    .line 4096
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000102;->val$answerButtons:Ljava/util/List;

    check-cast v7, Ljava/util/Collection;

    invoke-interface {v7}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v7

    move-object v3, v7

    .line 4097
    :goto_0
    move-object v7, v3

    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-nez v7, :cond_0

    .line 4099
    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000102;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000102;->val$b:Landroid/widget/Button;

    const v9, -0xc12e96

    invoke-static {v7, v8, v9}, Lgtandroid/universal/NeonUi;->tintTile(Landroid/content/Context;Landroid/widget/Button;I)V

    return-void

    .line 4096
    :cond_0
    move-object v7, v3

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/widget/Button;

    move-object v5, v7

    .line 4097
    move-object v7, v5

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000102;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v8}, Lgtandroid/universal/NeonUi;->tileDrawable(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    invoke-static {v7, v8}, Lgtandroid/universal/NeonUi;->setBg(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    goto :goto_0
.end method
