.class Lgtandroid/universal/KeyboardService$100000003;
.super Landroid/content/BroadcastReceiver;
.source "KeyboardService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000003"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000003;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v3, v0

    invoke-direct {v3}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000003;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000003;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 180
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v2

    if-eqz v4, :cond_0

    const-string v4, "KEYBOARD_TRANSPARENCY_CHANGED"

    move-object v5, v2

    invoke-virtual {v5}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 181
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000003;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000003;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v5

    const-string v6, "keyboard_transparency"

    const/16 v7, 0x64

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v5

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$S1000016(Lgtandroid/universal/KeyboardService;I)V

    .line 182
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000003;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000003;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$L1000016(Lgtandroid/universal/KeyboardService;)I

    move-result v5

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$1000105(Lgtandroid/universal/KeyboardService;I)V

    :cond_0
    return-void
.end method
