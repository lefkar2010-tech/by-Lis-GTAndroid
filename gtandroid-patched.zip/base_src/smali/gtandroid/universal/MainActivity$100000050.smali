.class Lgtandroid/universal/MainActivity$100000050;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000050"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$holder:[Landroid/app/AlertDialog;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;[Landroid/app/AlertDialog;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000050;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000050;->val$holder:[Landroid/app/AlertDialog;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000050;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000050;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1797
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000050;->val$holder:[Landroid/app/AlertDialog;

    const/4 v4, 0x0

    aget-object v3, v3, v4

    if-eqz v3, :cond_0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000050;->val$holder:[Landroid/app/AlertDialog;

    const/4 v4, 0x0

    aget-object v3, v3, v4

    invoke-virtual {v3}, Landroid/app/Dialog;->dismiss()V

    .line 1798
    :cond_0
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000050;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v3}, Lgtandroid/universal/MainActivity;->access$1000130(Lgtandroid/universal/MainActivity;)V

    return-void
.end method
