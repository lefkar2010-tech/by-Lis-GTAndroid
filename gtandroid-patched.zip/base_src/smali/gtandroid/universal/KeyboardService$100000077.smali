.class Lgtandroid/universal/KeyboardService$100000077;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000077"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000077;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000077;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000077;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3206
    move-object/from16 v0, p0

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000077;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-virtual {v7}, Landroid/inputmethodservice/InputMethodService;->getCurrentInputConnection()Landroid/view/inputmethod/InputConnection;

    move-result-object v7

    move-object v2, v7

    .line 3207
    move-object v7, v2

    if-eqz v7, :cond_0

    .line 3209
    :try_start_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    move-wide v3, v7

    .line 3210
    const/4 v7, 0x0

    move v5, v7

    :goto_0
    move v7, v5

    const/4 v8, 0x2

    if-lt v7, v8, :cond_1

    .line 3217
    :cond_0
    :goto_1
    return-void

    .line 3211
    :cond_1
    move-object v7, v2

    new-instance v8, Landroid/view/KeyEvent;

    move-object/from16 v17, v8

    move-object/from16 v8, v17

    move-object/from16 v9, v17

    move-wide v10, v3

    move v12, v5

    const/16 v13, 0x32

    mul-int/lit8 v12, v12, 0x32

    int-to-long v12, v12

    add-long/2addr v10, v12

    move-wide v12, v3

    move v14, v5

    const/16 v15, 0x32

    mul-int/lit8 v14, v14, 0x32

    int-to-long v14, v14

    add-long/2addr v12, v14

    const/4 v14, 0x0

    const/16 v15, 0x42

    const/16 v16, 0x0

    invoke-direct/range {v9 .. v16}, Landroid/view/KeyEvent;-><init>(JJIII)V

    invoke-interface {v7, v8}, Landroid/view/inputmethod/InputConnection;->sendKeyEvent(Landroid/view/KeyEvent;)Z

    move-result v7

    .line 3213
    move-object v7, v2

    new-instance v8, Landroid/view/KeyEvent;

    move-object/from16 v17, v8

    move-object/from16 v8, v17

    move-object/from16 v9, v17

    move-wide v10, v3

    move v12, v5

    const/16 v13, 0x32

    mul-int/lit8 v12, v12, 0x32

    int-to-long v12, v12

    add-long/2addr v10, v12

    const/16 v12, 0x19

    int-to-long v12, v12

    add-long/2addr v10, v12

    move-wide v12, v3

    move v14, v5

    const/16 v15, 0x32

    mul-int/lit8 v14, v14, 0x32

    int-to-long v14, v14

    add-long/2addr v12, v14

    const/16 v14, 0x19

    int-to-long v14, v14

    add-long/2addr v12, v14

    const/4 v14, 0x1

    const/16 v15, 0x42

    const/16 v16, 0x0

    invoke-direct/range {v9 .. v16}, Landroid/view/KeyEvent;-><init>(JJIII)V

    invoke-interface {v7, v8}, Landroid/view/inputmethod/InputConnection;->sendKeyEvent(Landroid/view/KeyEvent;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-result v7

    .line 3210
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :catch_0
    move-exception v7

    move-object v3, v7

    .line 3217
    move-object v7, v2

    const-string v8, "\n"

    const/4 v9, 0x1

    invoke-interface {v7, v8, v9}, Landroid/view/inputmethod/InputConnection;->commitText(Ljava/lang/CharSequence;I)Z

    move-result v7

    goto :goto_1
.end method
