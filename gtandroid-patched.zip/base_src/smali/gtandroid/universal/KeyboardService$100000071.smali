.class Lgtandroid/universal/KeyboardService$100000071;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000071"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$playerId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000071;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000071;->val$playerId:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000071;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000071;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3005
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000071;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$1000227(Lgtandroid/universal/KeyboardService;)V

    .line 3006
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000071;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$1000226(Lgtandroid/universal/KeyboardService;)V

    .line 3007
    new-instance v5, Landroid/content/Intent;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    const-string v7, "HELP_PLAYER_DECLINED"

    invoke-direct {v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 3008
    move-object v5, v3

    const-string v6, "playerId"

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000071;->val$playerId:Ljava/lang/String;

    invoke-virtual {v5, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v5

    .line 3009
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000071;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method
