.class Lgtandroid/universal/FloatingService$100000009;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000009"
.end annotation


# instance fields
.field private initialTouchX:F

.field private initialTouchY:F

.field private initialX:F

.field private initialY:F

.field private final this$0:Lgtandroid/universal/FloatingService;

.field private final val$dragHandle:Landroid/widget/LinearLayout;

.field private final val$menuParams:Landroid/view/WindowManager$LayoutParams;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;Landroid/view/WindowManager$LayoutParams;Landroid/widget/LinearLayout;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000009;->this$0:Lgtandroid/universal/FloatingService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000009;->val$menuParams:Landroid/view/WindowManager$LayoutParams;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000009;->val$dragHandle:Landroid/widget/LinearLayout;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000009;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000009;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 17
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 554
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object v12, v2

    invoke-virtual {v12}, Landroid/view/MotionEvent;->getAction()I

    move-result v12

    packed-switch v12, :pswitch_data_0

    .line 587
    const/4 v12, 0x0

    move v0, v12

    :goto_0
    return v0

    .line 556
    :pswitch_0
    move-object v12, v0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/FloatingService$100000009;->val$menuParams:Landroid/view/WindowManager$LayoutParams;

    iget v13, v13, Landroid/view/WindowManager$LayoutParams;->x:I

    int-to-float v13, v13

    iput v13, v12, Lgtandroid/universal/FloatingService$100000009;->initialX:F

    .line 557
    move-object v12, v0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/FloatingService$100000009;->val$menuParams:Landroid/view/WindowManager$LayoutParams;

    iget v13, v13, Landroid/view/WindowManager$LayoutParams;->y:I

    int-to-float v13, v13

    iput v13, v12, Lgtandroid/universal/FloatingService$100000009;->initialY:F

    .line 558
    move-object v12, v0

    move-object v13, v2

    invoke-virtual {v13}, Landroid/view/MotionEvent;->getRawX()F

    move-result v13

    iput v13, v12, Lgtandroid/universal/FloatingService$100000009;->initialTouchX:F

    .line 559
    move-object v12, v0

    move-object v13, v2

    invoke-virtual {v13}, Landroid/view/MotionEvent;->getRawY()F

    move-result v13

    iput v13, v12, Lgtandroid/universal/FloatingService$100000009;->initialTouchY:F

    .line 560
    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/FloatingService$100000009;->val$dragHandle:Landroid/widget/LinearLayout;

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/FloatingService$100000009;->this$0:Lgtandroid/universal/FloatingService;

    const v14, -0xff1a01

    const/16 v15, 0x3c

    invoke-static {v13, v14, v15}, Lgtandroid/universal/FloatingService;->access$1000006(Lgtandroid/universal/FloatingService;II)I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/view/View;->setBackgroundColor(I)V

    .line 561
    const/4 v12, 0x1

    move v0, v12

    goto :goto_0

    .line 564
    :pswitch_1
    move-object v12, v2

    invoke-virtual {v12}, Landroid/view/MotionEvent;->getRawX()F

    move-result v12

    move-object v13, v0

    iget v13, v13, Lgtandroid/universal/FloatingService$100000009;->initialTouchX:F

    sub-float/2addr v12, v13

    move v4, v12

    .line 565
    move-object v12, v2

    invoke-virtual {v12}, Landroid/view/MotionEvent;->getRawY()F

    move-result v12

    move-object v13, v0

    iget v13, v13, Lgtandroid/universal/FloatingService$100000009;->initialTouchY:F

    sub-float/2addr v12, v13

    move v5, v12

    .line 567
    move-object v12, v0

    iget v12, v12, Lgtandroid/universal/FloatingService$100000009;->initialX:F

    move v13, v4

    add-float/2addr v12, v13

    move v6, v12

    .line 568
    move-object v12, v0

    iget v12, v12, Lgtandroid/universal/FloatingService$100000009;->initialY:F

    move v13, v5

    add-float/2addr v12, v13

    move v7, v12

    .line 570
    new-instance v12, Landroid/graphics/Point;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    invoke-direct {v13}, Landroid/graphics/Point;-><init>()V

    move-object v8, v12

    .line 571
    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/FloatingService$100000009;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v12}, Lgtandroid/universal/FloatingService;->access$L1000010(Lgtandroid/universal/FloatingService;)Landroid/view/WindowManager;

    move-result-object v12

    invoke-interface {v12}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v12

    move-object v13, v8

    invoke-virtual {v12, v13}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V

    .line 572
    move-object v12, v8

    iget v12, v12, Landroid/graphics/Point;->x:I

    move v9, v12

    .line 573
    move-object v12, v8

    iget v12, v12, Landroid/graphics/Point;->y:I

    move v10, v12

    .line 575
    const/4 v12, 0x0

    int-to-float v12, v12

    move v13, v6

    move v14, v9

    const/16 v15, 0x1c2

    add-int/lit16 v14, v14, -0x1c2

    int-to-float v14, v14

    invoke-static {v13, v14}, Ljava/lang/Math;->min(FF)F

    move-result v13

    invoke-static {v12, v13}, Ljava/lang/Math;->max(FF)F

    move-result v12

    move v6, v12

    .line 576
    const/4 v12, 0x0

    int-to-float v12, v12

    move v13, v7

    move v14, v10

    const/16 v15, 0x64

    add-int/lit8 v14, v14, -0x64

    int-to-float v14, v14

    invoke-static {v13, v14}, Ljava/lang/Math;->min(FF)F

    move-result v13

    invoke-static {v12, v13}, Ljava/lang/Math;->max(FF)F

    move-result v12

    move v7, v12

    .line 578
    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/FloatingService$100000009;->val$menuParams:Landroid/view/WindowManager$LayoutParams;

    move v13, v6

    float-to-int v13, v13

    iput v13, v12, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 579
    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/FloatingService$100000009;->val$menuParams:Landroid/view/WindowManager$LayoutParams;

    move v13, v7

    float-to-int v13, v13

    iput v13, v12, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 580
    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/FloatingService$100000009;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v12}, Lgtandroid/universal/FloatingService;->access$L1000010(Lgtandroid/universal/FloatingService;)Landroid/view/WindowManager;

    move-result-object v12

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/FloatingService$100000009;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v13}, Lgtandroid/universal/FloatingService;->access$L1000012(Lgtandroid/universal/FloatingService;)Landroid/widget/LinearLayout;

    move-result-object v13

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/FloatingService$100000009;->val$menuParams:Landroid/view/WindowManager$LayoutParams;

    invoke-interface {v12, v13, v14}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 581
    const/4 v12, 0x1

    move v0, v12

    goto/16 :goto_0

    .line 584
    :pswitch_2
    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/FloatingService$100000009;->val$dragHandle:Landroid/widget/LinearLayout;

    const v13, -0xedebe3

    invoke-virtual {v12, v13}, Landroid/view/View;->setBackgroundColor(I)V

    .line 585
    const/4 v12, 0x1

    move v0, v12

    goto/16 :goto_0

    .line 554
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
