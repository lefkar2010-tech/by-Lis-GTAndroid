.class Lgtandroid/universal/FloatingService$100000008;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000008"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;

.field private final val$contentContainer:Landroid/widget/LinearLayout;

.field private final val$tabChat:Landroid/widget/Button;

.field private final val$tabCheats:Landroid/widget/Button;

.field private final val$tabSettings:Landroid/widget/Button;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/LinearLayout;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/FloatingService$100000008;->this$0:Lgtandroid/universal/FloatingService;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/FloatingService$100000008;->val$tabChat:Landroid/widget/Button;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/FloatingService$100000008;->val$tabCheats:Landroid/widget/Button;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/FloatingService$100000008;->val$tabSettings:Landroid/widget/Button;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/FloatingService$100000008;->val$contentContainer:Landroid/widget/LinearLayout;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000008;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000008;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 541
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000008;->this$0:Lgtandroid/universal/FloatingService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000008;->val$tabChat:Landroid/widget/Button;

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Lgtandroid/universal/FloatingService;->access$1000009(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Z)V

    .line 542
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000008;->this$0:Lgtandroid/universal/FloatingService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000008;->val$tabCheats:Landroid/widget/Button;

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Lgtandroid/universal/FloatingService;->access$1000009(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Z)V

    .line 543
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000008;->this$0:Lgtandroid/universal/FloatingService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000008;->val$tabSettings:Landroid/widget/Button;

    const/4 v5, 0x1

    invoke-static {v3, v4, v5}, Lgtandroid/universal/FloatingService;->access$1000009(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Z)V

    .line 544
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000008;->this$0:Lgtandroid/universal/FloatingService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000008;->val$contentContainer:Landroid/widget/LinearLayout;

    invoke-static {v3, v4}, Lgtandroid/universal/FloatingService;->access$1000063(Lgtandroid/universal/FloatingService;Landroid/widget/LinearLayout;)V

    return-void
.end method
