.class Lgtandroid/universal/JailAlertService$100000000;
.super Landroid/content/BroadcastReceiver;
.source "JailAlertService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/JailAlertService$100000000;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v3, v0

    invoke-direct {v3}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000000;)Lgtandroid/universal/JailAlertService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000000;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 386
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v8, v2

    const-string v9, "nick"

    invoke-virtual {v8, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v4, v8

    .line 387
    move-object v8, v2

    const-string v9, "id"

    invoke-virtual {v8, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v5, v8

    .line 388
    move-object v8, v2

    const-string v9, "sourceTime"

    invoke-virtual {v8, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v6, v8

    .line 389
    move-object v8, v4

    if-eqz v8, :cond_0

    move-object v8, v5

    if-eqz v8, :cond_0

    .line 390
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/JailAlertService$100000000;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v9, v4

    move-object v10, v5

    move-object v11, v6

    invoke-static {v8, v9, v10, v11}, Lgtandroid/universal/JailAlertService;->access$1000101(Lgtandroid/universal/JailAlertService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    return-void
.end method
