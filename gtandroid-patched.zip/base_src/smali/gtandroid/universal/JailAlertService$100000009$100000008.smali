.class Lgtandroid/universal/JailAlertService$100000009$100000008;
.super Ljava/lang/Object;
.source "JailAlertService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService$100000009;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000008"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService$100000009;

.field private final val$pkg:Ljava/lang/String;

.field private final val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService$100000009;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/JailAlertService$100000009$100000008;->this$0:Lgtandroid/universal/JailAlertService$100000009;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/JailAlertService$100000009$100000008;->val$pkg:Ljava/lang/String;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/JailAlertService$100000009$100000008;->val$text:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000009$100000008;)Lgtandroid/universal/JailAlertService$100000009;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000009$100000008;->this$0:Lgtandroid/universal/JailAlertService$100000009;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 624
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService$100000009$100000008;->this$0:Lgtandroid/universal/JailAlertService$100000009;

    invoke-static {v2}, Lgtandroid/universal/JailAlertService$100000009;->access$0(Lgtandroid/universal/JailAlertService$100000009;)Lgtandroid/universal/JailAlertService;

    move-result-object v2

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000009$100000008;->val$pkg:Ljava/lang/String;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/JailAlertService$100000009$100000008;->val$text:Ljava/lang/String;

    invoke-static {v2, v3, v4}, Lgtandroid/universal/JailAlertService;->access$1000094(Lgtandroid/universal/JailAlertService;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
