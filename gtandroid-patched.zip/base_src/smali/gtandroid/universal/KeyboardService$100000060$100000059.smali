.class Lgtandroid/universal/KeyboardService$100000060$100000059;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Lgtandroid/universal/KeyboardService$CommandCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService$100000060;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000059"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService$100000060;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService$100000060;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000060$100000059;->this$0:Lgtandroid/universal/KeyboardService$100000060;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000060$100000059;)Lgtandroid/universal/KeyboardService$100000060;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000060$100000059;->this$0:Lgtandroid/universal/KeyboardService$100000060;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onCommand(Ljava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2631
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000060$100000059;->this$0:Lgtandroid/universal/KeyboardService$100000060;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService$100000060;->access$0(Lgtandroid/universal/KeyboardService$100000060;)Lgtandroid/universal/KeyboardService;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v6, v4

    move-object v4, v6

    move-object v5, v6

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    const-string v5, "/gethere "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    move-object v5, v1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    return-void
.end method
