.class Lgtandroid/universal/KeyboardService$100000103;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Lgtandroid/universal/KeyboardService$ValueCb;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000103"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$follow:[Z

.field private final val$onDone:Ljava/lang/Runnable;

.field private final val$selName:[Ljava/lang/String;

.field private final val$selText:[Ljava/lang/String;

.field private final val$word:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/Runnable;[Ljava/lang/String;Ljava/lang/String;[Z[Ljava/lang/String;)V
    .locals 10

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object/from16 v6, p6

    move-object v8, v0

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    move-object v8, v0

    move-object v9, v1

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000103;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v8, v0

    move-object v9, v2

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000103;->val$onDone:Ljava/lang/Runnable;

    move-object v8, v0

    move-object v9, v3

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000103;->val$selName:[Ljava/lang/String;

    move-object v8, v0

    move-object v9, v4

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000103;->val$word:Ljava/lang/String;

    move-object v8, v0

    move-object v9, v5

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000103;->val$follow:[Z

    move-object v8, v0

    move-object v9, v6

    iput-object v9, v8, Lgtandroid/universal/KeyboardService$100000103;->val$selText:[Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000103;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000103;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onValue(Ljava/lang/String;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4115
    move-object v0, p0

    move-object/from16 v1, p1

    move-object v6, v1

    const-string v7, "\ud83d\udcbe"

    invoke-virtual {v6, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_0

    .line 4116
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000103;->val$onDone:Ljava/lang/Runnable;

    invoke-interface {v6}, Ljava/lang/Runnable;->run()V

    .line 4129
    :goto_0
    return-void

    .line 4119
    :cond_0
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000103;->val$selName:[Ljava/lang/String;

    const/4 v7, 0x0

    aget-object v6, v6, v7

    if-nez v6, :cond_1

    .line 4120
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000103;->this$0:Lgtandroid/universal/KeyboardService;

    const-string v7, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442"

    const/4 v8, 0x0

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 4121
    goto :goto_0

    .line 4123
    :cond_1
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000103;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    invoke-static {v6}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v6

    move-object v3, v6

    .line 4124
    move-object v6, v3

    new-instance v7, Lgtandroid/universal/TriggerData$Trigger;

    move-object v14, v7

    move-object v7, v14

    move-object v8, v14

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000103;->val$word:Ljava/lang/String;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/KeyboardService$100000103;->val$follow:[Z

    const/4 v11, 0x0

    aget-boolean v10, v10, v11

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/KeyboardService$100000103;->val$selName:[Ljava/lang/String;

    const/4 v12, 0x0

    aget-object v11, v11, v12

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/KeyboardService$100000103;->val$selText:[Ljava/lang/String;

    const/4 v13, 0x0

    aget-object v12, v12, v13

    invoke-direct {v8, v9, v10, v11, v12}, Lgtandroid/universal/TriggerData$Trigger;-><init>(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V

    invoke-static {v6, v7}, Lgtandroid/universal/TriggerData;->upsert(Ljava/util/List;Lgtandroid/universal/TriggerData$Trigger;)Z

    move-result v6

    move v4, v6

    .line 4126
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000103;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    move-object v7, v3

    invoke-static {v6, v7}, Lgtandroid/universal/TriggerData;->save(Landroid/content/SharedPreferences;Ljava/util/List;)V

    .line 4127
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000103;->this$0:Lgtandroid/universal/KeyboardService;

    move v7, v4

    if-eqz v7, :cond_2

    const-string v7, "\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043e\u0431\u043d\u043e\u0432\u043b\u0451\u043d"

    :goto_1
    const/4 v8, 0x0

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 4129
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000103;->val$onDone:Ljava/lang/Runnable;

    invoke-interface {v6}, Ljava/lang/Runnable;->run()V

    goto :goto_0

    .line 4127
    :cond_2
    const-string v7, "\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    goto :goto_1
.end method
