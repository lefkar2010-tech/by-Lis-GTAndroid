.class public final Lgtandroid/universal/AppLogger;
.super Ljava/lang/Object;
.source "AppLogger.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/AppLogger$100000000;
    }
.end annotation


# static fields
.field private static final LOG_FILE_NAME:Ljava/lang/String; = "error_log.txt"

.field private static final MAX_LOG_SIZE_BYTES:J = 0x4b000L

.field private static final TS_FORMAT:Ljava/text/SimpleDateFormat;


# direct methods
.method static final constructor <clinit>()V
    .locals 7

    new-instance v2, Ljava/text/SimpleDateFormat;

    move-object v6, v2

    move-object v2, v6

    move-object v3, v6

    const-string v4, "dd.MM HH:mm:ss"

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v5

    invoke-direct {v3, v4, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    sput-object v2, Lgtandroid/universal/AppLogger;->TS_FORMAT:Ljava/text/SimpleDateFormat;

    return-void
.end method

.method constructor <init>()V
    .locals 3

    .prologue
    .line 20
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static declared-synchronized clear(Landroid/content/Context;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .prologue
    .line 83
    move-object v0, p0

    const-class v5, Lgtandroid/universal/AppLogger;

    monitor-enter v5

    move-object v4, v0

    :try_start_0
    invoke-static {v4}, Lgtandroid/universal/AppLogger;->logFile(Landroid/content/Context;)Ljava/io/File;

    move-result-object v4

    move-object v2, v4

    .line 84
    move-object v4, v2

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result v4

    if-eqz v4, :cond_0

    .line 85
    move-object v4, v2

    invoke-virtual {v4}, Ljava/io/File;->delete()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result v4

    :cond_0
    monitor-exit v5

    return-void

    .line 83
    :catchall_0
    move-exception v0

    monitor-exit v5

    throw v0
.end method

.method public static installCrashHandler(Landroid/content/Context;Ljava/lang/String;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 52
    move-object v0, p0

    move-object v1, p1

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v5

    move-object v3, v5

    .line 53
    new-instance v5, Lgtandroid/universal/AppLogger$100000000;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    move-object v7, v0

    move-object v8, v1

    move-object v9, v3

    invoke-direct {v6, v7, v8, v9}, Lgtandroid/universal/AppLogger$100000000;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Thread$UncaughtExceptionHandler;)V

    invoke-static {v5}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    return-void
.end method

.method public static declared-synchronized log(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 27
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    const-class v16, Lgtandroid/universal/AppLogger;

    monitor-enter v16

    move-object v7, v0

    if-nez v7, :cond_0

    .line 35
    :goto_0
    monitor-exit v16

    return-void

    .line 29
    :cond_0
    :try_start_0
    new-instance v7, Ljava/lang/StringBuffer;

    move-object/from16 v17, v7

    move-object/from16 v7, v17

    move-object/from16 v8, v17

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object/from16 v17, v8

    move-object/from16 v8, v17

    move-object/from16 v9, v17

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v9, Ljava/lang/StringBuffer;

    move-object/from16 v17, v9

    move-object/from16 v9, v17

    move-object/from16 v10, v17

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v17, v11

    move-object/from16 v11, v17

    move-object/from16 v12, v17

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "["

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    sget-object v13, Lgtandroid/universal/AppLogger;->TS_FORMAT:Ljava/text/SimpleDateFormat;

    new-instance v14, Ljava/util/Date;

    move-object/from16 v17, v14

    move-object/from16 v14, v17

    move-object/from16 v15, v17

    invoke-direct {v15}, Ljava/util/Date;-><init>()V

    invoke-virtual {v13, v14}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, "] "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move-object v11, v1

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, ": "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v2

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, "\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v4, v7

    .line 30
    new-instance v7, Ljava/io/FileWriter;

    move-object/from16 v17, v7

    move-object/from16 v7, v17

    move-object/from16 v8, v17

    move-object v9, v0

    invoke-static {v9}, Lgtandroid/universal/AppLogger;->logFile(Landroid/content/Context;)Ljava/io/File;

    move-result-object v9

    const/4 v10, 0x1

    invoke-direct {v8, v9, v10}, Ljava/io/FileWriter;-><init>(Ljava/io/File;Z)V

    move-object v5, v7

    .line 31
    move-object v7, v5

    move-object v8, v4

    invoke-virtual {v7, v8}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 32
    move-object v7, v5

    invoke-virtual {v7}, Ljava/io/OutputStreamWriter;->close()V

    .line 33
    move-object v7, v0

    invoke-static {v7}, Lgtandroid/universal/AppLogger;->trimIfNeeded(Landroid/content/Context;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 35
    :goto_1
    goto/16 :goto_0

    .line 33
    :catch_0
    move-exception v7

    move-object v4, v7

    .line 35
    move-object v7, v4

    :try_start_1
    invoke-virtual {v7}, Ljava/lang/Throwable;->printStackTrace()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    .line 27
    :catchall_0
    move-exception v0

    monitor-exit v16

    throw v0
.end method

.method public static declared-synchronized logException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/Throwable;",
            ")V"
        }
    .end annotation

    .prologue
    .line 40
    move-object v0, p0

    move-object v1, p1

    move-object/from16 v2, p2

    const-class v12, Lgtandroid/universal/AppLogger;

    monitor-enter v12

    move-object v9, v0

    if-eqz v9, :cond_0

    move-object v9, v2

    if-nez v9, :cond_1

    .line 48
    :cond_0
    :goto_0
    monitor-exit v12

    return-void

    .line 41
    :cond_1
    :try_start_0
    new-instance v9, Ljava/lang/StringBuilder;

    move-object v13, v9

    move-object v9, v13

    move-object v10, v13

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move-object v4, v9

    .line 42
    move-object v9, v4

    move-object v10, v2

    invoke-virtual {v10}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    .line 43
    move-object v9, v2

    invoke-virtual {v9}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v9

    move-object v5, v9

    .line 44
    move-object v9, v5

    array-length v9, v9

    const/16 v10, 0xc

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v9

    move v6, v9

    .line 45
    const/4 v9, 0x0

    move v7, v9

    :goto_1
    move v9, v7

    move v10, v6

    if-lt v9, v10, :cond_2

    .line 48
    move-object v9, v0

    move-object v10, v1

    move-object v11, v4

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v9, v10, v11}, Lgtandroid/universal/AppLogger;->log(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    .line 46
    :cond_2
    move-object v9, v4

    const-string v10, "\n    at "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    move-object v10, v5

    move v11, v7

    aget-object v10, v10, v11

    invoke-virtual {v10}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-result-object v9

    .line 45
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    .line 40
    :catchall_0
    move-exception v0

    monitor-exit v12

    throw v0
.end method

.method private static logFile(Landroid/content/Context;)Ljava/io/File;
    .locals 8

    .prologue
    .line 23
    move-object v0, p0

    new-instance v3, Ljava/io/File;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    move-object v5, v0

    invoke-virtual {v5}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v5

    const-string v6, "error_log.txt"

    invoke-direct {v4, v5, v6}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object v0, v3

    return-object v0
.end method

.method public static readAll(Landroid/content/Context;)Ljava/lang/String;
    .locals 15

    .prologue
    .line 69
    move-object v1, p0

    move-object v8, v1

    invoke-static {v8}, Lgtandroid/universal/AppLogger;->logFile(Landroid/content/Context;)Ljava/io/File;

    move-result-object v8

    move-object v3, v8

    .line 70
    move-object v8, v3

    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    move-result v8

    if-nez v8, :cond_0

    const-string v8, ""

    move-object v1, v8

    .line 78
    :goto_0
    return-object v1

    .line 72
    :cond_0
    :try_start_0
    new-instance v8, Ljava/io/FileInputStream;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v3

    invoke-direct {v9, v10}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    move-object v4, v8

    .line 73
    move-object v8, v3

    invoke-virtual {v8}, Ljava/io/File;->length()J

    move-result-wide v8

    long-to-int v8, v8

    new-array v8, v8, [B

    move-object v5, v8

    .line 74
    move-object v8, v4

    move-object v9, v5

    invoke-virtual {v8, v9}, Ljava/io/FileInputStream;->read([B)I

    move-result v8

    move v6, v8

    .line 75
    move-object v8, v4

    invoke-virtual {v8}, Ljava/io/FileInputStream;->close()V

    .line 76
    new-instance v8, Ljava/lang/String;

    move-object v14, v8

    move-object v8, v14

    move-object v9, v14

    move-object v10, v5

    const/4 v11, 0x0

    move v12, v6

    const/4 v13, 0x0

    invoke-static {v12, v13}, Ljava/lang/Math;->max(II)I

    move-result v12

    invoke-direct {v9, v10, v11, v12}, Ljava/lang/String;-><init>([BII)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    move-object v1, v8

    goto :goto_0

    :catch_0
    move-exception v8

    move-object v4, v8

    .line 78
    const-string v8, ""

    move-object v1, v8

    goto :goto_0
.end method

.method private static trimIfNeeded(Landroid/content/Context;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")V"
        }
    .end annotation

    .prologue
    .line 90
    move-object v0, p0

    move-object v8, v0

    invoke-static {v8}, Lgtandroid/universal/AppLogger;->logFile(Landroid/content/Context;)Ljava/io/File;

    move-result-object v8

    move-object v2, v8

    .line 91
    move-object v8, v2

    invoke-virtual {v8}, Ljava/io/File;->length()J

    move-result-wide v8

    const-wide/32 v10, 0x4b000

    cmp-long v8, v8, v10

    if-gtz v8, :cond_0

    .line 102
    :goto_0
    return-void

    .line 93
    :cond_0
    move-object v8, v0

    :try_start_0
    invoke-static {v8}, Lgtandroid/universal/AppLogger;->readAll(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    move-object v3, v8

    .line 95
    move-object v8, v3

    move-object v9, v3

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v9

    const/4 v10, 0x2

    div-int/lit8 v9, v9, 0x2

    invoke-virtual {v8, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v8

    move-object v4, v8

    .line 96
    move-object v8, v4

    const/16 v9, 0xa

    invoke-virtual {v8, v9}, Ljava/lang/String;->indexOf(I)I

    move-result v8

    move v5, v8

    .line 97
    move v8, v5

    const/4 v9, 0x0

    if-lt v8, v9, :cond_1

    move-object v8, v4

    move v9, v5

    const/4 v10, 0x1

    add-int/lit8 v9, v9, 0x1

    invoke-virtual {v8, v9}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v8

    move-object v4, v8

    .line 98
    :cond_1
    new-instance v8, Ljava/io/FileOutputStream;

    move-object v12, v8

    move-object v8, v12

    move-object v9, v12

    move-object v10, v2

    const/4 v11, 0x0

    invoke-direct {v9, v10, v11}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    move-object v6, v8

    .line 99
    move-object v8, v6

    move-object v9, v4

    invoke-virtual {v9}, Ljava/lang/String;->getBytes()[B

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/io/FileOutputStream;->write([B)V

    .line 100
    move-object v8, v6

    invoke-virtual {v8}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 102
    :goto_1
    goto :goto_0

    .line 100
    :catch_0
    move-exception v8

    move-object v3, v8

    .line 102
    move-object v8, v3

    invoke-virtual {v8}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_1
.end method
