.class public Lgtandroid/universal/NeonUi$StatusBadge;
.super Landroid/view/View;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "StatusBadge"
.end annotation


# instance fields
.field private final p:Landroid/graphics/Paint;

.field private reports:I

.field private time:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 8

    .prologue
    .line 1367
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v3, v0

    new-instance v4, Landroid/graphics/Paint;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const/4 v6, 0x1

    invoke-direct {v5, v6}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v4, v3, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move-object v3, v0

    const-string v4, "--:--"

    iput-object v4, v3, Lgtandroid/universal/NeonUi$StatusBadge;->time:Ljava/lang/String;

    move-object v3, v0

    const/4 v4, 0x0

    iput v4, v3, Lgtandroid/universal/NeonUi$StatusBadge;->reports:I

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1381
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object v12, v1

    invoke-virtual {v12}, Landroid/view/View;->getWidth()I

    move-result v12

    int-to-float v12, v12

    move v4, v12

    .line 1382
    move-object v12, v1

    invoke-virtual {v12}, Landroid/view/View;->getHeight()I

    move-result v12

    int-to-float v12, v12

    move v5, v12

    .line 1383
    move v12, v4

    move v13, v5

    invoke-static {v12, v13}, Ljava/lang/Math;->min(FF)F

    move-result v12

    move v6, v12

    .line 1384
    move v12, v6

    const/4 v13, 0x0

    cmpg-float v12, v12, v13

    if-gtz v12, :cond_0

    .line 1422
    :goto_0
    return-void

    .line 1385
    :cond_0
    move v12, v4

    const/high16 v13, 0x40000000    # 2.0f

    div-float/2addr v12, v13

    move v7, v12

    .line 1386
    move v12, v5

    const/high16 v13, 0x40000000    # 2.0f

    div-float/2addr v12, v13

    move v8, v12

    .line 1387
    move v12, v6

    const/high16 v13, 0x40000000    # 2.0f

    div-float/2addr v12, v13

    move v9, v12

    .line 1388
    move-object v12, v1

    invoke-virtual {v12}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    invoke-virtual {v12}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v12

    iget v12, v12, Landroid/util/DisplayMetrics;->density:F

    move v10, v12

    .line 1390
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1391
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const/high16 v13, 0x40400000    # 3.0f

    move v14, v10

    mul-float/2addr v13, v14

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1392
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const v13, -0xd13701

    const/16 v14, 0x55

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 1393
    move-object v12, v2

    move v13, v7

    move v14, v8

    move v15, v9

    const/high16 v16, 0x3fc00000    # 1.5f

    move/from16 v17, v10

    mul-float v16, v16, v17

    sub-float v15, v15, v16

    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move-object/from16 v16, v0

    invoke-virtual/range {v12 .. v16}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1395
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1396
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    new-instance v13, Landroid/graphics/RadialGradient;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    move v15, v7

    move/from16 v16, v8

    const v17, 0x3f4ccccd    # 0.8f

    mul-float v16, v16, v17

    move/from16 v17, v9

    const v18, -0xe5c574

    const v19, -0xf6efcd

    sget-object v20, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v14 .. v20}, Landroid/graphics/RadialGradient;-><init>(FFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    move-result-object v12

    .line 1398
    move-object v12, v2

    move v13, v7

    move v14, v8

    move v15, v9

    const/high16 v16, 0x40400000    # 3.0f

    move/from16 v17, v10

    mul-float v16, v16, v17

    sub-float v15, v15, v16

    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move-object/from16 v16, v0

    invoke-virtual/range {v12 .. v16}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1399
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const/4 v13, 0x0

    check-cast v13, Landroid/graphics/Shader;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    move-result-object v12

    .line 1401
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1402
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const v13, 0x3fcccccd    # 1.6f

    move v14, v10

    mul-float/2addr v13, v14

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1403
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const v13, -0xd13701

    const/16 v14, 0xee

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 1404
    move-object v12, v2

    move v13, v7

    move v14, v8

    move v15, v9

    const/high16 v16, 0x40400000    # 3.0f

    move/from16 v17, v10

    mul-float v16, v16, v17

    sub-float v15, v15, v16

    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move-object/from16 v16, v0

    invoke-virtual/range {v12 .. v16}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1406
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1407
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 1408
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object v12

    .line 1409
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const/4 v13, -0x1

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 1410
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move v13, v6

    const v14, 0x3e8a3d71    # 0.27f

    mul-float/2addr v13, v14

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1411
    move-object v12, v2

    move-object v13, v1

    iget-object v13, v13, Lgtandroid/universal/NeonUi$StatusBadge;->time:Ljava/lang/String;

    move v14, v7

    move v15, v8

    move/from16 v16, v6

    const v17, 0x3ca3d70a    # 0.02f

    mul-float v16, v16, v17

    sub-float v15, v15, v16

    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move-object/from16 v16, v0

    invoke-virtual/range {v12 .. v16}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 1413
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1414
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move v13, v10

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1415
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const v13, -0x907937

    const/16 v14, 0x99

    invoke-static {v13, v14}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v13

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 1416
    move-object v12, v2

    move v13, v7

    move v14, v6

    const v15, 0x3e6147ae    # 0.22f

    mul-float/2addr v14, v15

    sub-float/2addr v13, v14

    move v14, v8

    move v15, v6

    const v16, 0x3d8f5c29    # 0.07f

    mul-float v15, v15, v16

    add-float/2addr v14, v15

    move v15, v7

    move/from16 v16, v6

    const v17, 0x3e6147ae    # 0.22f

    mul-float v16, v16, v17

    add-float v15, v15, v16

    move/from16 v16, v8

    move/from16 v17, v6

    const v18, 0x3d8f5c29    # 0.07f

    mul-float v17, v17, v18

    add-float v16, v16, v17

    move-object/from16 v17, v1

    move-object/from16 v0, v17

    iget-object v0, v0, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move-object/from16 v17, v0

    invoke-virtual/range {v12 .. v17}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1418
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1419
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    sget-object v13, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object v12

    .line 1420
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    const v13, -0x705f28

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setColor(I)V

    .line 1421
    move-object v12, v1

    iget-object v12, v12, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move v13, v6

    const v14, 0x3e19999a    # 0.15f

    mul-float/2addr v13, v14

    invoke-virtual {v12, v13}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 1422
    move-object v12, v2

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    const-string v14, "\u0420\u0415\u041f. "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move-object v14, v1

    iget v14, v14, Lgtandroid/universal/NeonUi$StatusBadge;->reports:I

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    move v14, v7

    move v15, v8

    move/from16 v16, v6

    const v17, 0x3e75c28f    # 0.24f

    mul-float v16, v16, v17

    add-float v15, v15, v16

    move-object/from16 v16, v1

    move-object/from16 v0, v16

    iget-object v0, v0, Lgtandroid/universal/NeonUi$StatusBadge;->p:Landroid/graphics/Paint;

    move-object/from16 v16, v0

    invoke-virtual/range {v12 .. v16}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    goto/16 :goto_0
.end method

.method public setData(Ljava/lang/String;I)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)V"
        }
    .end annotation

    .prologue
    .line 1371
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v1

    if-nez v4, :cond_0

    const-string v4, "--:--"

    move-object v1, v4

    .line 1372
    :cond_0
    move-object v4, v1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/NeonUi$StatusBadge;->time:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1

    move v4, v2

    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/NeonUi$StatusBadge;->reports:I

    if-eq v4, v5, :cond_2

    .line 1373
    :cond_1
    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/NeonUi$StatusBadge;->time:Ljava/lang/String;

    .line 1374
    move-object v4, v0

    move v5, v2

    iput v5, v4, Lgtandroid/universal/NeonUi$StatusBadge;->reports:I

    .line 1375
    move-object v4, v0

    invoke-virtual {v4}, Landroid/view/View;->invalidate()V

    :cond_2
    return-void
.end method
