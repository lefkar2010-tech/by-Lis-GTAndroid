.class Lgtandroid/universal/KeyboardService$100000161$100000160;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService$100000161;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000160"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService$100000161;

.field private final val$s:Lgtandroid/universal/KeyboardService$TileSpec;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService$100000161;Lgtandroid/universal/KeyboardService$TileSpec;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000161$100000160;->this$0:Lgtandroid/universal/KeyboardService$100000161;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000161$100000160;->val$s:Lgtandroid/universal/KeyboardService$TileSpec;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000161$100000160;)Lgtandroid/universal/KeyboardService$100000161;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000161$100000160;->this$0:Lgtandroid/universal/KeyboardService$100000161;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 5632
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000161$100000160;->this$0:Lgtandroid/universal/KeyboardService$100000161;

    invoke-static {v2}, Lgtandroid/universal/KeyboardService$100000161;->access$0(Lgtandroid/universal/KeyboardService$100000161;)Lgtandroid/universal/KeyboardService;

    move-result-object v2

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000161$100000160;->val$s:Lgtandroid/universal/KeyboardService$TileSpec;

    const/4 v4, 0x1

    invoke-static {v2, v3, v4}, Lgtandroid/universal/KeyboardService;->access$1000441(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/KeyboardService$TileSpec;Z)V

    return-void
.end method
