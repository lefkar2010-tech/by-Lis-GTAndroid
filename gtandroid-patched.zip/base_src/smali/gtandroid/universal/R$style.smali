.class public final Lgtandroid/universal/R$style;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "style"
.end annotation


# static fields
.field public static final AppTheme:I = 0x7f070000

.field public static final NeonAlertDialog:I = 0x7f070001

.field public static final NeonDialogButtonNegative:I = 0x7f070003

.field public static final NeonDialogButtonNeutral:I = 0x7f070004

.field public static final NeonDialogButtonPositive:I = 0x7f070002

.field public static final NeonDialogEditText:I = 0x7f070005


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 166
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
