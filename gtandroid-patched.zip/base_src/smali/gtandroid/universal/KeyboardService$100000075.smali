.class Lgtandroid/universal/KeyboardService$100000075;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000075"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000075;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000075;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000075;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3182
    move-object v0, p0

    move-object v4, v0

    :try_start_0
    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000075;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-virtual {v4}, Landroid/inputmethodservice/InputMethodService;->getCurrentInputConnection()Landroid/view/inputmethod/InputConnection;

    move-result-object v4

    move-object v2, v4

    .line 3183
    move-object v4, v2

    if-eqz v4, :cond_0

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000075;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v2

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$1000269(Lgtandroid/universal/KeyboardService;Landroid/view/inputmethod/InputConnection;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 3187
    :cond_0
    :goto_0
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000075;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$1000266(Lgtandroid/universal/KeyboardService;)V

    return-void

    .line 3183
    :catch_0
    move-exception v4

    move-object v2, v4

    .line 3185
    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_0
.end method
