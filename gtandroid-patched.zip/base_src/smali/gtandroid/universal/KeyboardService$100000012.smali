.class Lgtandroid/universal/KeyboardService$100000012;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000012"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000012;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 703
    move-object v0, p0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    if-eqz v6, :cond_0

    .line 704
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "admin_level"

    const/4 v8, 0x1

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v6

    move v2, v6

    .line 705
    move v6, v2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$L1000014(Lgtandroid/universal/KeyboardService;)I

    move-result v7

    if-eq v6, v7, :cond_0

    .line 706
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    move v7, v2

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$S1000014(Lgtandroid/universal/KeyboardService;I)V

    .line 710
    :cond_0
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000223(Lgtandroid/universal/KeyboardService;)V

    .line 711
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000326(Lgtandroid/universal/KeyboardService;)V

    .line 713
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    if-eqz v6, :cond_4

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "auto_reports"

    const-string v8, "[]"

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_0
    move-object v2, v6

    .line 714
    move-object v6, v2

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$L1000024(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    .line 715
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v2

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$S1000024(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 716
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000113(Lgtandroid/universal/KeyboardService;)V

    .line 719
    :cond_1
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000103(Lgtandroid/universal/KeyboardService;)Z

    move-result v6

    if-eqz v6, :cond_2

    .line 720
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    if-eqz v6, :cond_5

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "auto_reports"

    const-string v8, "[]"

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_1
    move-object v3, v6

    .line 721
    move-object v6, v3

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$L1000046(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_2

    .line 722
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000160(Lgtandroid/universal/KeyboardService;)V

    .line 726
    :cond_2
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000104(Lgtandroid/universal/KeyboardService;)Z

    move-result v6

    move v3, v6

    .line 728
    move v6, v3

    if-eqz v6, :cond_3

    .line 729
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    if-eqz v6, :cond_6

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000010(Lgtandroid/universal/KeyboardService;)Landroid/content/SharedPreferences;

    move-result-object v6

    const-string v7, "auto_reports"

    const-string v8, "[]"

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_2
    move-object v4, v6

    .line 730
    move-object v6, v4

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v7}, Lgtandroid/universal/KeyboardService;->access$L1000046(Lgtandroid/universal/KeyboardService;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_3

    .line 731
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000457(Lgtandroid/universal/KeyboardService;)V

    .line 735
    :cond_3
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000012;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$L1000051(Lgtandroid/universal/KeyboardService;)Landroid/os/Handler;

    move-result-object v6

    move-object v7, v0

    const/16 v8, 0xfa

    int-to-long v8, v8

    invoke-virtual {v6, v7, v8, v9}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v6

    return-void

    .line 713
    :cond_4
    const-string v6, "[]"

    goto/16 :goto_0

    .line 720
    :cond_5
    const-string v6, "[]"

    goto :goto_1

    .line 729
    :cond_6
    const-string v6, "[]"

    goto :goto_2
.end method
