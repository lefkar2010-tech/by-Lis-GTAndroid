.class Lgtandroid/universal/MainActivity$100000061;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000061"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$etCommand:Landroid/widget/EditText;

.field private final val$etMinLevel:Landroid/widget/EditText;

.field private final val$etName:Landroid/widget/EditText;

.field private final val$etReason:Landroid/widget/EditText;

.field private final val$etTime:Landroid/widget/EditText;

.field private final val$index:I

.field private final val$typeName:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;Ljava/lang/String;I)V
    .locals 12

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move/from16 v8, p8

    move-object v10, v0

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    move-object v10, v0

    move-object v11, v1

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000061;->this$0:Lgtandroid/universal/MainActivity;

    move-object v10, v0

    move-object v11, v2

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000061;->val$etName:Landroid/widget/EditText;

    move-object v10, v0

    move-object v11, v3

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000061;->val$etCommand:Landroid/widget/EditText;

    move-object v10, v0

    move-object v11, v4

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000061;->val$etTime:Landroid/widget/EditText;

    move-object v10, v0

    move-object v11, v5

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000061;->val$etReason:Landroid/widget/EditText;

    move-object v10, v0

    move-object v11, v6

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000061;->val$etMinLevel:Landroid/widget/EditText;

    move-object v10, v0

    move-object v11, v7

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000061;->val$typeName:Ljava/lang/String;

    move-object v10, v0

    move v11, v8

    iput v11, v10, Lgtandroid/universal/MainActivity$100000061;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000061;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000061;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2237
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->val$etName:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v4, v10

    .line 2238
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->val$etCommand:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v5, v10

    .line 2239
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->val$etTime:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v6, v10

    .line 2240
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->val$etReason:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v7, v10

    .line 2241
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->val$etMinLevel:Landroid/widget/EditText;

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    invoke-interface {v10}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    move-object v8, v10

    .line 2243
    move-object v10, v4

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_1

    move-object v10, v5

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_1

    .line 2244
    move-object v10, v8

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-eqz v10, :cond_0

    const-string v10, "1"

    move-object v8, v10

    .line 2245
    :cond_0
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->this$0:Lgtandroid/universal/MainActivity;

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity$100000061;->val$typeName:Ljava/lang/String;

    move-object v12, v0

    iget v12, v12, Lgtandroid/universal/MainActivity$100000061;->val$index:I

    move-object v13, v4

    move-object v14, v5

    move-object v15, v6

    move-object/from16 v16, v7

    move-object/from16 v17, v8

    invoke-static/range {v10 .. v17}, Lgtandroid/universal/MainActivity;->access$1000148(Lgtandroid/universal/MainActivity;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 2246
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->this$0:Lgtandroid/universal/MainActivity;

    const-string v11, "\u2705 \u041e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u043e!"

    const/4 v12, 0x0

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->this$0:Lgtandroid/universal/MainActivity;

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity$100000061;->val$typeName:Ljava/lang/String;

    invoke-static {v10, v11}, Lgtandroid/universal/MainActivity;->access$1000145(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V

    .line 2248
    :goto_0
    return-void

    :cond_1
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000061;->this$0:Lgtandroid/universal/MainActivity;

    const-string v11, "\u0417\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0438 \u043a\u043e\u043c\u0430\u043d\u0434\u0443!"

    const/4 v12, 0x0

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method
