.class Lgtandroid/universal/KeyboardService$100000091;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000091"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$legacy:Ljava/lang/Runnable;

.field private final val$reopen:Ljava/lang/Runnable;

.field private final val$s:Lgtandroid/universal/KeyboardService$TileSpec;

.field private final val$targetId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/KeyboardService$TileSpec;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000091;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000091;->val$s:Lgtandroid/universal/KeyboardService$TileSpec;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000091;->val$targetId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000091;->val$reopen:Ljava/lang/Runnable;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000091;->val$legacy:Ljava/lang/Runnable;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000091;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000091;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3700
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000091;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000091;->val$s:Lgtandroid/universal/KeyboardService$TileSpec;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000091;->val$targetId:Ljava/lang/String;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000091;->val$reopen:Ljava/lang/Runnable;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000091;->val$legacy:Ljava/lang/Runnable;

    const/4 v7, 0x1

    invoke-static/range {v2 .. v7}, Lgtandroid/universal/KeyboardService;->access$1000311(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/KeyboardService$TileSpec;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;Z)V

    return-void
.end method
