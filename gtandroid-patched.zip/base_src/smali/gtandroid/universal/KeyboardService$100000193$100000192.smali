.class Lgtandroid/universal/KeyboardService$100000193$100000192;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService$100000193;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000192"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService$100000193;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService$100000193;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000193$100000192;->this$0:Lgtandroid/universal/KeyboardService$100000193;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000193$100000192;)Lgtandroid/universal/KeyboardService$100000193;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000193$100000192;->this$0:Lgtandroid/universal/KeyboardService$100000193;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 6892
    move-object v0, p0

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193$100000192;->this$0:Lgtandroid/universal/KeyboardService$100000193;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService$100000193;->access$0(Lgtandroid/universal/KeyboardService$100000193;)Lgtandroid/universal/KeyboardService;

    move-result-object v4

    const/4 v5, 0x1

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$S1000075(Lgtandroid/universal/KeyboardService;Z)V

    .line 6893
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193$100000192;->this$0:Lgtandroid/universal/KeyboardService$100000193;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService$100000193;->access$0(Lgtandroid/universal/KeyboardService$100000193;)Lgtandroid/universal/KeyboardService;

    move-result-object v4

    invoke-virtual {v4}, Landroid/inputmethodservice/InputMethodService;->getCurrentInputConnection()Landroid/view/inputmethod/InputConnection;

    move-result-object v4

    move-object v2, v4

    .line 6894
    move-object v4, v2

    if-eqz v4, :cond_0

    .line 6895
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193$100000192;->this$0:Lgtandroid/universal/KeyboardService$100000193;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService$100000193;->access$0(Lgtandroid/universal/KeyboardService$100000193;)Lgtandroid/universal/KeyboardService;

    move-result-object v4

    move-object v5, v2

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$1000488(Lgtandroid/universal/KeyboardService;Landroid/view/inputmethod/InputConnection;)V

    .line 6897
    :cond_0
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193$100000192;->this$0:Lgtandroid/universal/KeyboardService$100000193;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService$100000193;->access$0(Lgtandroid/universal/KeyboardService$100000193;)Lgtandroid/universal/KeyboardService;

    move-result-object v4

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$L1000073(Lgtandroid/universal/KeyboardService;)Landroid/os/Handler;

    move-result-object v4

    move-object v5, v0

    const/16 v6, 0x2d

    int-to-long v6, v6

    invoke-virtual {v4, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v4

    return-void
.end method
