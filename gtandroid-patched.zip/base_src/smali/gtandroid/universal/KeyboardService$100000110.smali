.class Lgtandroid/universal/KeyboardService$100000110;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000110"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$index:I

.field private final val$pick:Lgtandroid/universal/KeyboardService$NavPick;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/KeyboardService$NavPick;I)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000110;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000110;->val$pick:Lgtandroid/universal/KeyboardService$NavPick;

    move-object v5, v0

    move v6, v3

    iput v6, v5, Lgtandroid/universal/KeyboardService$100000110;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000110;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000110;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4290
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000110;->val$pick:Lgtandroid/universal/KeyboardService$NavPick;

    move-object v4, v0

    iget v4, v4, Lgtandroid/universal/KeyboardService$100000110;->val$index:I

    invoke-interface {v3, v4}, Lgtandroid/universal/KeyboardService$NavPick;->onPick(I)V

    return-void
.end method
