.class Lgtandroid/universal/KeyboardService$100000149;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000149"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$idInput:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Landroid/widget/EditText;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000149;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000149;->val$idInput:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000149;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000149;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 5348
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000149;->val$idInput:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-interface {v5}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v3, v5

    .line 5349
    move-object v5, v3

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_0

    .line 5355
    :goto_0
    return-void

    .line 5353
    :cond_0
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000149;->this$0:Lgtandroid/universal/KeyboardService;

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const-string v7, "/sp "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v3

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 5355
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000149;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$1000091(Lgtandroid/universal/KeyboardService;)V

    goto :goto_0
.end method
