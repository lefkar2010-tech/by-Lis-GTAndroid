.class Lgtandroid/universal/FloatingService$100000003;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000003"
.end annotation


# instance fields
.field private downTime:J

.field private initialTouchX:F

.field private initialTouchY:F

.field private initialX:F

.field private initialY:F

.field private final this$0:Lgtandroid/universal/FloatingService;

.field private final val$iconSize:I

.field private final val$params:Landroid/view/WindowManager$LayoutParams;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;Landroid/view/WindowManager$LayoutParams;I)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000003;->this$0:Lgtandroid/universal/FloatingService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object v5, v0

    move v6, v3

    iput v6, v5, Lgtandroid/universal/FloatingService$100000003;->val$iconSize:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000003;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000003;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 25
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 208
    move-object/from16 v3, p0

    move-object/from16 v4, p1

    move-object/from16 v5, p2

    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Landroid/view/MotionEvent;->getAction()I

    move-result v20

    packed-switch v20, :pswitch_data_0

    .line 248
    const/16 v20, 0x0

    move/from16 v3, v20

    :goto_0
    return v3

    .line 210
    :pswitch_0
    move-object/from16 v20, v3

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    move/from16 v21, v0

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Lgtandroid/universal/FloatingService$100000003;->initialX:F

    .line 211
    move-object/from16 v20, v3

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    move/from16 v21, v0

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Lgtandroid/universal/FloatingService$100000003;->initialY:F

    .line 212
    move-object/from16 v20, v3

    move-object/from16 v21, v5

    invoke-virtual/range {v21 .. v21}, Landroid/view/MotionEvent;->getRawX()F

    move-result v21

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Lgtandroid/universal/FloatingService$100000003;->initialTouchX:F

    .line 213
    move-object/from16 v20, v3

    move-object/from16 v21, v5

    invoke-virtual/range {v21 .. v21}, Landroid/view/MotionEvent;->getRawY()F

    move-result v21

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Lgtandroid/universal/FloatingService$100000003;->initialTouchY:F

    .line 214
    move-object/from16 v20, v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v21

    move-wide/from16 v0, v21

    move-object/from16 v2, v20

    iput-wide v0, v2, Lgtandroid/universal/FloatingService$100000003;->downTime:J

    .line 215
    const/16 v20, 0x1

    move/from16 v3, v20

    goto :goto_0

    .line 218
    :pswitch_1
    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Landroid/view/MotionEvent;->getRawX()F

    move-result v20

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->initialTouchX:F

    move/from16 v21, v0

    sub-float v20, v20, v21

    move/from16 v7, v20

    .line 219
    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Landroid/view/MotionEvent;->getRawY()F

    move-result v20

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->initialTouchY:F

    move/from16 v21, v0

    sub-float v20, v20, v21

    move/from16 v8, v20

    .line 221
    move-object/from16 v20, v3

    move-object/from16 v0, v20

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->initialX:F

    move/from16 v20, v0

    move/from16 v21, v7

    add-float v20, v20, v21

    move/from16 v9, v20

    .line 222
    move-object/from16 v20, v3

    move-object/from16 v0, v20

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->initialY:F

    move/from16 v20, v0

    move/from16 v21, v8

    add-float v20, v20, v21

    move/from16 v10, v20

    .line 224
    new-instance v20, Landroid/graphics/Point;

    move-object/from16 v24, v20

    move-object/from16 v20, v24

    move-object/from16 v21, v24

    invoke-direct/range {v21 .. v21}, Landroid/graphics/Point;-><init>()V

    move-object/from16 v11, v20

    .line 225
    move-object/from16 v20, v3

    move-object/from16 v0, v20

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v20, v0

    invoke-static/range {v20 .. v20}, Lgtandroid/universal/FloatingService;->access$L1000010(Lgtandroid/universal/FloatingService;)Landroid/view/WindowManager;

    move-result-object v20

    invoke-interface/range {v20 .. v20}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v20

    move-object/from16 v21, v11

    invoke-virtual/range {v20 .. v21}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V

    .line 226
    move-object/from16 v20, v11

    move-object/from16 v0, v20

    iget v0, v0, Landroid/graphics/Point;->x:I

    move/from16 v20, v0

    move/from16 v12, v20

    .line 227
    move-object/from16 v20, v11

    move-object/from16 v0, v20

    iget v0, v0, Landroid/graphics/Point;->y:I

    move/from16 v20, v0

    move/from16 v13, v20

    .line 229
    const/16 v20, 0x0

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    move/from16 v21, v9

    move/from16 v22, v12

    move-object/from16 v23, v3

    move-object/from16 v0, v23

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$iconSize:I

    move/from16 v23, v0

    sub-int v22, v22, v23

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-static/range {v21 .. v22}, Ljava/lang/Math;->min(FF)F

    move-result v21

    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->max(FF)F

    move-result v20

    move/from16 v9, v20

    .line 230
    const/16 v20, 0x0

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    move/from16 v21, v10

    move/from16 v22, v13

    move-object/from16 v23, v3

    move-object/from16 v0, v23

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$iconSize:I

    move/from16 v23, v0

    sub-int v22, v22, v23

    move/from16 v0, v22

    int-to-float v0, v0

    move/from16 v22, v0

    invoke-static/range {v21 .. v22}, Ljava/lang/Math;->min(FF)F

    move-result v21

    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->max(FF)F

    move-result v20

    move/from16 v10, v20

    .line 232
    move-object/from16 v20, v3

    move-object/from16 v0, v20

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v20, v0

    move/from16 v21, v9

    move/from16 v0, v21

    float-to-int v0, v0

    move/from16 v21, v0

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 233
    move-object/from16 v20, v3

    move-object/from16 v0, v20

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v20, v0

    move/from16 v21, v10

    move/from16 v0, v21

    float-to-int v0, v0

    move/from16 v21, v0

    move/from16 v0, v21

    move-object/from16 v1, v20

    iput v0, v1, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 234
    move-object/from16 v20, v3

    move-object/from16 v0, v20

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v20, v0

    invoke-static/range {v20 .. v20}, Lgtandroid/universal/FloatingService;->access$L1000010(Lgtandroid/universal/FloatingService;)Landroid/view/WindowManager;

    move-result-object v20

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v21, v0

    invoke-static/range {v21 .. v21}, Lgtandroid/universal/FloatingService;->access$L1000011(Lgtandroid/universal/FloatingService;)Landroid/view/View;

    move-result-object v21

    move-object/from16 v22, v3

    move-object/from16 v0, v22

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v22, v0

    invoke-interface/range {v20 .. v22}, Landroid/view/WindowManager;->updateViewLayout(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 235
    const/16 v20, 0x1

    move/from16 v3, v20

    goto/16 :goto_0

    .line 238
    :pswitch_2
    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Landroid/view/MotionEvent;->getRawX()F

    move-result v20

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->initialTouchX:F

    move/from16 v21, v0

    sub-float v20, v20, v21

    move/from16 v14, v20

    .line 239
    move-object/from16 v20, v5

    invoke-virtual/range {v20 .. v20}, Landroid/view/MotionEvent;->getRawY()F

    move-result v20

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget v0, v0, Lgtandroid/universal/FloatingService$100000003;->initialTouchY:F

    move/from16 v21, v0

    sub-float v20, v20, v21

    move/from16 v15, v20

    .line 240
    move/from16 v20, v14

    move/from16 v21, v14

    mul-float v20, v20, v21

    move/from16 v21, v15

    move/from16 v22, v15

    mul-float v21, v21, v22

    add-float v20, v20, v21

    move/from16 v0, v20

    float-to-double v0, v0

    move-wide/from16 v20, v0

    invoke-static/range {v20 .. v21}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v20

    move-wide/from16 v0, v20

    double-to-float v0, v0

    move/from16 v20, v0

    move/from16 v16, v20

    .line 241
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v20

    move-object/from16 v22, v3

    move-object/from16 v0, v22

    iget-wide v0, v0, Lgtandroid/universal/FloatingService$100000003;->downTime:J

    move-wide/from16 v22, v0

    sub-long v20, v20, v22

    move-wide/from16 v17, v20

    .line 243
    move/from16 v20, v16

    const/16 v21, 0xa

    move/from16 v0, v21

    int-to-float v0, v0

    move/from16 v21, v0

    cmpg-float v20, v20, v21

    if-gez v20, :cond_0

    move-wide/from16 v20, v17

    const/16 v22, 0x12c

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    cmp-long v20, v20, v22

    if-gez v20, :cond_0

    .line 244
    move-object/from16 v20, v3

    move-object/from16 v0, v20

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->this$0:Lgtandroid/universal/FloatingService;

    move-object/from16 v20, v0

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v21, v0

    move-object/from16 v0, v21

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->x:I

    move/from16 v21, v0

    move-object/from16 v22, v3

    move-object/from16 v0, v22

    iget-object v0, v0, Lgtandroid/universal/FloatingService$100000003;->val$params:Landroid/view/WindowManager$LayoutParams;

    move-object/from16 v22, v0

    move-object/from16 v0, v22

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->y:I

    move/from16 v22, v0

    invoke-static/range {v20 .. v22}, Lgtandroid/universal/FloatingService;->access$1000041(Lgtandroid/universal/FloatingService;II)V

    .line 246
    :cond_0
    const/16 v20, 0x1

    move/from16 v3, v20

    goto/16 :goto_0

    .line 208
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
