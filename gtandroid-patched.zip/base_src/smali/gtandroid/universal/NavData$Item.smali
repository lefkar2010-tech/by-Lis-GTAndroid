.class public Lgtandroid/universal/NavData$Item;
.super Ljava/lang/Object;
.source "NavData.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NavData;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "Item"
.end annotation


# instance fields
.field public name:Ljava/lang/String;

.field public pos:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    .prologue
    .line 22
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 23
    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/NavData$Item;->name:Ljava/lang/String;

    .line 24
    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/NavData$Item;->pos:Ljava/lang/String;

    return-void
.end method
