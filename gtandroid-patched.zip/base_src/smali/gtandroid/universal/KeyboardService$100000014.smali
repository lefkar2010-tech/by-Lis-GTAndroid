.class Lgtandroid/universal/KeyboardService$100000014;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000014"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000014;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000014;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000014;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1015
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000014;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v2}, Lgtandroid/universal/KeyboardService;->access$1000124(Lgtandroid/universal/KeyboardService;)V

    .line 1016
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000014;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v2}, Lgtandroid/universal/KeyboardService;->access$L1000000(Lgtandroid/universal/KeyboardService;)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000014;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v2}, Lgtandroid/universal/KeyboardService;->access$L1000000(Lgtandroid/universal/KeyboardService;)Landroid/view/View;

    move-result-object v2

    move-object v3, v0

    const/16 v4, 0x2710

    int-to-long v4, v4

    invoke-virtual {v2, v3, v4, v5}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v2

    :cond_0
    return-void
.end method
