.class interface Lgtandroid/universal/KeyboardService$TileClick;
.super Ljava/lang/Object;
.source "KeyboardService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20a
    name = "TileClick"
.end annotation


# virtual methods
.method public abstract onTile(Lgtandroid/universal/KeyboardService$TileSpec;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgtandroid/universal/KeyboardService$TileSpec;",
            ")V"
        }
    .end annotation
.end method
