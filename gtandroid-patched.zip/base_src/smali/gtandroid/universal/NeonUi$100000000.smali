.class Lgtandroid/universal/NeonUi$100000000;
.super Ljava/lang/Object;
.source "NeonUi.java"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# direct methods
.method constructor <init>()V
    .locals 3

    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "IIIIIIII)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 697
    move-object v0, p0

    move-object v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v6, p6

    move/from16 v7, p7

    move/from16 v8, p8

    move/from16 v9, p9

    move v11, v4

    move v12, v2

    sub-int/2addr v11, v12

    move v12, v8

    move v13, v6

    sub-int/2addr v12, v13

    if-eq v11, v12, :cond_0

    move-object v11, v1

    instance-of v11, v11, Landroid/widget/TextView;

    if-eqz v11, :cond_0

    .line 698
    move-object v11, v1

    check-cast v11, Landroid/widget/TextView;

    invoke-static {v11}, Lgtandroid/universal/NeonUi;->refreshTextLayout(Landroid/widget/TextView;)V

    :cond_0
    return-void
.end method
