.class Lgtandroid/universal/KeyboardService$100000095;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000095"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/KeyboardService$100000095$100000092;,
        Lgtandroid/universal/KeyboardService$100000095$100000093;,
        Lgtandroid/universal/KeyboardService$100000095$100000094;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$back:Ljava/lang/Runnable;

.field private final val$done:Ljava/lang/Runnable;

.field private final val$pre:Ljava/lang/String;

.field private final val$which:I


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;ILjava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000095;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    move v8, v2

    iput v8, v7, Lgtandroid/universal/KeyboardService$100000095;->val$which:I

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000095;->val$pre:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000095;->val$back:Ljava/lang/Runnable;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000095;->val$done:Ljava/lang/Runnable;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000095;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000095;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3764
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/KeyboardService$100000095;->val$which:I

    const/4 v4, 0x0

    if-ne v3, v4, :cond_0

    .line 3765
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000095;->this$0:Lgtandroid/universal/KeyboardService;

    const-string v4, "\u2550\u2550 \u0418\u0421\u0422\u041e\u0420\u0418\u042f \u041d\u0410\u041a\u0410\u0417\u0410\u041d\u0418\u0419: ID \u2550\u2550"

    const-string v5, "ID \u0438\u0433\u0440\u043e\u043a\u0430"

    new-instance v6, Lgtandroid/universal/KeyboardService$100000095$100000092;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    move-object v8, v0

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000095;->val$pre:Ljava/lang/String;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/KeyboardService$100000095;->val$back:Ljava/lang/Runnable;

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/KeyboardService$100000095;->val$done:Ljava/lang/Runnable;

    invoke-direct {v7, v8, v9, v10, v11}, Lgtandroid/universal/KeyboardService$100000095$100000092;-><init>(Lgtandroid/universal/KeyboardService$100000095;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    new-instance v7, Lgtandroid/universal/KeyboardService$100000095$100000093;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    move-object v9, v0

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/KeyboardService$100000095;->val$pre:Ljava/lang/String;

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/KeyboardService$100000095;->val$back:Ljava/lang/Runnable;

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/KeyboardService$100000095;->val$done:Ljava/lang/Runnable;

    invoke-direct {v8, v9, v10, v11, v12}, Lgtandroid/universal/KeyboardService$100000095$100000093;-><init>(Lgtandroid/universal/KeyboardService$100000095;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    invoke-static {v3, v4, v5, v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000383(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Runnable;Lgtandroid/universal/KeyboardService$ValueCb;)V

    .line 3778
    :goto_0
    return-void

    .line 3772
    :cond_0
    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/KeyboardService$100000095;->val$which:I

    const/4 v4, 0x1

    if-ne v3, v4, :cond_1

    .line 3773
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000095;->this$0:Lgtandroid/universal/KeyboardService;

    const-string v4, "\u041f\u0435\u0447\u0430\u0442\u0430\u0439\u0442\u0435 \u043d\u0438\u043a\u2026"

    new-instance v5, Lgtandroid/universal/KeyboardService$100000095$100000094;

    move-object v13, v5

    move-object v5, v13

    move-object v6, v13

    move-object v7, v0

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000095;->val$pre:Ljava/lang/String;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000095;->val$back:Ljava/lang/Runnable;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/KeyboardService$100000095;->val$done:Ljava/lang/Runnable;

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/KeyboardService$100000095$100000094;-><init>(Lgtandroid/universal/KeyboardService$100000095;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;)V

    invoke-static {v3, v4, v5}, Lgtandroid/universal/KeyboardService;->access$1000320(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Lgtandroid/universal/KeyboardService$ValueCb;)V

    goto :goto_0

    .line 3778
    :cond_1
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000095;->val$back:Ljava/lang/Runnable;

    invoke-interface {v3}, Ljava/lang/Runnable;->run()V

    goto :goto_0
.end method
