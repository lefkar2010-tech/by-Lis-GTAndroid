.class Lgtandroid/universal/MainActivity$100000015;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000015"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/MainActivity$100000015$100000014;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$imageView:Landroid/widget/ImageView;

.field private final val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;Landroid/widget/ImageView;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000015;->this$0:Lgtandroid/universal/MainActivity;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000015;->val$url:Ljava/lang/String;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000015;->val$imageView:Landroid/widget/ImageView;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000015;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000015;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 778
    move-object v0, p0

    :try_start_0
    new-instance v5, Ljava/net/URL;

    move-object v11, v5

    move-object v5, v11

    move-object v6, v11

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000015;->val$url:Ljava/lang/String;

    invoke-direct {v6, v7}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5}, Ljava/net/URL;->getContent()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/io/InputStream;

    move-object v2, v5

    .line 779
    move-object v5, v2

    invoke-static {v5}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v5

    move-object v3, v5

    .line 780
    move-object v5, v3

    if-eqz v5, :cond_0

    .line 781
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000015;->this$0:Lgtandroid/universal/MainActivity;

    new-instance v6, Lgtandroid/universal/MainActivity$100000015$100000014;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000015;->val$imageView:Landroid/widget/ImageView;

    move-object v10, v3

    invoke-direct {v7, v8, v9, v10}, Lgtandroid/universal/MainActivity$100000015$100000014;-><init>(Lgtandroid/universal/MainActivity$100000015;Landroid/widget/ImageView;Landroid/graphics/Bitmap;)V

    invoke-virtual {v5, v6}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 789
    :cond_0
    :goto_0
    return-void

    .line 781
    :catch_0
    move-exception v5

    move-object v2, v5

    .line 789
    move-object v5, v2

    invoke-virtual {v5}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_0
.end method
