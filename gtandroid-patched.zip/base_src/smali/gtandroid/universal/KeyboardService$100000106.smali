.class Lgtandroid/universal/KeyboardService$100000106;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Lgtandroid/universal/KeyboardService$ValueCb;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000106"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$adminId:Ljava/lang/String;

.field private final val$nick:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000106;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000106;->val$nick:Ljava/lang/String;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000106;->val$adminId:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000106;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000106;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onValue(Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4202
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    const-string v4, "\u2705"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 4203
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000106;->this$0:Lgtandroid/universal/KeyboardService;

    const-string v4, "/a +"

    invoke-static {v3, v4}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 4204
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000106;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000333(Lgtandroid/universal/KeyboardService;)V

    .line 4205
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000106;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000091(Lgtandroid/universal/KeyboardService;)V

    .line 4207
    :goto_0
    return-void

    :cond_0
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000106;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000106;->val$nick:Ljava/lang/String;

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000106;->val$adminId:Ljava/lang/String;

    invoke-static {v3, v4, v5}, Lgtandroid/universal/KeyboardService;->access$1000359(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0
.end method
