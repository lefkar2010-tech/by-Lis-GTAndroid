.class Lgtandroid/universal/JailAlertService$100000004;
.super Landroid/content/BroadcastReceiver;
.source "JailAlertService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000004"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/JailAlertService$100000004;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v3, v0

    invoke-direct {v3}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000004;)Lgtandroid/universal/JailAlertService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000004;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 441
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/JailAlertService$100000004;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v4}, Lgtandroid/universal/JailAlertService;->access$1000096(Lgtandroid/universal/JailAlertService;)V

    .line 442
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/JailAlertService$100000004;->this$0:Lgtandroid/universal/JailAlertService;

    const-string v5, ""

    invoke-static {v4, v5}, Lgtandroid/universal/JailAlertService;->access$S1000015(Lgtandroid/universal/JailAlertService;Ljava/lang/String;)V

    .line 443
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/JailAlertService$100000004;->this$0:Lgtandroid/universal/JailAlertService;

    const/4 v5, 0x1

    invoke-static {v4, v5}, Lgtandroid/universal/JailAlertService;->access$1000090(Lgtandroid/universal/JailAlertService;Z)V

    return-void
.end method
