.class Lgtandroid/universal/KeyboardService$100000193;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000193"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/KeyboardService$100000193$100000192;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000193;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 9
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 6886
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v2

    invoke-virtual {v4}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v4

    packed-switch v4, :pswitch_data_0

    .line 6914
    :pswitch_0
    const/4 v4, 0x0

    move v0, v4

    :goto_0
    return v0

    .line 6888
    :pswitch_1
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    const/4 v5, 0x0

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$S1000075(Lgtandroid/universal/KeyboardService;Z)V

    .line 6889
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    new-instance v5, Lgtandroid/universal/KeyboardService$100000193$100000192;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    move-object v7, v0

    invoke-direct {v6, v7}, Lgtandroid/universal/KeyboardService$100000193$100000192;-><init>(Lgtandroid/universal/KeyboardService$100000193;)V

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$S1000074(Lgtandroid/universal/KeyboardService;Ljava/lang/Runnable;)V

    .line 6900
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$L1000073(Lgtandroid/universal/KeyboardService;)Landroid/os/Handler;

    move-result-object v4

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$L1000074(Lgtandroid/universal/KeyboardService;)Ljava/lang/Runnable;

    move-result-object v5

    const/16 v6, 0x190

    int-to-long v6, v6

    invoke-virtual {v4, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v4

    .line 6901
    const/4 v4, 0x0

    move v0, v4

    goto :goto_0

    .line 6905
    :pswitch_2
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$L1000074(Lgtandroid/universal/KeyboardService;)Ljava/lang/Runnable;

    move-result-object v4

    if-eqz v4, :cond_0

    .line 6906
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$L1000073(Lgtandroid/universal/KeyboardService;)Landroid/os/Handler;

    move-result-object v4

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$L1000074(Lgtandroid/universal/KeyboardService;)Ljava/lang/Runnable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 6908
    :cond_0
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$L1000075(Lgtandroid/universal/KeyboardService;)Z

    move-result v4

    if-eqz v4, :cond_1

    .line 6909
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000193;->this$0:Lgtandroid/universal/KeyboardService;

    const/4 v5, 0x0

    invoke-static {v4, v5}, Lgtandroid/universal/KeyboardService;->access$S1000075(Lgtandroid/universal/KeyboardService;Z)V

    .line 6910
    const/4 v4, 0x1

    move v0, v4

    goto :goto_0

    .line 6912
    :cond_1
    const/4 v4, 0x0

    move v0, v4

    goto :goto_0

    .line 6886
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_2
        :pswitch_0
        :pswitch_2
    .end packed-switch
.end method
