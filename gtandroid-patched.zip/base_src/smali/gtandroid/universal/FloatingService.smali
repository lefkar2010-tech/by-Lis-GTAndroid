.class public Lgtandroid/universal/FloatingService;
.super Landroid/app/Service;
.source "FloatingService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/FloatingService$100000000;,
        Lgtandroid/universal/FloatingService$100000001;,
        Lgtandroid/universal/FloatingService$100000002;,
        Lgtandroid/universal/FloatingService$100000003;,
        Lgtandroid/universal/FloatingService$100000004;,
        Lgtandroid/universal/FloatingService$100000005;,
        Lgtandroid/universal/FloatingService$100000006;,
        Lgtandroid/universal/FloatingService$100000007;,
        Lgtandroid/universal/FloatingService$100000008;,
        Lgtandroid/universal/FloatingService$100000009;,
        Lgtandroid/universal/FloatingService$100000010;,
        Lgtandroid/universal/FloatingService$100000011;,
        Lgtandroid/universal/FloatingService$100000012;,
        Lgtandroid/universal/FloatingService$100000013;,
        Lgtandroid/universal/FloatingService$100000014;
    }
.end annotation


# static fields
.field private static final BG_CARD:I = -0xedebe3

.field private static final BG_DARK:I = -0xf5f3ee

.field private static final NEON_CYAN:I = -0xff1a01

.field private static final NEON_GREEN:I = -0xc60078

.field private static final NEON_RED:I = -0xb293

.field private static final NEON_VIOLET:I = -0x57aa01

.field public static currentChatMode:I

.field public static currentCheatMode:I


# instance fields
.field private chatMode:I

.field private cheatMode:I

.field private cheatResetReceiver:Landroid/content/BroadcastReceiver;

.field private floatingIconView:Landroid/view/View;

.field private iconUpdateHandler:Landroid/os/Handler;

.field private iconUpdateRunnable:Ljava/lang/Runnable;

.field private keyboardSize:I

.field private keyboardTransparency:I

.field private menuView:Landroid/widget/LinearLayout;

.field private prefs:Landroid/content/SharedPreferences;

.field private resizingContentScroll:Z

.field private updateIconReceiver:Landroid/content/BroadcastReceiver;

.field private windowManager:Landroid/view/WindowManager;


# direct methods
.method static final constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    sput v2, Lgtandroid/universal/FloatingService;->currentChatMode:I

    const/4 v2, 0x0

    sput v2, Lgtandroid/universal/FloatingService;->currentCheatMode:I

    return-void
.end method

.method public constructor <init>()V
    .locals 6

    .prologue
    .line 944
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Landroid/app/Service;-><init>()V

    move-object v2, v0

    const/4 v3, 0x0

    iput v3, v2, Lgtandroid/universal/FloatingService;->chatMode:I

    move-object v2, v0

    const/4 v3, 0x0

    iput v3, v2, Lgtandroid/universal/FloatingService;->cheatMode:I

    move-object v2, v0

    const/4 v3, 0x1

    iput v3, v2, Lgtandroid/universal/FloatingService;->keyboardSize:I

    move-object v2, v0

    const/16 v3, 0x64

    iput v3, v2, Lgtandroid/universal/FloatingService;->keyboardTransparency:I

    move-object v2, v0

    const/4 v3, 0x0

    iput-boolean v3, v2, Lgtandroid/universal/FloatingService;->resizingContentScroll:Z

    move-object v2, v0

    new-instance v3, Landroid/os/Handler;

    move-object v5, v3

    move-object v3, v5

    move-object v4, v5

    invoke-direct {v4}, Landroid/os/Handler;-><init>()V

    iput-object v3, v2, Lgtandroid/universal/FloatingService;->iconUpdateHandler:Landroid/os/Handler;

    return-void
.end method

.method static access$1000006(Lgtandroid/universal/FloatingService;II)I
    .locals 8

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v5, v0

    move v6, v1

    move v7, v2

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/FloatingService;->withAlpha(II)I

    move-result v5

    move v0, v5

    return v0
.end method

.method static access$1000009(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Z)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v5, v0

    move-object v6, v1

    move v7, v2

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/FloatingService;->styleTab(Landroid/widget/Button;Z)V

    return-void
.end method

.method static access$1000021(Lgtandroid/universal/FloatingService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/FloatingService;->computeMenuContentMaxHeight()I

    move-result v3

    move v0, v3

    return v0
.end method

.method static access$1000034(Lgtandroid/universal/FloatingService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/FloatingService;->updateIconBackground()V

    return-void
.end method

.method static access$1000039(Lgtandroid/universal/FloatingService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/FloatingService;->updateIconContent()V

    return-void
.end method

.method static access$1000041(Lgtandroid/universal/FloatingService;II)V
    .locals 8

    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v5, v0

    move v6, v1

    move v7, v2

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/FloatingService;->openMenu(II)V

    return-void
.end method

.method static access$1000042(Lgtandroid/universal/FloatingService;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lgtandroid/universal/FloatingService;->closeMenu()V

    return-void
.end method

.method static access$1000054(Lgtandroid/universal/FloatingService;Landroid/widget/LinearLayout;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/FloatingService;->showChatModeTab(Landroid/widget/LinearLayout;)V

    return-void
.end method

.method static access$1000056(Lgtandroid/universal/FloatingService;Landroid/widget/LinearLayout;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/FloatingService;->showCheatsTab(Landroid/widget/LinearLayout;)V

    return-void
.end method

.method static access$1000063(Lgtandroid/universal/FloatingService;Landroid/widget/LinearLayout;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    invoke-direct {v4, v5}, Lgtandroid/universal/FloatingService;->showSettingsTab(Landroid/widget/LinearLayout;)V

    return-void
.end method

.method static access$L1000001()I
    .locals 3

    sget v2, Lgtandroid/universal/FloatingService;->BG_CARD:I

    move v0, v2

    return v0
.end method

.method static access$L1000002()I
    .locals 3

    sget v2, Lgtandroid/universal/FloatingService;->NEON_CYAN:I

    move v0, v2

    return v0
.end method

.method static access$L1000010(Lgtandroid/universal/FloatingService;)Landroid/view/WindowManager;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000011(Lgtandroid/universal/FloatingService;)Landroid/view/View;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000012(Lgtandroid/universal/FloatingService;)Landroid/widget/LinearLayout;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000013(Lgtandroid/universal/FloatingService;)Landroid/content/SharedPreferences;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    move-object v0, v3

    return-object v0
.end method

.method static access$L1000014(Lgtandroid/universal/FloatingService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/FloatingService;->chatMode:I

    move v0, v3

    return v0
.end method

.method static access$L1000015(Lgtandroid/universal/FloatingService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/FloatingService;->cheatMode:I

    move v0, v3

    return v0
.end method

.method static access$L1000016(Lgtandroid/universal/FloatingService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/FloatingService;->keyboardSize:I

    move v0, v3

    return v0
.end method

.method static access$L1000017(Lgtandroid/universal/FloatingService;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lgtandroid/universal/FloatingService;->keyboardTransparency:I

    move v0, v3

    return v0
.end method

.method static access$L1000022(Lgtandroid/universal/FloatingService;)Z
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-boolean v3, v3, Lgtandroid/universal/FloatingService;->resizingContentScroll:Z

    move v0, v3

    return v0
.end method

.method static access$L1000035(Lgtandroid/universal/FloatingService;)Landroid/os/Handler;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->iconUpdateHandler:Landroid/os/Handler;

    move-object v0, v3

    return-object v0
.end method

.method static access$S1000001(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/FloatingService;->BG_CARD:I

    return-void
.end method

.method static access$S1000002(I)V
    .locals 4

    move v0, p0

    move v3, v0

    sput v3, Lgtandroid/universal/FloatingService;->NEON_CYAN:I

    return-void
.end method

.method static access$S1000010(Lgtandroid/universal/FloatingService;Landroid/view/WindowManager;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    return-void
.end method

.method static access$S1000011(Lgtandroid/universal/FloatingService;Landroid/view/View;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    return-void
.end method

.method static access$S1000012(Lgtandroid/universal/FloatingService;Landroid/widget/LinearLayout;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    return-void
.end method

.method static access$S1000013(Lgtandroid/universal/FloatingService;Landroid/content/SharedPreferences;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    return-void
.end method

.method static access$S1000014(Lgtandroid/universal/FloatingService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/FloatingService;->chatMode:I

    return-void
.end method

.method static access$S1000015(Lgtandroid/universal/FloatingService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/FloatingService;->cheatMode:I

    return-void
.end method

.method static access$S1000016(Lgtandroid/universal/FloatingService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/FloatingService;->keyboardSize:I

    return-void
.end method

.method static access$S1000017(Lgtandroid/universal/FloatingService;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lgtandroid/universal/FloatingService;->keyboardTransparency:I

    return-void
.end method

.method static access$S1000022(Lgtandroid/universal/FloatingService;Z)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput-boolean v5, v4, Lgtandroid/universal/FloatingService;->resizingContentScroll:Z

    return-void
.end method

.method static access$S1000035(Lgtandroid/universal/FloatingService;Landroid/os/Handler;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/FloatingService;->iconUpdateHandler:Landroid/os/Handler;

    return-void
.end method

.method private attachContentScrollAutoFit(Landroid/widget/ScrollView;Landroid/widget/LinearLayout;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/ScrollView;",
            "Landroid/widget/LinearLayout;",
            ")V"
        }
    .end annotation

    .prologue
    .line 109
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v1

    new-instance v5, Lgtandroid/universal/FloatingService$100000000;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    move-object v7, v0

    move-object v8, v1

    move-object v9, v2

    invoke-direct {v6, v7, v8, v9}, Lgtandroid/universal/FloatingService$100000000;-><init>(Lgtandroid/universal/FloatingService;Landroid/widget/ScrollView;Landroid/widget/LinearLayout;)V

    invoke-virtual {v4, v5}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    return-void
.end method

.method private buildFeatureToggleButton(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Landroid/view/View;
    .locals 22

    .prologue
    .line 904
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p4

    const/4 v10, 0x1

    new-array v10, v10, [Z

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    const/4 v12, 0x0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    move-object v14, v2

    move v15, v3

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v13

    aput-boolean v13, v11, v12

    move-object v6, v10

    .line 906
    new-instance v10, Landroid/widget/Button;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v7, v10

    .line 907
    move-object v10, v7

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v21, v11

    move-object/from16 v11, v21

    move-object/from16 v12, v21

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v21, v12

    move-object/from16 v12, v21

    move-object/from16 v13, v21

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    move-object v13, v1

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, ": "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    move-object v12, v6

    const/4 v13, 0x0

    aget-boolean v12, v12, v13

    if-eqz v12, :cond_0

    const-string v12, "\u0412\u043a\u043b"

    :goto_0
    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 908
    move-object v10, v7

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v11

    move-object/from16 v11, v21

    move-object/from16 v12, v21

    const/4 v13, -0x1

    const/4 v14, -0x2

    invoke-direct {v12, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 911
    move-object v10, v7

    const/16 v11, 0xa

    const/16 v12, 0xf

    const/16 v13, 0xa

    const/16 v14, 0xf

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 912
    move-object v10, v7

    const/16 v11, 0xd

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 913
    move-object v10, v7

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 914
    move-object v10, v7

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 915
    move-object v10, v7

    move-object v11, v6

    const/4 v12, 0x0

    aget-boolean v11, v11, v12

    if-eqz v11, :cond_1

    const v11, -0xff5600

    :goto_1
    invoke-virtual {v10, v11}, Landroid/view/View;->setBackgroundColor(I)V

    .line 917
    move-object v10, v7

    new-instance v11, Lgtandroid/universal/FloatingService$100000014;

    move-object/from16 v21, v11

    move-object/from16 v11, v21

    move-object/from16 v12, v21

    move-object v13, v0

    move-object v14, v6

    move-object v15, v2

    move-object/from16 v16, v7

    move-object/from16 v17, v1

    move-object/from16 v18, v4

    invoke-direct/range {v12 .. v18}, Lgtandroid/universal/FloatingService$100000014;-><init>(Lgtandroid/universal/FloatingService;[ZLjava/lang/String;Landroid/widget/Button;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 934
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    const/4 v12, -0x1

    const/4 v13, -0x2

    invoke-direct {v11, v12, v13}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    move-object v8, v10

    .line 936
    move-object v10, v8

    const/4 v11, 0x0

    const/16 v12, 0x8

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    .line 937
    move-object v10, v7

    move-object v11, v8

    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 939
    move-object v10, v7

    move-object v0, v10

    return-object v0

    .line 907
    :cond_0
    const-string v12, "\u0412\u044b\u043a\u043b"

    goto :goto_0

    .line 915
    :cond_1
    const v11, -0x99999a

    goto :goto_1
.end method

.method private closeMenu()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 421
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    if-eqz v2, :cond_0

    .line 422
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 425
    :cond_0
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_1

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    if-eqz v2, :cond_1

    .line 426
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    invoke-interface {v2, v3}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    .line 427
    move-object v2, v0

    const/4 v3, 0x0

    check-cast v3, Landroid/widget/LinearLayout;

    iput-object v3, v2, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    :cond_1
    return-void
.end method

.method private computeMenuContentMaxHeight()I
    .locals 12

    .prologue
    .line 96
    move-object v0, p0

    new-instance v9, Landroid/graphics/Point;

    move-object v11, v9

    move-object v9, v11

    move-object v10, v11

    invoke-direct {v10}, Landroid/graphics/Point;-><init>()V

    move-object v2, v9

    .line 97
    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    invoke-interface {v9}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v9

    move-object v10, v2

    invoke-virtual {v9, v10}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V

    .line 98
    move-object v9, v2

    iget v9, v9, Landroid/graphics/Point;->y:I

    move v3, v9

    .line 99
    move-object v9, v0

    const/16 v10, 0x78

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v9

    move v4, v9

    .line 100
    move v9, v3

    move v10, v4

    sub-int/2addr v9, v10

    move v5, v9

    .line 101
    move v9, v3

    int-to-float v9, v9

    const v10, 0x3f266666    # 0.65f

    mul-float/2addr v9, v10

    float-to-int v9, v9

    move v6, v9

    .line 102
    move v9, v5

    move v10, v6

    invoke-static {v9, v10}, Ljava/lang/Math;->min(II)I

    move-result v9

    move v7, v9

    .line 103
    move-object v9, v0

    const/16 v10, 0x96

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v9

    move v10, v7

    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v9

    move v0, v9

    return v0
.end method

.method private createFloatingIcon()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 180
    move-object v0, p0

    move-object v5, v0

    const/16 v6, 0x28

    int-to-float v6, v6

    invoke-direct {v5, v6}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v5

    move v2, v5

    .line 182
    move-object v5, v0

    new-instance v6, Landroid/widget/ImageButton;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    invoke-direct {v7, v8}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    iput-object v6, v5, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    .line 183
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    check-cast v5, Landroid/widget/ImageButton;

    sget-object v6, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 184
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    check-cast v5, Landroid/widget/ImageButton;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 185
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/FloatingService;->updateIconBackground()V

    .line 187
    new-instance v5, Landroid/view/WindowManager$LayoutParams;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move v7, v2

    move v8, v2

    const/16 v9, 0x7f6

    const/16 v10, 0x8

    const/4 v11, -0x3

    invoke-direct/range {v6 .. v11}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    move-object v3, v5

    .line 193
    move-object v5, v3

    const v6, 0x800033

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 194
    move-object v5, v3

    const/4 v6, 0x0

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 195
    move-object v5, v3

    move-object v6, v0

    const/16 v7, 0x21

    int-to-float v7, v7

    invoke-direct {v6, v7}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v6

    iput v6, v5, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 197
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    move-object v7, v3

    invoke-interface {v5, v6, v7}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 199
    move-object v5, v0

    invoke-direct {v5}, Lgtandroid/universal/FloatingService;->startIconUpdater()V

    .line 201
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    new-instance v6, Lgtandroid/universal/FloatingService$100000003;

    move-object v12, v6

    move-object v6, v12

    move-object v7, v12

    move-object v8, v0

    move-object v9, v3

    move v10, v2

    invoke-direct {v7, v8, v9, v10}, Lgtandroid/universal/FloatingService$100000003;-><init>(Lgtandroid/universal/FloatingService;Landroid/view/WindowManager$LayoutParams;I)V

    invoke-virtual {v5, v6}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void
.end method

.method private createNeonBackground(IF)Landroid/graphics/drawable/Drawable;
    .locals 10

    .prologue
    .line 49
    move-object v0, p0

    move v1, p1

    move v2, p2

    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v4, v6

    .line 50
    move-object v6, v4

    const v7, -0xedebe3

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 51
    move-object v6, v4

    move-object v7, v0

    move v8, v2

    invoke-direct {v7, v8}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 52
    move-object v6, v4

    move-object v7, v0

    const/high16 v8, 0x3fc00000    # 1.5f

    invoke-direct {v7, v8}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v7

    move v8, v1

    invoke-virtual {v6, v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 53
    move-object v6, v4

    move-object v0, v6

    return-object v0
.end method

.method private createNeonTabBackground(IZ)Landroid/graphics/drawable/Drawable;
    .locals 12

    .prologue
    .line 57
    move-object v0, p0

    move v1, p1

    move v2, p2

    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    move-object v4, v6

    .line 58
    move-object v6, v4

    move v7, v2

    if-eqz v7, :cond_0

    move-object v7, v0

    move v8, v1

    const/16 v9, 0x2d

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/FloatingService;->withAlpha(II)I

    move-result v7

    :goto_0
    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 59
    move-object v6, v4

    move-object v7, v0

    const/16 v8, 0xa

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v7

    int-to-float v7, v7

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 60
    move-object v6, v4

    move-object v7, v0

    const/high16 v8, 0x3fc00000    # 1.5f

    invoke-direct {v7, v8}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v7

    move v8, v2

    if-eqz v8, :cond_1

    move v8, v1

    :goto_1
    invoke-virtual {v6, v7, v8}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 61
    move-object v6, v4

    move-object v0, v6

    return-object v0

    .line 58
    :cond_0
    const v7, -0xedebe3

    goto :goto_0

    .line 60
    :cond_1
    const v8, -0xd5d2c6

    goto :goto_1
.end method

.method private dpToPx(F)I
    .locals 6

    .prologue
    .line 91
    move-object v0, p0

    move v1, p1

    const/4 v3, 0x1

    move v4, v1

    move-object v5, v0

    invoke-virtual {v5}, Landroid/content/ContextWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    invoke-static {v3, v4, v5}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v3

    float-to-int v3, v3

    move v0, v3

    return v0
.end method

.method private getCircularBackground(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Landroid/graphics/drawable/Drawable;
    .locals 22

    .prologue
    .line 324
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v5, p4

    const/16 v15, 0x78

    move v7, v15

    .line 325
    move v15, v7

    move/from16 v16, v7

    sget-object v17, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static/range {v15 .. v17}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v15

    move-object v8, v15

    .line 326
    new-instance v15, Landroid/graphics/Canvas;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    move-object/from16 v17, v8

    invoke-direct/range {v16 .. v17}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    move-object v9, v15

    .line 328
    new-instance v15, Landroid/graphics/Paint;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    const/16 v17, 0x1

    invoke-direct/range {v16 .. v17}, Landroid/graphics/Paint;-><init>(I)V

    move-object v10, v15

    .line 329
    move-object v15, v10

    move/from16 v16, v5

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setColor(I)V

    .line 330
    move-object v15, v9

    move/from16 v16, v7

    const/16 v17, 0x2

    div-int/lit8 v16, v16, 0x2

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    move/from16 v17, v7

    const/16 v18, 0x2

    div-int/lit8 v17, v17, 0x2

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    move/from16 v18, v7

    const/16 v19, 0x2

    div-int/lit8 v18, v18, 0x2

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move-object/from16 v19, v10

    invoke-virtual/range {v15 .. v19}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 332
    new-instance v15, Landroid/graphics/Paint;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    const/16 v17, 0x1

    invoke-direct/range {v16 .. v17}, Landroid/graphics/Paint;-><init>(I)V

    move-object v11, v15

    .line 333
    move-object v15, v11

    sget-object v16, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 334
    move-object v15, v11

    const/16 v16, 0x4

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 335
    move-object v15, v11

    const/16 v16, -0x1

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setColor(I)V

    .line 336
    move-object v15, v9

    move/from16 v16, v7

    const/16 v17, 0x2

    div-int/lit8 v16, v16, 0x2

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    move/from16 v17, v7

    const/16 v18, 0x2

    div-int/lit8 v17, v17, 0x2

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    move/from16 v18, v7

    const/16 v19, 0x2

    div-int/lit8 v18, v18, 0x2

    const/16 v19, 0x2

    add-int/lit8 v18, v18, -0x2

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move-object/from16 v19, v11

    invoke-virtual/range {v15 .. v19}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 338
    move-object v15, v4

    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    move-result v15

    if-nez v15, :cond_0

    .line 339
    new-instance v15, Landroid/graphics/Paint;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    const/16 v17, 0x1

    invoke-direct/range {v16 .. v17}, Landroid/graphics/Paint;-><init>(I)V

    move-object v12, v15

    .line 340
    move-object v15, v12

    const/16 v16, -0x1

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setColor(I)V

    .line 341
    move-object v15, v12

    sget-object v16, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 342
    move-object v15, v12

    const/16 v16, 0x12

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 343
    move-object v15, v12

    sget-object v16, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object v15

    .line 344
    move-object v15, v9

    move-object/from16 v16, v4

    move/from16 v17, v7

    const/16 v18, 0x2

    div-int/lit8 v17, v17, 0x2

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    const/16 v18, 0x19

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move-object/from16 v19, v12

    invoke-virtual/range {v15 .. v19}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 347
    :cond_0
    new-instance v15, Landroid/graphics/Paint;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    const/16 v17, 0x1

    invoke-direct/range {v16 .. v17}, Landroid/graphics/Paint;-><init>(I)V

    move-object v12, v15

    .line 348
    move-object v15, v12

    const/16 v16, -0x1

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setColor(I)V

    .line 349
    move-object v15, v12

    sget-object v16, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 350
    move-object v15, v12

    const/16 v16, 0x1a

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 351
    move-object v15, v12

    sget-object v16, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object v15

    .line 352
    move-object v15, v9

    move-object/from16 v16, v2

    move/from16 v17, v7

    const/16 v18, 0x2

    div-int/lit8 v17, v17, 0x2

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    move/from16 v18, v7

    const/16 v19, 0x2

    div-int/lit8 v18, v18, 0x2

    const/16 v19, 0x5

    add-int/lit8 v18, v18, 0x5

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move-object/from16 v19, v12

    invoke-virtual/range {v15 .. v19}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 354
    new-instance v15, Landroid/graphics/Paint;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    const/16 v17, 0x1

    invoke-direct/range {v16 .. v17}, Landroid/graphics/Paint;-><init>(I)V

    move-object v13, v15

    .line 355
    move-object v15, v13

    const/16 v16, -0x1

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setColor(I)V

    .line 356
    move-object v15, v13

    const/16 v16, 0x2

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 357
    move-object v15, v9

    const/16 v16, 0x14

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    move/from16 v17, v7

    const/16 v18, 0x2

    div-int/lit8 v17, v17, 0x2

    const/16 v18, 0xf

    add-int/lit8 v17, v17, 0xf

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    move/from16 v18, v7

    const/16 v19, 0x14

    add-int/lit8 v18, v18, -0x14

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move/from16 v19, v7

    const/16 v20, 0x2

    div-int/lit8 v19, v19, 0x2

    const/16 v20, 0xf

    add-int/lit8 v19, v19, 0xf

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    move-object/from16 v20, v13

    invoke-virtual/range {v15 .. v20}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 359
    move-object v15, v12

    const/16 v16, 0xe

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 360
    move-object v15, v12

    sget-object v16, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object v15

    .line 361
    move-object v15, v9

    const-string v16, "\u0420\u0415\u041f:"

    move/from16 v17, v7

    const/16 v18, 0x2

    div-int/lit8 v17, v17, 0x2

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    move/from16 v18, v7

    const/16 v19, 0x2

    div-int/lit8 v18, v18, 0x2

    const/16 v19, 0x23

    add-int/lit8 v18, v18, 0x23

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move-object/from16 v19, v12

    invoke-virtual/range {v15 .. v19}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 363
    move-object v15, v12

    const/16 v16, 0x14

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 364
    move-object v15, v12

    sget-object v16, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual/range {v15 .. v16}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object v15

    .line 365
    move-object v15, v9

    move-object/from16 v16, v3

    move/from16 v17, v7

    const/16 v18, 0x2

    div-int/lit8 v17, v17, 0x2

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    move/from16 v18, v7

    const/16 v19, 0x2

    div-int/lit8 v18, v18, 0x2

    const/16 v19, 0x37

    add-int/lit8 v18, v18, 0x37

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    move-object/from16 v19, v12

    invoke-virtual/range {v15 .. v19}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    .line 367
    new-instance v15, Landroid/graphics/drawable/BitmapDrawable;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    move-object/from16 v17, v1

    invoke-virtual/range {v17 .. v17}, Landroid/content/ContextWrapper;->getResources()Landroid/content/res/Resources;

    move-result-object v17

    move-object/from16 v18, v8

    invoke-direct/range {v16 .. v18}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    move-object v1, v15

    return-object v1
.end method

.method private openMenu(II)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II)V"
        }
    .end annotation

    .prologue
    .line 391
    move-object v0, p0

    move v1, p1

    move/from16 v2, p2

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    if-eqz v6, :cond_0

    .line 392
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    const/16 v7, 0x8

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    .line 395
    :cond_0
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    if-eqz v6, :cond_1

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    if-eqz v6, :cond_1

    .line 396
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    invoke-interface {v6, v7}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    .line 399
    :cond_1
    move-object v6, v0

    new-instance v7, Landroid/widget/LinearLayout;

    move-object v13, v7

    move-object v7, v13

    move-object v8, v13

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    .line 400
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 401
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    move-object v7, v0

    const v8, -0x57aa01

    const/high16 v9, 0x41800000    # 16.0f

    invoke-direct {v7, v8, v9}, Lgtandroid/universal/FloatingService;->createNeonBackground(IF)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 402
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    move-object v7, v0

    const/4 v8, 0x2

    int-to-float v8, v8

    invoke-direct {v7, v8}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v7

    move-object v8, v0

    const/4 v9, 0x2

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v8

    move-object v9, v0

    const/4 v10, 0x2

    int-to-float v10, v10

    invoke-direct {v9, v10}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v9

    move-object v10, v0

    const/4 v11, 0x2

    int-to-float v11, v11

    invoke-direct {v10, v11}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v10

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 404
    new-instance v6, Landroid/view/WindowManager$LayoutParams;

    move-object v13, v6

    move-object v6, v13

    move-object v7, v13

    const/16 v8, 0x1c2

    const/4 v9, -0x2

    const/16 v10, 0x7f6

    const/16 v11, 0x8

    const/4 v12, -0x3

    invoke-direct/range {v7 .. v12}, Landroid/view/WindowManager$LayoutParams;-><init>(IIIII)V

    move-object v4, v6

    .line 411
    move-object v6, v4

    const v7, 0x800033

    iput v7, v6, Landroid/view/WindowManager$LayoutParams;->gravity:I

    .line 412
    move-object v6, v4

    move v7, v1

    iput v7, v6, Landroid/view/WindowManager$LayoutParams;->x:I

    .line 413
    move-object v6, v4

    move v7, v2

    move-object v8, v0

    const/16 v9, 0x21

    int-to-float v9, v9

    invoke-direct {v8, v9}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v8

    add-int/2addr v7, v8

    iput v7, v6, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 415
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    move-object v8, v4

    invoke-interface {v6, v7, v8}, Landroid/view/WindowManager;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 417
    move-object v6, v0

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    move-object v8, v4

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/FloatingService;->setupMenuContent(Landroid/widget/LinearLayout;Landroid/view/WindowManager$LayoutParams;)V

    return-void
.end method

.method public static resetCheatMode()V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 943
    const/4 v2, 0x0

    sput v2, Lgtandroid/universal/FloatingService;->currentCheatMode:I

    return-void
.end method

.method private setupMenuContent(Landroid/widget/LinearLayout;Landroid/view/WindowManager$LayoutParams;)V
    .locals 24
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            "Landroid/view/WindowManager$LayoutParams;",
            ")V"
        }
    .end annotation

    .prologue
    .line 432
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    new-instance v15, Landroid/widget/LinearLayout;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v5, v15

    .line 433
    move-object v15, v5

    const/16 v16, 0x0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 434
    move-object v15, v5

    const v16, -0xedebe3

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setBackgroundColor(I)V

    .line 435
    move-object v15, v5

    const/16 v16, 0xa

    const/16 v17, 0xa

    const/16 v18, 0xa

    const/16 v19, 0xa

    invoke-virtual/range {v15 .. v19}, Landroid/view/View;->setPadding(IIII)V

    .line 436
    move-object v15, v5

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, -0x1

    const/16 v19, -0x2

    invoke-direct/range {v17 .. v19}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 440
    new-instance v15, Landroid/widget/TextView;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v6, v15

    .line 441
    move-object v15, v6

    const-string v16, "\u2550\u2550\u2550 \u041f\u0415\u0420\u0415\u0422\u0410\u0429\u0418 \u2550\u2550\u2550"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 442
    move-object v15, v6

    const v16, -0xff1a01

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setTextColor(I)V

    .line 443
    move-object v15, v6

    const/16 v16, 0xc

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setTextSize(F)V

    .line 444
    move-object v15, v6

    const/16 v16, 0x11

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setGravity(I)V

    .line 445
    move-object v15, v6

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, -0x1

    const/16 v19, -0x2

    invoke-direct/range {v17 .. v19}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 449
    move-object v15, v5

    move-object/from16 v16, v6

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 450
    move-object v15, v2

    move-object/from16 v16, v5

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 452
    new-instance v15, Landroid/widget/LinearLayout;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v7, v15

    .line 453
    move-object v15, v7

    const/16 v16, 0x0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 454
    move-object v15, v7

    const v16, -0xf5f3ee

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setBackgroundColor(I)V

    .line 455
    move-object v15, v7

    move-object/from16 v16, v1

    const/16 v17, 0x4

    move/from16 v0, v17

    int-to-float v0, v0

    move/from16 v17, v0

    invoke-direct/range {v16 .. v17}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v16

    move-object/from16 v17, v1

    const/16 v18, 0x4

    move/from16 v0, v18

    int-to-float v0, v0

    move/from16 v18, v0

    invoke-direct/range {v17 .. v18}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v17

    move-object/from16 v18, v1

    const/16 v19, 0x4

    move/from16 v0, v19

    int-to-float v0, v0

    move/from16 v19, v0

    invoke-direct/range {v18 .. v19}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v18

    move-object/from16 v19, v1

    const/16 v20, 0x4

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v19

    invoke-virtual/range {v15 .. v19}, Landroid/view/View;->setPadding(IIII)V

    .line 456
    move-object v15, v7

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, -0x1

    const/16 v19, -0x2

    invoke-direct/range {v17 .. v19}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 460
    new-instance v15, Landroid/widget/Button;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v8, v15

    .line 461
    move-object v15, v8

    const-string v16, "\ud83d\udcac \u0427\u0430\u0442"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 462
    move-object v15, v8

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, 0x0

    move-object/from16 v19, v1

    const/16 v20, 0x3c

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v19

    const/16 v20, 0x1

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v17 .. v20}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 463
    move-object v15, v8

    const/16 v16, 0xc

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setTextSize(F)V

    .line 464
    move-object v15, v8

    const/16 v16, 0x0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 466
    new-instance v15, Landroid/widget/Button;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v9, v15

    .line 467
    move-object v15, v9

    const-string v16, "\ud83c\udfae \u0427\u0438\u0442\u044b"

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 468
    move-object v15, v9

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, 0x0

    move-object/from16 v19, v1

    const/16 v20, 0x3c

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v19

    const/16 v20, 0x1

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v17 .. v20}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 469
    move-object v15, v9

    const/16 v16, 0xc

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setTextSize(F)V

    .line 470
    move-object v15, v9

    const/16 v16, 0x0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 472
    new-instance v15, Landroid/widget/Button;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    move-object v10, v15

    .line 473
    move-object v15, v10

    const-string v16, "\u2699\ufe0f \u041d\u0430\u0441\u0442\u0440."

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 474
    move-object v15, v10

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, 0x0

    move-object/from16 v19, v1

    const/16 v20, 0x3c

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v19 .. v20}, Lgtandroid/universal/FloatingService;->dpToPx(F)I

    move-result v19

    const/16 v20, 0x1

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-direct/range {v17 .. v20}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 475
    move-object v15, v10

    const/16 v16, 0xc

    move/from16 v0, v16

    int-to-float v0, v0

    move/from16 v16, v0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setTextSize(F)V

    .line 476
    move-object v15, v10

    const/16 v16, 0x0

    invoke-virtual/range {v15 .. v16}, Landroid/widget/TextView;->setAllCaps(Z)V

    .line 478
    move-object v15, v1

    move-object/from16 v16, v8

    const/16 v17, 0x1

    invoke-direct/range {v15 .. v17}, Lgtandroid/universal/FloatingService;->styleTab(Landroid/widget/Button;Z)V

    .line 479
    move-object v15, v1

    move-object/from16 v16, v9

    const/16 v17, 0x0

    invoke-direct/range {v15 .. v17}, Lgtandroid/universal/FloatingService;->styleTab(Landroid/widget/Button;Z)V

    .line 480
    move-object v15, v1

    move-object/from16 v16, v10

    const/16 v17, 0x0

    invoke-direct/range {v15 .. v17}, Lgtandroid/universal/FloatingService;->styleTab(Landroid/widget/Button;Z)V

    .line 482
    move-object v15, v7

    move-object/from16 v16, v8

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 483
    move-object v15, v7

    move-object/from16 v16, v9

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 484
    move-object v15, v7

    move-object/from16 v16, v10

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 485
    move-object v15, v2

    move-object/from16 v16, v7

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 487
    new-instance v15, Landroid/widget/LinearLayout;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    move-object v11, v15

    .line 488
    move-object v15, v11

    const/16 v16, 0x1

    invoke-virtual/range {v15 .. v16}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 489
    move-object v15, v11

    const/16 v16, 0x14

    const/16 v17, 0x14

    const/16 v18, 0x14

    const/16 v19, 0x14

    invoke-virtual/range {v15 .. v19}, Landroid/view/View;->setPadding(IIII)V

    .line 490
    move-object v15, v11

    const v16, -0xf5f3ee

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setBackgroundColor(I)V

    .line 491
    move-object v15, v11

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, -0x1

    const/16 v19, -0x2

    invoke-direct/range {v17 .. v19}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 494
    new-instance v15, Landroid/widget/ScrollView;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    move-object v12, v15

    .line 495
    move-object v15, v12

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, -0x1

    const/16 v19, -0x2

    invoke-direct/range {v17 .. v19}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 497
    move-object v15, v12

    const/16 v16, 0x1

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    .line 498
    move-object v15, v12

    move-object/from16 v16, v11

    invoke-virtual/range {v15 .. v16}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 499
    move-object v15, v2

    move-object/from16 v16, v12

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 500
    move-object v15, v1

    move-object/from16 v16, v12

    move-object/from16 v17, v11

    invoke-direct/range {v15 .. v17}, Lgtandroid/universal/FloatingService;->attachContentScrollAutoFit(Landroid/widget/ScrollView;Landroid/widget/LinearLayout;)V

    .line 502
    new-instance v15, Landroid/widget/ImageButton;

    move-object/from16 v23, v15

    move-object/from16 v15, v23

    move-object/from16 v16, v23

    move-object/from16 v17, v1

    invoke-direct/range {v16 .. v17}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;)V

    move-object v13, v15

    .line 503
    move-object v15, v13

    const v16, 0x1080038

    invoke-virtual/range {v15 .. v16}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 504
    move-object v15, v13

    const v16, -0xb293

    invoke-virtual/range {v15 .. v16}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 505
    move-object v15, v13

    move-object/from16 v16, v1

    const v17, -0xb293

    const/16 v18, 0x0

    invoke-direct/range {v16 .. v18}, Lgtandroid/universal/FloatingService;->createNeonBackground(IF)Landroid/graphics/drawable/Drawable;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 506
    move-object v15, v13

    new-instance v16, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    const/16 v18, -0x1

    const/16 v19, 0x32

    invoke-direct/range {v17 .. v19}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 508
    move-object v15, v13

    new-instance v16, Lgtandroid/universal/FloatingService$100000005;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    move-object/from16 v18, v1

    invoke-direct/range {v17 .. v18}, Lgtandroid/universal/FloatingService$100000005;-><init>(Lgtandroid/universal/FloatingService;)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 514
    move-object v15, v2

    move-object/from16 v16, v13

    invoke-virtual/range {v15 .. v16}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 516
    move-object v15, v1

    move-object/from16 v16, v11

    invoke-direct/range {v15 .. v16}, Lgtandroid/universal/FloatingService;->showChatModeTab(Landroid/widget/LinearLayout;)V

    .line 518
    move-object v15, v8

    new-instance v16, Lgtandroid/universal/FloatingService$100000006;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    move-object/from16 v18, v1

    move-object/from16 v19, v8

    move-object/from16 v20, v9

    move-object/from16 v21, v10

    move-object/from16 v22, v11

    invoke-direct/range {v17 .. v22}, Lgtandroid/universal/FloatingService$100000006;-><init>(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/LinearLayout;)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 528
    move-object v15, v9

    new-instance v16, Lgtandroid/universal/FloatingService$100000007;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    move-object/from16 v18, v1

    move-object/from16 v19, v8

    move-object/from16 v20, v9

    move-object/from16 v21, v10

    move-object/from16 v22, v11

    invoke-direct/range {v17 .. v22}, Lgtandroid/universal/FloatingService$100000007;-><init>(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/LinearLayout;)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 538
    move-object v15, v10

    new-instance v16, Lgtandroid/universal/FloatingService$100000008;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    move-object/from16 v18, v1

    move-object/from16 v19, v8

    move-object/from16 v20, v9

    move-object/from16 v21, v10

    move-object/from16 v22, v11

    invoke-direct/range {v17 .. v22}, Lgtandroid/universal/FloatingService$100000008;-><init>(Lgtandroid/universal/FloatingService;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/Button;Landroid/widget/LinearLayout;)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 548
    move-object v15, v5

    new-instance v16, Lgtandroid/universal/FloatingService$100000009;

    move-object/from16 v23, v16

    move-object/from16 v16, v23

    move-object/from16 v17, v23

    move-object/from16 v18, v1

    move-object/from16 v19, v3

    move-object/from16 v20, v5

    invoke-direct/range {v17 .. v20}, Lgtandroid/universal/FloatingService$100000009;-><init>(Lgtandroid/universal/FloatingService;Landroid/view/WindowManager$LayoutParams;Landroid/widget/LinearLayout;)V

    invoke-virtual/range {v15 .. v16}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void
.end method

.method private showChatModeTab(Landroid/widget/LinearLayout;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            ")V"
        }
    .end annotation

    .prologue
    .line 593
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v10, v1

    invoke-virtual {v10}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 595
    new-instance v10, Landroid/widget/TextView;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v10

    .line 596
    move-object v10, v3

    const-string v11, "\u0420\u0415\u0416\u0418\u041c \u0427\u0410\u0422\u0410"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 597
    move-object v10, v3

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 598
    move-object v10, v3

    const/16 v11, 0x10

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 599
    move-object v10, v3

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 600
    move-object v10, v3

    const/4 v11, 0x0

    const/16 v12, 0xa

    const/4 v13, 0x0

    const/16 v14, 0x14

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 601
    move-object v10, v3

    const/4 v11, 0x0

    check-cast v11, Landroid/graphics/Typeface;

    const/4 v12, 0x1

    invoke-virtual {v10, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 602
    move-object v10, v1

    move-object v11, v3

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 604
    new-instance v10, Landroid/widget/RadioGroup;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/RadioGroup;-><init>(Landroid/content/Context;)V

    move-object v4, v10

    .line 605
    move-object v10, v4

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 606
    move-object v10, v4

    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    const/4 v13, -0x1

    const/4 v14, -0x2

    invoke-direct {v12, v13, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v10, v11}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 610
    new-instance v10, Landroid/widget/RadioButton;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    move-object v5, v10

    .line 611
    move-object v10, v5

    const-string v11, "\ud83d\udce2 \u0410\u0434\u043c\u0438\u043d \u0447\u0430\u0442 (/a)"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 612
    move-object v10, v5

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 613
    move-object v10, v5

    const/16 v11, 0xf

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 614
    move-object v10, v5

    const/16 v11, 0x14

    const/16 v12, 0xc

    const/16 v13, 0x14

    const/16 v14, 0xc

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 615
    move-object v10, v5

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/view/View;->setId(I)V

    .line 617
    new-instance v10, Landroid/widget/RadioButton;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    move-object v6, v10

    .line 618
    move-object v10, v6

    const-string v11, "\ud83d\udcac \u041d\u043e\u043d \u0420\u041f \u0447\u0430\u0442 (/n)"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 619
    move-object v10, v6

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 620
    move-object v10, v6

    const/16 v11, 0xf

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 621
    move-object v10, v6

    const/16 v11, 0x14

    const/16 v12, 0xc

    const/16 v13, 0x14

    const/16 v14, 0xc

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 622
    move-object v10, v6

    const/4 v11, 0x2

    invoke-virtual {v10, v11}, Landroid/view/View;->setId(I)V

    .line 624
    new-instance v10, Landroid/widget/RadioButton;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    move-object v7, v10

    .line 625
    move-object v10, v7

    const-string v11, "\u26aa \u041e\u0431\u044b\u0447\u043d\u044b\u0439 \u0440\u0435\u0436\u0438\u043c"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 626
    move-object v10, v7

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 627
    move-object v10, v7

    const/16 v11, 0xf

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 628
    move-object v10, v7

    const/16 v11, 0x14

    const/16 v12, 0xc

    const/16 v13, 0x14

    const/16 v14, 0xc

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 629
    move-object v10, v7

    const/4 v11, 0x0

    invoke-virtual {v10, v11}, Landroid/view/View;->setId(I)V

    .line 631
    move-object v10, v4

    move-object v11, v5

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 632
    move-object v10, v4

    move-object v11, v6

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 633
    move-object v10, v4

    move-object v11, v7

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 635
    move-object v10, v0

    iget v10, v10, Lgtandroid/universal/FloatingService;->chatMode:I

    packed-switch v10, :pswitch_data_0

    .line 638
    move-object v10, v7

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 641
    :goto_0
    move-object v10, v4

    new-instance v11, Lgtandroid/universal/FloatingService$100000010;

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    move-object v13, v0

    invoke-direct {v12, v13}, Lgtandroid/universal/FloatingService$100000010;-><init>(Lgtandroid/universal/FloatingService;)V

    invoke-virtual {v10, v11}, Landroid/widget/RadioGroup;->setOnCheckedChangeListener(Landroid/widget/RadioGroup$OnCheckedChangeListener;)V

    .line 662
    move-object v10, v1

    move-object v11, v4

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 664
    new-instance v10, Landroid/widget/TextView;

    move-object v15, v10

    move-object v10, v15

    move-object v11, v15

    move-object v12, v0

    invoke-direct {v11, v12}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v8, v10

    .line 665
    move-object v10, v8

    const-string v11, "\u0420\u0435\u0436\u0438\u043c \u0447\u0430\u0442\u0430 \u043d\u0435 \u0441\u0431\u0440\u0430\u0441\u044b\u0432\u0430\u0435\u0442\u0441\u044f \u043f\u043e\u0441\u043b\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438"

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 666
    move-object v10, v8

    const v11, -0x655f4c

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    .line 667
    move-object v10, v8

    const/16 v11, 0xb

    int-to-float v11, v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 668
    move-object v10, v8

    const/16 v11, 0x11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setGravity(I)V

    .line 669
    move-object v10, v8

    const/16 v11, 0xa

    const/16 v12, 0x14

    const/16 v13, 0xa

    const/16 v14, 0xa

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 670
    move-object v10, v1

    move-object v11, v8

    invoke-virtual {v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void

    .line 636
    :pswitch_0
    move-object v10, v5

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_0

    .line 637
    :pswitch_1
    move-object v10, v6

    const/4 v11, 0x1

    invoke-virtual {v10, v11}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_0

    .line 635
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private showCheatsTab(Landroid/widget/LinearLayout;)V
    .locals 17
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            ")V"
        }
    .end annotation

    .prologue
    .line 674
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v11, v1

    invoke-virtual {v11}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 676
    new-instance v11, Landroid/widget/TextView;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v3, v11

    .line 677
    move-object v11, v3

    const-string v12, "\u0427\u0418\u0422\u042b"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 678
    move-object v11, v3

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 679
    move-object v11, v3

    const/16 v12, 0x10

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 680
    move-object v11, v3

    const/16 v12, 0x11

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 681
    move-object v11, v3

    const/4 v12, 0x0

    const/16 v13, 0xa

    const/4 v14, 0x0

    const/16 v15, 0x14

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 682
    move-object v11, v3

    const/4 v12, 0x0

    check-cast v12, Landroid/graphics/Typeface;

    const/4 v13, 0x1

    invoke-virtual {v11, v12, v13}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 683
    move-object v11, v1

    move-object v12, v3

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 685
    new-instance v11, Landroid/widget/RadioGroup;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/RadioGroup;-><init>(Landroid/content/Context;)V

    move-object v4, v11

    .line 686
    move-object v11, v4

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 687
    move-object v11, v4

    new-instance v12, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    const/4 v14, -0x1

    const/4 v15, -0x2

    invoke-direct {v13, v14, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v12}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 691
    new-instance v11, Landroid/widget/RadioButton;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    move-object v5, v11

    .line 692
    move-object v11, v5

    const-string v12, "\ud83d\udee1\ufe0f \u0411\u0435\u0441\u0441\u043c\u0435\u0440\u0442\u0438\u0435 (/gm)"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 693
    move-object v11, v5

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 694
    move-object v11, v5

    const/16 v12, 0xf

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 695
    move-object v11, v5

    const/16 v12, 0x14

    const/16 v13, 0xc

    const/16 v14, 0x14

    const/16 v15, 0xc

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 696
    move-object v11, v5

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/view/View;->setId(I)V

    .line 698
    new-instance v11, Landroid/widget/RadioButton;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    move-object v6, v11

    .line 699
    move-object v11, v6

    const-string v12, "\ud83d\ude97 ID \u0422\u0421 (/dl)"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 700
    move-object v11, v6

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 701
    move-object v11, v6

    const/16 v12, 0xf

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 702
    move-object v11, v6

    const/16 v12, 0x14

    const/16 v13, 0xc

    const/16 v14, 0x14

    const/16 v15, 0xc

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 703
    move-object v11, v6

    const/4 v12, 0x2

    invoke-virtual {v11, v12}, Landroid/view/View;->setId(I)V

    .line 705
    new-instance v11, Landroid/widget/RadioButton;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    move-object v7, v11

    .line 706
    move-object v11, v7

    const-string v12, "\ud83c\udfad \u041c\u0430\u0441\u043a\u0430 (/clist)"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 707
    move-object v11, v7

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 708
    move-object v11, v7

    const/16 v12, 0xf

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 709
    move-object v11, v7

    const/16 v12, 0x14

    const/16 v13, 0xc

    const/16 v14, 0x14

    const/16 v15, 0xc

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 710
    move-object v11, v7

    const/4 v12, 0x3

    invoke-virtual {v11, v12}, Landroid/view/View;->setId(I)V

    .line 712
    new-instance v11, Landroid/widget/RadioButton;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/RadioButton;-><init>(Landroid/content/Context;)V

    move-object v8, v11

    .line 713
    move-object v11, v8

    const-string v12, "\u26aa \u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0447\u0438\u0442\u044b"

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 714
    move-object v11, v8

    const/4 v12, -0x1

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 715
    move-object v11, v8

    const/16 v12, 0xf

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 716
    move-object v11, v8

    const/16 v12, 0x14

    const/16 v13, 0xc

    const/16 v14, 0x14

    const/16 v15, 0xc

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 717
    move-object v11, v8

    const/4 v12, 0x0

    invoke-virtual {v11, v12}, Landroid/view/View;->setId(I)V

    .line 719
    move-object v11, v4

    move-object v12, v5

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 720
    move-object v11, v4

    move-object v12, v6

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 721
    move-object v11, v4

    move-object v12, v7

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 722
    move-object v11, v4

    move-object v12, v8

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 724
    move-object v11, v0

    iget v11, v11, Lgtandroid/universal/FloatingService;->cheatMode:I

    packed-switch v11, :pswitch_data_0

    .line 728
    move-object v11, v8

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/widget/CompoundButton;->setChecked(Z)V

    .line 731
    :goto_0
    move-object v11, v4

    new-instance v12, Lgtandroid/universal/FloatingService$100000011;

    move-object/from16 v16, v12

    move-object/from16 v12, v16

    move-object/from16 v13, v16

    move-object v14, v0

    invoke-direct {v13, v14}, Lgtandroid/universal/FloatingService$100000011;-><init>(Lgtandroid/universal/FloatingService;)V

    invoke-virtual {v11, v12}, Landroid/widget/RadioGroup;->setOnCheckedChangeListener(Landroid/widget/RadioGroup$OnCheckedChangeListener;)V

    .line 755
    move-object v11, v1

    move-object v12, v4

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 757
    new-instance v11, Landroid/widget/TextView;

    move-object/from16 v16, v11

    move-object/from16 v11, v16

    move-object/from16 v12, v16

    move-object v13, v0

    invoke-direct {v12, v13}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object v9, v11

    .line 758
    move-object v11, v9

    const-string v12, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0447\u0438\u0442, \u0437\u0430\u0442\u0435\u043c \u043d\u0430\u0436\u043c\u0438\u0442\u0435 Enter \u043d\u0430 \u043f\u0443\u0441\u0442\u043e\u043c \u043f\u043e\u043b\u0435.\n\u041f\u043e\u0441\u043b\u0435 \u043e\u0442\u043f\u0440\u0430\u0432\u043a\u0438 \u0447\u0438\u0442 \u0430\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0441\u0431\u0440\u043e\u0441\u0438\u0442\u0441\u044f."

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 759
    move-object v11, v9

    const v12, -0x655f4c

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 760
    move-object v11, v9

    const/16 v12, 0xb

    int-to-float v12, v12

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setTextSize(F)V

    .line 761
    move-object v11, v9

    const/16 v12, 0x11

    invoke-virtual {v11, v12}, Landroid/widget/TextView;->setGravity(I)V

    .line 762
    move-object v11, v9

    const/16 v12, 0xa

    const/16 v13, 0x14

    const/16 v14, 0xa

    const/16 v15, 0xa

    invoke-virtual {v11, v12, v13, v14, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 763
    move-object v11, v1

    move-object v12, v9

    invoke-virtual {v11, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void

    .line 725
    :pswitch_0
    move-object v11, v5

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_0

    .line 726
    :pswitch_1
    move-object v11, v6

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_0

    .line 727
    :pswitch_2
    move-object v11, v7

    const/4 v12, 0x1

    invoke-virtual {v11, v12}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_0

    .line 724
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch
.end method

.method private showSettingsTab(Landroid/widget/LinearLayout;)V
    .locals 27
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/LinearLayout;",
            ")V"
        }
    .end annotation

    .prologue
    .line 767
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object/from16 v19, v3

    invoke-virtual/range {v19 .. v19}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 769
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v5, v19

    .line 770
    move-object/from16 v19, v5

    const-string v20, "\u041d\u0410\u0421\u0422\u0420\u041e\u0419\u041a\u0418"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 771
    move-object/from16 v19, v5

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 772
    move-object/from16 v19, v5

    const/16 v20, 0x10

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 773
    move-object/from16 v19, v5

    const/16 v20, 0x11

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setGravity(I)V

    .line 774
    move-object/from16 v19, v5

    const/16 v20, 0x0

    const/16 v21, 0xa

    const/16 v22, 0x0

    const/16 v23, 0x14

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 775
    move-object/from16 v19, v5

    const/16 v20, 0x0

    check-cast v20, Landroid/graphics/Typeface;

    const/16 v21, 0x1

    invoke-virtual/range {v19 .. v21}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 776
    move-object/from16 v19, v3

    move-object/from16 v20, v5

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 778
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v6, v19

    .line 779
    move-object/from16 v19, v6

    const-string v20, "\ud83d\udccf \u0420\u0430\u0437\u043c\u0435\u0440 \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u044b"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 780
    move-object/from16 v19, v6

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 781
    move-object/from16 v19, v6

    const/16 v20, 0xe

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 782
    move-object/from16 v19, v6

    const/16 v20, 0x0

    const/16 v21, 0xa

    const/16 v22, 0x0

    const/16 v23, 0x5

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 783
    move-object/from16 v19, v3

    move-object/from16 v20, v6

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 785
    const/16 v19, 0x8

    move/from16 v0, v19

    new-array v0, v0, [Ljava/lang/String;

    move-object/from16 v19, v0

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x0

    const-string v22, "50%"

    aput-object v22, v20, v21

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x1

    const-string v22, "80%"

    aput-object v22, v20, v21

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x2

    const-string v22, "100%"

    aput-object v22, v20, v21

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x3

    const-string v22, "120%"

    aput-object v22, v20, v21

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x4

    const-string v22, "140%"

    aput-object v22, v20, v21

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x5

    const-string v22, "160%"

    aput-object v22, v20, v21

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x6

    const-string v22, "180%"

    aput-object v22, v20, v21

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    const/16 v21, 0x7

    const-string v22, "200%"

    aput-object v22, v20, v21

    move-object/from16 v7, v19

    .line 786
    const/16 v19, 0x8

    move/from16 v0, v19

    new-array v0, v0, [I

    move-object/from16 v19, v0

    fill-array-data v19, :array_0

    move-object/from16 v8, v19

    .line 787
    const/16 v19, 0x2

    move/from16 v9, v19

    .line 788
    const/16 v19, 0x0

    move/from16 v10, v19

    :goto_0
    move/from16 v19, v10

    move-object/from16 v20, v8

    move-object/from16 v0, v20

    array-length v0, v0

    move/from16 v20, v0

    move/from16 v0, v19

    move/from16 v1, v20

    if-lt v0, v1, :cond_0

    .line 791
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v10, v19

    .line 792
    move-object/from16 v19, v10

    move-object/from16 v20, v7

    move/from16 v21, v9

    aget-object v20, v20, v21

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 793
    move-object/from16 v19, v10

    const v20, -0xff5501

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 794
    move-object/from16 v19, v10

    const/16 v20, 0xe

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 795
    move-object/from16 v19, v10

    const/16 v20, 0x11

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setGravity(I)V

    .line 796
    move-object/from16 v19, v10

    const/16 v20, 0x0

    const/16 v21, 0x5

    const/16 v22, 0x0

    const/16 v23, 0x5

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 797
    move-object/from16 v19, v3

    move-object/from16 v20, v10

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 799
    new-instance v19, Landroid/widget/SeekBar;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    move-object/from16 v11, v19

    .line 800
    move-object/from16 v19, v11

    move-object/from16 v20, v7

    move-object/from16 v0, v20

    array-length v0, v0

    move/from16 v20, v0

    const/16 v21, 0x1

    add-int/lit8 v20, v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/AbsSeekBar;->setMax(I)V

    .line 801
    move-object/from16 v19, v11

    move/from16 v20, v9

    invoke-virtual/range {v19 .. v20}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 802
    move-object/from16 v19, v11

    const/16 v20, 0xa

    const/16 v21, 0x5

    const/16 v22, 0xa

    const/16 v23, 0x5

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 803
    move-object/from16 v19, v3

    move-object/from16 v20, v11

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 805
    move-object/from16 v19, v11

    new-instance v20, Lgtandroid/universal/FloatingService$100000012;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    move-object/from16 v23, v10

    move-object/from16 v24, v7

    move-object/from16 v25, v8

    invoke-direct/range {v21 .. v25}, Lgtandroid/universal/FloatingService$100000012;-><init>(Lgtandroid/universal/FloatingService;Landroid/widget/TextView;[Ljava/lang/String;[I)V

    invoke-virtual/range {v19 .. v20}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 825
    new-instance v19, Landroid/view/View;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v12, v19

    .line 826
    move-object/from16 v19, v12

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, -0x1

    const/16 v23, 0x1

    invoke-direct/range {v21 .. v23}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 828
    move-object/from16 v19, v12

    const v20, -0x99999a

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setBackgroundColor(I)V

    .line 829
    move-object/from16 v19, v3

    move-object/from16 v20, v12

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 831
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v13, v19

    .line 832
    move-object/from16 v19, v13

    const-string v20, "\ud83c\udfa8 \u041f\u0440\u043e\u0437\u0440\u0430\u0447\u043d\u043e\u0441\u0442\u044c \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u044b"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 833
    move-object/from16 v19, v13

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 834
    move-object/from16 v19, v13

    const/16 v20, 0xe

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 835
    move-object/from16 v19, v13

    const/16 v20, 0x0

    const/16 v21, 0xf

    const/16 v22, 0x0

    const/16 v23, 0x5

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 836
    move-object/from16 v19, v3

    move-object/from16 v20, v13

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 838
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v14, v19

    .line 839
    move-object/from16 v19, v14

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v21, v2

    move-object/from16 v0, v21

    iget v0, v0, Lgtandroid/universal/FloatingService;->keyboardTransparency:I

    move/from16 v21, v0

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v20

    const-string v21, "%"

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 840
    move-object/from16 v19, v14

    const v20, -0xff5501

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 841
    move-object/from16 v19, v14

    const/16 v20, 0xe

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 842
    move-object/from16 v19, v14

    const/16 v20, 0x11

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setGravity(I)V

    .line 843
    move-object/from16 v19, v14

    const/16 v20, 0x0

    const/16 v21, 0x5

    const/16 v22, 0x0

    const/16 v23, 0x5

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 844
    move-object/from16 v19, v3

    move-object/from16 v20, v14

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 846
    new-instance v19, Landroid/widget/SeekBar;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    move-object/from16 v15, v19

    .line 847
    move-object/from16 v19, v15

    const/16 v20, 0x64

    invoke-virtual/range {v19 .. v20}, Landroid/widget/AbsSeekBar;->setMax(I)V

    .line 848
    move-object/from16 v19, v15

    move-object/from16 v20, v2

    move-object/from16 v0, v20

    iget v0, v0, Lgtandroid/universal/FloatingService;->keyboardTransparency:I

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/ProgressBar;->setProgress(I)V

    .line 849
    move-object/from16 v19, v15

    const/16 v20, 0xa

    const/16 v21, 0x5

    const/16 v22, 0xa

    const/16 v23, 0x5

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 850
    move-object/from16 v19, v3

    move-object/from16 v20, v15

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 852
    move-object/from16 v19, v15

    new-instance v20, Lgtandroid/universal/FloatingService$100000013;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    move-object/from16 v22, v2

    move-object/from16 v23, v14

    invoke-direct/range {v21 .. v23}, Lgtandroid/universal/FloatingService$100000013;-><init>(Lgtandroid/universal/FloatingService;Landroid/widget/TextView;)V

    invoke-virtual/range {v19 .. v20}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 872
    new-instance v19, Landroid/view/View;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object/from16 v16, v19

    .line 873
    move-object/from16 v19, v16

    new-instance v20, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v26, v20

    move-object/from16 v20, v26

    move-object/from16 v21, v26

    const/16 v22, -0x1

    const/16 v23, 0x1

    invoke-direct/range {v21 .. v23}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 875
    move-object/from16 v19, v16

    const v20, -0x99999a

    invoke-virtual/range {v19 .. v20}, Landroid/view/View;->setBackgroundColor(I)V

    .line 876
    move-object/from16 v19, v16

    const/16 v20, 0x0

    const/16 v21, 0xa

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-virtual/range {v19 .. v23}, Landroid/view/View;->setPadding(IIII)V

    .line 877
    move-object/from16 v19, v3

    move-object/from16 v20, v16

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 879
    new-instance v19, Landroid/widget/TextView;

    move-object/from16 v26, v19

    move-object/from16 v19, v26

    move-object/from16 v20, v26

    move-object/from16 v21, v2

    invoke-direct/range {v20 .. v21}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    move-object/from16 v17, v19

    .line 880
    move-object/from16 v19, v17

    const-string v20, "\ud83d\udd27 \u0424\u0443\u043d\u043a\u0446\u0438\u0438"

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 881
    move-object/from16 v19, v17

    const/16 v20, -0x1

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextColor(I)V

    .line 882
    move-object/from16 v19, v17

    const/16 v20, 0xe

    move/from16 v0, v20

    int-to-float v0, v0

    move/from16 v20, v0

    invoke-virtual/range {v19 .. v20}, Landroid/widget/TextView;->setTextSize(F)V

    .line 883
    move-object/from16 v19, v17

    const/16 v20, 0x0

    const/16 v21, 0xf

    const/16 v22, 0x0

    const/16 v23, 0x5

    invoke-virtual/range {v19 .. v23}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 884
    move-object/from16 v19, v3

    move-object/from16 v20, v17

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 886
    move-object/from16 v19, v3

    move-object/from16 v20, v2

    const-string v21, "\ud83d\udccb \u0410\u0432\u0442\u043e\u0440\u0435\u043f\u043e\u0440\u0442"

    const-string v22, "floating_menu_enabled"

    const/16 v23, 0x0

    const-string v24, "floatingmenu"

    invoke-direct/range {v20 .. v24}, Lgtandroid/universal/FloatingService;->buildFeatureToggleButton(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Landroid/view/View;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 889
    move-object/from16 v19, v3

    move-object/from16 v20, v2

    const-string v21, "\ud83e\udd16 \u0410\u0432\u0442\u043e\u0444\u043e\u0440\u043c\u0430"

    const-string v22, "auto_form_enabled"

    const/16 v23, 0x1

    const-string v24, "autoform"

    invoke-direct/range {v20 .. v24}, Lgtandroid/universal/FloatingService;->buildFeatureToggleButton(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Landroid/view/View;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 892
    move-object/from16 v19, v3

    move-object/from16 v20, v2

    const-string v21, "\ud83c\udd98 \u041f\u043e\u043c\u043e\u0449\u044c \u0438\u0433\u0440\u043e\u043a\u0443"

    const-string v22, "help_player_enabled"

    const/16 v23, 0x1

    const-string v24, "helpplayer"

    invoke-direct/range {v20 .. v24}, Lgtandroid/universal/FloatingService;->buildFeatureToggleButton(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Landroid/view/View;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 895
    move-object/from16 v19, v3

    move-object/from16 v20, v2

    const-string v21, "\u26a1 \u0422\u0440\u0438\u0433\u0433\u0435\u0440\u044b"

    const-string v22, "triggers_enabled"

    const/16 v23, 0x1

    const/16 v24, 0x0

    check-cast v24, Ljava/lang/String;

    invoke-direct/range {v20 .. v24}, Lgtandroid/universal/FloatingService;->buildFeatureToggleButton(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Landroid/view/View;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 898
    move-object/from16 v19, v3

    move-object/from16 v20, v2

    const-string v21, "\ud83d\udfe2 \u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u043d\u0430 \u043e\u0442\u0432\u0435\u0447\u0435\u043d\u043d\u044b\u0435"

    const-string v22, "trigger_on_answered"

    const/16 v23, 0x0

    const/16 v24, 0x0

    check-cast v24, Ljava/lang/String;

    invoke-direct/range {v20 .. v24}, Lgtandroid/universal/FloatingService;->buildFeatureToggleButton(Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;)Landroid/view/View;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    return-void

    .line 789
    :cond_0
    move-object/from16 v19, v8

    move/from16 v20, v10

    aget v19, v19, v20

    move-object/from16 v20, v2

    move-object/from16 v0, v20

    iget v0, v0, Lgtandroid/universal/FloatingService;->keyboardSize:I

    move/from16 v20, v0

    move/from16 v0, v19

    move/from16 v1, v20

    if-ne v0, v1, :cond_1

    move/from16 v19, v10

    move/from16 v9, v19

    .line 788
    :cond_1
    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_0

    .line 786
    :array_0
    .array-data 4
        0x7
        0x0
        0x1
        0x2
        0x3
        0x4
        0x5
        0x6
    .end array-data
.end method

.method private startIconUpdater()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 278
    move-object v0, p0

    move-object v2, v0

    new-instance v3, Lgtandroid/universal/FloatingService$100000004;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/FloatingService$100000004;-><init>(Lgtandroid/universal/FloatingService;)V

    iput-object v3, v2, Lgtandroid/universal/FloatingService;->iconUpdateRunnable:Ljava/lang/Runnable;

    .line 285
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->iconUpdateHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->iconUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    move-result v2

    return-void
.end method

.method private styleTab(Landroid/widget/Button;Z)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/Button;",
            "Z)V"
        }
    .end annotation

    .prologue
    .line 65
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v4, v1

    move-object v5, v0

    const v6, -0xff1a01

    move v7, v2

    invoke-direct {v5, v6, v7}, Lgtandroid/universal/FloatingService;->createNeonTabBackground(IZ)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 66
    move-object v4, v1

    move v5, v2

    if-eqz v5, :cond_0

    const v5, -0xff1a01

    :goto_0
    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    return-void

    :cond_0
    const v5, -0x655f4c

    goto :goto_0
.end method

.method private updateIconBackground()V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 254
    move-object v0, p0

    const-string v5, ""

    move-object v2, v5

    .line 255
    const-string v5, "#0066CC"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move v3, v5

    .line 257
    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/FloatingService;->cheatMode:I

    const/4 v6, 0x0

    if-le v5, v6, :cond_0

    .line 258
    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/FloatingService;->cheatMode:I

    packed-switch v5, :pswitch_data_0

    .line 271
    :goto_0
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    check-cast v5, Landroid/widget/ImageButton;

    move-object v6, v0

    const-string v7, "00:00"

    const-string v8, "0"

    move-object v9, v2

    move v10, v3

    invoke-direct {v6, v7, v8, v9, v10}, Lgtandroid/universal/FloatingService;->getCircularBackground(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    return-void

    .line 259
    :pswitch_0
    const-string v5, "GM"

    move-object v2, v5

    const-string v5, "#FF00FF"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move v3, v5

    goto :goto_0

    .line 260
    :pswitch_1
    const-string v5, "DL"

    move-object v2, v5

    const-string v5, "#FF00FF"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move v3, v5

    goto :goto_0

    .line 261
    :pswitch_2
    const-string v5, "CL"

    move-object v2, v5

    const-string v5, "#FF00FF"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move v3, v5

    goto :goto_0

    .line 264
    :cond_0
    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/FloatingService;->chatMode:I

    packed-switch v5, :pswitch_data_1

    .line 267
    const-string v5, ""

    move-object v2, v5

    const-string v5, "#0066CC"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move v3, v5

    goto :goto_0

    .line 265
    :pswitch_3
    const-string v5, "N"

    move-object v2, v5

    const-string v5, "#FF6600"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move v3, v5

    goto :goto_0

    .line 266
    :pswitch_4
    const-string v5, "A"

    move-object v2, v5

    const-string v5, "#CC0000"

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    move v3, v5

    goto :goto_0

    .line 258
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch

    .line 264
    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method private updateIconContent()V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 289
    move-object/from16 v0, p0

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    if-nez v13, :cond_0

    .line 320
    :goto_0
    return-void

    .line 291
    :cond_0
    new-instance v13, Ljava/text/SimpleDateFormat;

    move-object/from16 v20, v13

    move-object/from16 v13, v20

    move-object/from16 v14, v20

    const-string v15, "HH:mm"

    invoke-direct {v14, v15}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    move-object v2, v13

    .line 292
    move-object v13, v2

    const-string v14, "Europe/Moscow"

    invoke-static {v14}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 293
    move-object v13, v2

    new-instance v14, Ljava/util/Date;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    invoke-direct {v15}, Ljava/util/Date;-><init>()V

    invoke-virtual {v13, v14}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v13

    move-object v3, v13

    .line 295
    move-object v13, v0

    const-string v14, "GTAndroidStats"

    const/4 v15, 0x0

    invoke-virtual {v13, v14, v15}, Landroid/content/ContextWrapper;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v13

    move-object v4, v13

    .line 297
    const-string v13, "Europe/Moscow"

    invoke-static {v13}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v13

    invoke-static {v13}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v13

    move-object v5, v13

    .line 298
    move-object v13, v5

    const/4 v14, 0x7

    invoke-virtual {v13, v14}, Ljava/util/Calendar;->get(I)I

    move-result v13

    move v6, v13

    .line 299
    move v13, v6

    const/4 v14, 0x1

    if-ne v13, v14, :cond_1

    const/4 v13, 0x6

    :goto_1
    move v7, v13

    .line 301
    move-object v13, v4

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v20, v14

    move-object/from16 v14, v20

    move-object/from16 v15, v20

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    const-string v15, "weekly_"

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move v15, v7

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x0

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v13

    move v8, v13

    .line 302
    move v13, v8

    invoke-static {v13}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v13

    move-object v9, v13

    .line 304
    const-string v13, ""

    move-object v10, v13

    .line 305
    const-string v13, "#0066CC"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    move v11, v13

    .line 307
    move-object v13, v0

    iget v13, v13, Lgtandroid/universal/FloatingService;->cheatMode:I

    const/4 v14, 0x0

    if-le v13, v14, :cond_2

    .line 308
    move-object v13, v0

    iget v13, v13, Lgtandroid/universal/FloatingService;->cheatMode:I

    packed-switch v13, :pswitch_data_0

    .line 320
    :goto_2
    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    check-cast v13, Landroid/widget/ImageButton;

    move-object v14, v0

    move-object v15, v3

    move-object/from16 v16, v9

    move-object/from16 v17, v10

    move/from16 v18, v11

    invoke-direct/range {v14 .. v18}, Lgtandroid/universal/FloatingService;->getCircularBackground(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)Landroid/graphics/drawable/Drawable;

    move-result-object v14

    invoke-virtual {v13, v14}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto/16 :goto_0

    .line 299
    :cond_1
    move v13, v6

    const/4 v14, 0x2

    add-int/lit8 v13, v13, -0x2

    goto :goto_1

    .line 309
    :pswitch_0
    const-string v13, "GM"

    move-object v10, v13

    const-string v13, "#FF00FF"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    move v11, v13

    goto :goto_2

    .line 310
    :pswitch_1
    const-string v13, "DL"

    move-object v10, v13

    const-string v13, "#FF00FF"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    move v11, v13

    goto :goto_2

    .line 311
    :pswitch_2
    const-string v13, "CL"

    move-object v10, v13

    const-string v13, "#FF00FF"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    move v11, v13

    goto :goto_2

    .line 314
    :cond_2
    move-object v13, v0

    iget v13, v13, Lgtandroid/universal/FloatingService;->chatMode:I

    packed-switch v13, :pswitch_data_1

    goto :goto_2

    .line 315
    :pswitch_3
    const-string v13, "N"

    move-object v10, v13

    const-string v13, "#FF6600"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    move v11, v13

    goto :goto_2

    .line 316
    :pswitch_4
    const-string v13, "A"

    move-object v10, v13

    const-string v13, "#CC0000"

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    move v11, v13

    goto :goto_2

    .line 308
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
        :pswitch_1
        :pswitch_2
    .end packed-switch

    .line 314
    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_3
        :pswitch_4
    .end packed-switch
.end method

.method private withAlpha(II)I
    .locals 7

    .prologue
    .line 45
    move-object v0, p0

    move v1, p1

    move v2, p2

    move v4, v2

    const/16 v5, 0x18

    shl-int/lit8 v4, v4, 0x18

    move v5, v1

    const v6, 0xffffff

    and-int/2addr v5, v6

    or-int/2addr v4, v5

    move v0, v4

    return v0
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 4
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 87
    move-object v0, p0

    move-object v1, p1

    const/4 v3, 0x0

    check-cast v3, Landroid/os/IBinder;

    move-object v0, v3

    return-object v0
.end method

.method public onCreate()V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 143
    move-object v0, p0

    move-object v2, v0

    invoke-super {v2}, Landroid/app/Service;->onCreate()V

    .line 144
    move-object v2, v0

    const-string v3, "FloatingService"

    invoke-static {v2, v3}, Lgtandroid/universal/AppLogger;->installCrashHandler(Landroid/content/Context;Ljava/lang/String;)V

    .line 145
    move-object v2, v0

    move-object v3, v0

    const-string v4, "GTAndroidData"

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/content/ContextWrapper;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    iput-object v3, v2, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    .line 146
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "chat_mode"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/FloatingService;->chatMode:I

    .line 147
    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/FloatingService;->chatMode:I

    sput v2, Lgtandroid/universal/FloatingService;->currentChatMode:I

    .line 148
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "cheat_mode"

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/FloatingService;->cheatMode:I

    .line 149
    move-object v2, v0

    iget v2, v2, Lgtandroid/universal/FloatingService;->cheatMode:I

    sput v2, Lgtandroid/universal/FloatingService;->currentCheatMode:I

    .line 150
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "keyboard_size"

    const/4 v5, 0x1

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/FloatingService;->keyboardSize:I

    .line 151
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "keyboard_transparency"

    const/16 v5, 0x64

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    iput v3, v2, Lgtandroid/universal/FloatingService;->keyboardTransparency:I

    .line 152
    move-object v2, v0

    move-object v3, v0

    const-string v4, "window"

    invoke-virtual {v3, v4}, Landroid/content/ContextWrapper;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/view/WindowManager;

    iput-object v3, v2, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    .line 154
    move-object v2, v0

    new-instance v3, Lgtandroid/universal/FloatingService$100000001;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/FloatingService$100000001;-><init>(Lgtandroid/universal/FloatingService;)V

    iput-object v3, v2, Lgtandroid/universal/FloatingService;->cheatResetReceiver:Landroid/content/BroadcastReceiver;

    .line 164
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->cheatResetReceiver:Landroid/content/BroadcastReceiver;

    new-instance v4, Landroid/content/IntentFilter;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "CHEAT_MODE_RESET"

    invoke-direct {v5, v6}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3, v4}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v2

    .line 166
    move-object v2, v0

    new-instance v3, Lgtandroid/universal/FloatingService$100000002;

    move-object v7, v3

    move-object v3, v7

    move-object v4, v7

    move-object v5, v0

    invoke-direct {v4, v5}, Lgtandroid/universal/FloatingService$100000002;-><init>(Lgtandroid/universal/FloatingService;)V

    iput-object v3, v2, Lgtandroid/universal/FloatingService;->updateIconReceiver:Landroid/content/BroadcastReceiver;

    .line 174
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->updateIconReceiver:Landroid/content/BroadcastReceiver;

    new-instance v4, Landroid/content/IntentFilter;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const-string v6, "UPDATE_FLOATING_ICON"

    invoke-direct {v5, v6}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3, v4}, Landroid/content/ContextWrapper;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    move-result-object v2

    .line 176
    move-object v2, v0

    invoke-direct {v2}, Lgtandroid/universal/FloatingService;->createFloatingIcon()V

    return-void
.end method

.method public onDestroy()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 372
    move-object v0, p0

    move-object v2, v0

    invoke-super {v2}, Landroid/app/Service;->onDestroy()V

    .line 373
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->iconUpdateHandler:Landroid/os/Handler;

    if-eqz v2, :cond_0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->iconUpdateRunnable:Ljava/lang/Runnable;

    if-eqz v2, :cond_0

    .line 374
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->iconUpdateHandler:Landroid/os/Handler;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->iconUpdateRunnable:Ljava/lang/Runnable;

    invoke-virtual {v2, v3}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 376
    :cond_0
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    if-eqz v2, :cond_1

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    if-eqz v2, :cond_1

    .line 377
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->floatingIconView:Landroid/view/View;

    invoke-interface {v2, v3}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    .line 379
    :cond_1
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    if-eqz v2, :cond_2

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    if-eqz v2, :cond_2

    .line 380
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->windowManager:Landroid/view/WindowManager;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->menuView:Landroid/widget/LinearLayout;

    invoke-interface {v2, v3}, Landroid/view/WindowManager;->removeView(Landroid/view/View;)V

    .line 382
    :cond_2
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->cheatResetReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v2, :cond_3

    .line 383
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->cheatResetReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v2, v3}, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 385
    :cond_3
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/FloatingService;->updateIconReceiver:Landroid/content/BroadcastReceiver;

    if-eqz v2, :cond_4

    .line 386
    move-object v2, v0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService;->updateIconReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v2, v3}, Landroid/content/ContextWrapper;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    :cond_4
    return-void
.end method
