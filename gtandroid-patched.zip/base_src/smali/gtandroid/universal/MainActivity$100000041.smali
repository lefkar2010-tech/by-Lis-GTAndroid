.class Lgtandroid/universal/MainActivity$100000041;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000041"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$btnMaster:Landroid/widget/Button;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000041;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/MainActivity$100000041;->val$btnMaster:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000041;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000041;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1526
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000041;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v3, v3, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const-string v4, "triggers_enabled"

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000041;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v5, v5, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "triggers_enabled"

    const/4 v7, 0x1

    invoke-interface {v5, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_0

    const/4 v5, 0x0

    :goto_0
    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 1527
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000041;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000041;->val$btnMaster:Landroid/widget/Button;

    invoke-static {v3, v4}, Lgtandroid/universal/MainActivity;->access$1000113(Lgtandroid/universal/MainActivity;Landroid/widget/Button;)V

    return-void

    .line 1526
    :cond_0
    const/4 v5, 0x1

    goto :goto_0
.end method
