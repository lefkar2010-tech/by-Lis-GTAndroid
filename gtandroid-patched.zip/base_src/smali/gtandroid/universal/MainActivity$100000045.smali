.class Lgtandroid/universal/MainActivity$100000045;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000045"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/MainActivity$100000045$100000044;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$btnPick:Landroid/widget/Button;

.field private final val$selName:[Ljava/lang/String;

.field private final val$selText:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;[Ljava/lang/String;[Ljava/lang/String;Landroid/widget/Button;)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000045;->this$0:Lgtandroid/universal/MainActivity;

    move-object v6, v0

    move-object v7, v2

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000045;->val$selName:[Ljava/lang/String;

    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000045;->val$selText:[Ljava/lang/String;

    move-object v6, v0

    move-object v7, v4

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000045;->val$btnPick:Landroid/widget/Button;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000045;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000045;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1632
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object v9, v1

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000045;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v9}, Lgtandroid/universal/MainActivity;->access$1000109(Lgtandroid/universal/MainActivity;)Ljava/util/List;

    move-result-object v9

    move-object v4, v9

    .line 1633
    move-object v9, v4

    invoke-interface {v9}, Ljava/util/List;->isEmpty()Z

    move-result v9

    if-eqz v9, :cond_0

    .line 1634
    move-object v9, v1

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000045;->this$0:Lgtandroid/universal/MainActivity;

    const-string v10, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0434\u043e\u0431\u0430\u0432\u044c\u0442\u0435 \u0431\u044b\u0441\u0442\u0440\u044b\u0435 \u043e\u0442\u0432\u0435\u0442\u044b (\u0420\u0435\u0434\u0430\u043a\u0442\u043e\u0440 \u0431\u044b\u0441\u0442\u0440\u043e\u0433\u043e \u043e\u0442\u0432\u0435\u0442\u0430)"

    const/4 v11, 0x1

    invoke-static {v9, v10, v11}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v9

    invoke-virtual {v9}, Landroid/widget/Toast;->show()V

    .line 1643
    :goto_0
    return-void

    .line 1637
    :cond_0
    move-object v9, v4

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    new-array v9, v9, [Ljava/lang/String;

    move-object v5, v9

    .line 1638
    const/4 v9, -0x1

    move v6, v9

    .line 1639
    const/4 v9, 0x0

    move v7, v9

    :goto_1
    move v9, v7

    move-object v10, v4

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v10

    if-lt v9, v10, :cond_1

    .line 1643
    new-instance v9, Landroid/app/AlertDialog$Builder;

    move-object/from16 v19, v9

    move-object/from16 v9, v19

    move-object/from16 v10, v19

    move-object v11, v1

    iget-object v11, v11, Lgtandroid/universal/MainActivity$100000045;->this$0:Lgtandroid/universal/MainActivity;

    invoke-direct {v10, v11}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v10, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u043e\u0434\u0438\u043d \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442"

    invoke-virtual {v9, v10}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    move-object v10, v5

    move v11, v6

    new-instance v12, Lgtandroid/universal/MainActivity$100000045$100000044;

    move-object/from16 v19, v12

    move-object/from16 v12, v19

    move-object/from16 v13, v19

    move-object v14, v1

    move-object v15, v1

    iget-object v15, v15, Lgtandroid/universal/MainActivity$100000045;->val$selName:[Ljava/lang/String;

    move-object/from16 v16, v4

    move-object/from16 v17, v1

    move-object/from16 v0, v17

    iget-object v0, v0, Lgtandroid/universal/MainActivity$100000045;->val$selText:[Ljava/lang/String;

    move-object/from16 v17, v0

    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/MainActivity$100000045;->val$btnPick:Landroid/widget/Button;

    move-object/from16 v18, v0

    invoke-direct/range {v13 .. v18}, Lgtandroid/universal/MainActivity$100000045$100000044;-><init>(Lgtandroid/universal/MainActivity$100000045;[Ljava/lang/String;Ljava/util/List;[Ljava/lang/String;Landroid/widget/Button;)V

    invoke-virtual {v9, v10, v11, v12}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    const-string v10, "\u041e\u0442\u043c\u0435\u043d\u0430"

    const/4 v11, 0x0

    check-cast v11, Landroid/content/DialogInterface$OnClickListener;

    invoke-virtual {v9, v10, v11}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v9

    invoke-virtual {v9}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    move-result-object v9

    goto :goto_0

    .line 1640
    :cond_1
    move-object v9, v5

    move v10, v7

    move-object v11, v4

    move v12, v7

    invoke-interface {v11, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [Ljava/lang/String;

    const/4 v12, 0x0

    aget-object v11, v11, v12

    aput-object v11, v9, v10

    .line 1641
    move-object v9, v5

    move v10, v7

    aget-object v9, v9, v10

    move-object v10, v1

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000045;->val$selName:[Ljava/lang/String;

    const/4 v11, 0x0

    aget-object v10, v10, v11

    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2

    move v9, v7

    move v6, v9

    .line 1639
    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_1
.end method
