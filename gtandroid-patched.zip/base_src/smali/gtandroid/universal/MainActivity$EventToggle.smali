.class Lgtandroid/universal/MainActivity$EventToggle;
.super Landroid/view/View;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2a
    name = "EventToggle"
.end annotation


# instance fields
.field private checked:Z

.field private final paint:Landroid/graphics/Paint;

.field private final rect:Landroid/graphics/RectF;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 8

    .prologue
    .line 906
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-direct {v3, v4}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    move-object v3, v0

    const/4 v4, 0x0

    iput-boolean v4, v3, Lgtandroid/universal/MainActivity$EventToggle;->checked:Z

    move-object v3, v0

    new-instance v4, Landroid/graphics/Paint;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    const/4 v6, 0x1

    invoke-direct {v5, v6}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v4, v3, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    move-object v3, v0

    new-instance v4, Landroid/graphics/RectF;

    move-object v7, v4

    move-object v4, v7

    move-object v5, v7

    invoke-direct {v5}, Landroid/graphics/RectF;-><init>()V

    iput-object v4, v3, Lgtandroid/universal/MainActivity$EventToggle;->rect:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method isChecked()Z
    .locals 3

    .prologue
    .line 915
    move-object v0, p0

    move-object v2, v0

    iget-boolean v2, v2, Lgtandroid/universal/MainActivity$EventToggle;->checked:Z

    move v0, v2

    return v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 920
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v10, v0

    invoke-virtual {v10}, Landroid/view/View;->getWidth()I

    move-result v10

    int-to-float v10, v10

    move v3, v10

    .line 921
    move-object v10, v0

    invoke-virtual {v10}, Landroid/view/View;->getHeight()I

    move-result v10

    int-to-float v10, v10

    move v4, v10

    .line 922
    move v10, v4

    const/high16 v11, 0x40000000    # 2.0f

    div-float/2addr v10, v11

    move v5, v10

    .line 923
    move v10, v4

    const v11, 0x3d8f5c29    # 0.07f

    mul-float/2addr v10, v11

    move v6, v10

    .line 925
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    sget-object v11, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 926
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    move-object v11, v0

    iget-boolean v11, v11, Lgtandroid/universal/MainActivity$EventToggle;->checked:Z

    if-eqz v11, :cond_1

    const v11, -0xe10086

    :goto_0
    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 927
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->rect:Landroid/graphics/RectF;

    const/4 v11, 0x0

    int-to-float v11, v11

    const/4 v12, 0x0

    int-to-float v12, v12

    move v13, v3

    move v14, v4

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/RectF;->set(FFFF)V

    .line 928
    move-object v10, v1

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity$EventToggle;->rect:Landroid/graphics/RectF;

    move v12, v5

    move v13, v5

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 930
    move v10, v5

    move v11, v4

    const v12, 0x3db851ec    # 0.09f

    mul-float/2addr v11, v12

    sub-float/2addr v10, v11

    move v7, v10

    .line 931
    move-object v10, v0

    iget-boolean v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->checked:Z

    if-eqz v10, :cond_2

    move v10, v3

    move v11, v5

    sub-float/2addr v10, v11

    :goto_1
    move v8, v10

    .line 932
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    const/4 v11, -0x1

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 933
    move-object v10, v1

    move v11, v8

    move v12, v5

    move v13, v7

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 935
    move-object v10, v0

    iget-boolean v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->checked:Z

    if-nez v10, :cond_0

    .line 936
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    sget-object v11, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 937
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    move v11, v6

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 938
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    const v11, -0x303031

    invoke-virtual {v10, v11}, Landroid/graphics/Paint;->setColor(I)V

    .line 939
    move-object v10, v1

    move v11, v8

    move v12, v5

    move v13, v7

    move v14, v6

    const/high16 v15, 0x40000000    # 2.0f

    div-float/2addr v14, v15

    sub-float/2addr v13, v14

    move-object v14, v0

    iget-object v14, v14, Lgtandroid/universal/MainActivity$EventToggle;->paint:Landroid/graphics/Paint;

    invoke-virtual {v10, v11, v12, v13, v14}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    :cond_0
    return-void

    .line 926
    :cond_1
    const v11, -0x19191a

    goto :goto_0

    .line 931
    :cond_2
    move v10, v5

    goto :goto_1
.end method

.method setChecked(Z)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation

    .prologue
    .line 910
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    move v4, v1

    iput-boolean v4, v3, Lgtandroid/universal/MainActivity$EventToggle;->checked:Z

    .line 911
    move-object v3, v0

    invoke-virtual {v3}, Landroid/view/View;->invalidate()V

    return-void
.end method
