.class Lgtandroid/universal/KeyboardService$100000087;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000087"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$playerId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000087;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000087;->val$playerId:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000087;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000087;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3501
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000087;->this$0:Lgtandroid/universal/KeyboardService;

    new-instance v4, Ljava/lang/StringBuffer;

    move-object v6, v4

    move-object v4, v6

    move-object v5, v6

    invoke-direct {v5}, Ljava/lang/StringBuffer;-><init>()V

    const-string v5, "/goto "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000087;->val$playerId:Ljava/lang/String;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 3502
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000087;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000087;->val$playerId:Ljava/lang/String;

    invoke-static {v3, v4}, Lgtandroid/universal/KeyboardService;->access$1000388(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    return-void
.end method
