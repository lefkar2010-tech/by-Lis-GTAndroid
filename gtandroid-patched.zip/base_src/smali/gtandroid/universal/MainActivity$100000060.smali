.class Lgtandroid/universal/MainActivity$100000060;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000060"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$index:I

.field private final val$typeName:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;I)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000060;->this$0:Lgtandroid/universal/MainActivity;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000060;->val$typeName:Ljava/lang/String;

    move-object v5, v0

    move v6, v3

    iput v6, v5, Lgtandroid/universal/MainActivity$100000060;->val$index:I

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000060;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000060;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2162
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000060;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000060;->val$typeName:Ljava/lang/String;

    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/MainActivity$100000060;->val$index:I

    invoke-static {v3, v4, v5}, Lgtandroid/universal/MainActivity;->access$1000149(Lgtandroid/universal/MainActivity;Ljava/lang/String;I)V

    .line 2163
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000060;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000060;->val$typeName:Ljava/lang/String;

    invoke-static {v3, v4}, Lgtandroid/universal/MainActivity;->access$1000145(Lgtandroid/universal/MainActivity;Ljava/lang/String;)V

    return-void
.end method
