.class Lgtandroid/universal/FloatingService$100000002;
.super Landroid/content/BroadcastReceiver;
.source "FloatingService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/FloatingService$100000002;->this$0:Lgtandroid/universal/FloatingService;

    move-object v3, v0

    invoke-direct {v3}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000002;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000002;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 169
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    const-string v4, "UPDATE_FLOATING_ICON"

    move-object v5, v2

    invoke-virtual {v5}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    .line 170
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000002;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v4}, Lgtandroid/universal/FloatingService;->access$1000034(Lgtandroid/universal/FloatingService;)V

    :cond_0
    return-void
.end method
