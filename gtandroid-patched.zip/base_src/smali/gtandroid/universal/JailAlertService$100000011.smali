.class Lgtandroid/universal/JailAlertService$100000011;
.super Ljava/lang/Object;
.source "JailAlertService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000011"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/JailAlertService$100000011;->this$0:Lgtandroid/universal/JailAlertService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000011;)Lgtandroid/universal/JailAlertService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000011;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1445
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService$100000011;->this$0:Lgtandroid/universal/JailAlertService;

    invoke-static {v2}, Lgtandroid/universal/JailAlertService;->access$1000130(Lgtandroid/universal/JailAlertService;)V

    .line 1446
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/JailAlertService$100000011;->this$0:Lgtandroid/universal/JailAlertService;

    new-instance v3, Landroid/content/Intent;

    move-object v6, v3

    move-object v3, v6

    move-object v4, v6

    const-string v5, "CLEAR_HELP_PLAYER"

    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method
