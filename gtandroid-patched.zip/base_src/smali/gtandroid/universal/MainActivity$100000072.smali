.class Lgtandroid/universal/MainActivity$100000072;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000072"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$sizes:[Ljava/lang/String;

.field private final val$values:[I


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;[I[Ljava/lang/String;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000072;->this$0:Lgtandroid/universal/MainActivity;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000072;->val$values:[I

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000072;->val$sizes:[Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000072;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000072;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2758
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000072;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v6, v6, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v6}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const-string v7, "keyboard_size"

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000072;->val$values:[I

    move v9, v2

    aget v8, v8, v9

    invoke-interface {v6, v7, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 2759
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000072;->this$0:Lgtandroid/universal/MainActivity;

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    const-string v8, "\u2705 \u0420\u0430\u0437\u043c\u0435\u0440: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000072;->val$sizes:[Ljava/lang/String;

    move v9, v2

    aget-object v8, v8, v9

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v8, 0x0

    invoke-static {v6, v7, v8}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v6

    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 2761
    new-instance v6, Landroid/content/Intent;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    const-string v8, "KEYBOARD_SIZE_CHANGED"

    invoke-direct {v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v4, v6

    .line 2762
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000072;->this$0:Lgtandroid/universal/MainActivity;

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    .line 2763
    move-object v6, v1

    invoke-interface {v6}, Landroid/content/DialogInterface;->dismiss()V

    return-void
.end method
