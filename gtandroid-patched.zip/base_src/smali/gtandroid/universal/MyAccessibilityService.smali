.class public Lgtandroid/universal/MyAccessibilityService;
.super Landroid/accessibilityservice/AccessibilityService;
.source "MyAccessibilityService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/MyAccessibilityService$100000000;,
        Lgtandroid/universal/MyAccessibilityService$100000001;,
        Lgtandroid/universal/MyAccessibilityService$100000002;
    }
.end annotation


# static fields
.field private static instance:Lgtandroid/universal/MyAccessibilityService;


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 184
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Landroid/accessibilityservice/AccessibilityService;-><init>()V

    return-void
.end method

.method static access$1000004(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-static {v3}, Lgtandroid/universal/MyAccessibilityService;->findEditableNode(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v3

    move-object v0, v3

    return-object v0
.end method

.method private static findEditableNode(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;
    .locals 8

    .prologue
    .line 159
    move-object v0, p0

    move-object v6, v0

    if-nez v6, :cond_0

    const/4 v6, 0x0

    check-cast v6, Landroid/view/accessibility/AccessibilityNodeInfo;

    move-object v0, v6

    .line 179
    :goto_0
    return-object v0

    .line 161
    :cond_0
    move-object v6, v0

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->isEditable()Z

    move-result v6

    if-eqz v6, :cond_1

    move-object v6, v0

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->isEnabled()Z

    move-result v6

    if-eqz v6, :cond_1

    move-object v6, v0

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->isFocused()Z

    move-result v6

    if-eqz v6, :cond_1

    .line 162
    move-object v6, v0

    move-object v0, v6

    goto :goto_0

    .line 165
    :cond_1
    move-object v6, v0

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->isEditable()Z

    move-result v6

    if-eqz v6, :cond_2

    move-object v6, v0

    invoke-virtual {v6}, Landroid/view/accessibility/AccessibilityNodeInfo;->isEnabled()Z

    move-result v6

    if-eqz v6, :cond_2

    .line 166
    move-object v6, v0

    move-object v0, v6

    goto :goto_0

    .line 169
    :cond_2
    const/4 v6, 0x0

    move v2, v6

    :goto_1
    move v6, v2

    move-object v7, v0

    invoke-virtual {v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChildCount()I

    move-result v7

    if-lt v6, v7, :cond_3

    .line 179
    const/4 v6, 0x0

    check-cast v6, Landroid/view/accessibility/AccessibilityNodeInfo;

    move-object v0, v6

    goto :goto_0

    .line 170
    :cond_3
    move-object v6, v0

    move v7, v2

    invoke-virtual {v6, v7}, Landroid/view/accessibility/AccessibilityNodeInfo;->getChild(I)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v6

    move-object v3, v6

    .line 171
    move-object v6, v3

    if-eqz v6, :cond_4

    .line 172
    move-object v6, v3

    invoke-static {v6}, Lgtandroid/universal/MyAccessibilityService;->findEditableNode(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v6

    move-object v4, v6

    .line 173
    move-object v6, v4

    if-eqz v6, :cond_4

    .line 174
    move-object v6, v4

    move-object v0, v6

    goto :goto_0

    .line 169
    :cond_4
    add-int/lit8 v2, v2, 0x1

    goto :goto_1
.end method

.method public static insertText(Ljava/lang/String;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 58
    move-object v0, p0

    sget-object v4, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    move-object v2, v4

    .line 59
    move-object v4, v2

    if-nez v4, :cond_0

    .line 61
    :goto_0
    return-void

    :cond_0
    new-instance v4, Landroid/os/Handler;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    invoke-direct {v5}, Landroid/os/Handler;-><init>()V

    new-instance v5, Lgtandroid/universal/MyAccessibilityService$100000000;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    move-object v7, v2

    move-object v8, v0

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MyAccessibilityService$100000000;-><init>(Lgtandroid/universal/MyAccessibilityService;Ljava/lang/String;)V

    const/16 v6, 0x64

    int-to-long v6, v6

    invoke-virtual {v4, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v4

    goto :goto_0
.end method

.method public static insertTextAndPaste(Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    return-void
.end method

.method public static insertTextAndSend(Ljava/lang/String;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .prologue
    .line 130
    move-object v0, p0

    sget-object v4, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    move-object v2, v4

    .line 131
    move-object v4, v2

    if-nez v4, :cond_0

    .line 133
    :goto_0
    return-void

    :cond_0
    new-instance v4, Landroid/os/Handler;

    move-object v9, v4

    move-object v4, v9

    move-object v5, v9

    invoke-direct {v5}, Landroid/os/Handler;-><init>()V

    new-instance v5, Lgtandroid/universal/MyAccessibilityService$100000002;

    move-object v9, v5

    move-object v5, v9

    move-object v6, v9

    move-object v7, v2

    move-object v8, v0

    invoke-direct {v6, v7, v8}, Lgtandroid/universal/MyAccessibilityService$100000002;-><init>(Lgtandroid/universal/MyAccessibilityService;Ljava/lang/String;)V

    const/16 v6, 0x64

    int-to-long v6, v6

    invoke-virtual {v4, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v4

    goto :goto_0
.end method

.method public static isAvailable()Z
    .locals 3

    .prologue
    .line 183
    sget-object v2, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    if-nez v2, :cond_0

    const/4 v2, 0x0

    :goto_0
    move v0, v2

    return v0

    :cond_0
    const/4 v2, 0x1

    goto :goto_0
.end method

.method public static pasteAndSend(Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    return-void
.end method

.method public static pressEnter()V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 107
    sget-object v4, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    move-object v2, v4

    .line 108
    move-object v4, v2

    if-nez v4, :cond_0

    .line 110
    :goto_0
    return-void

    :cond_0
    new-instance v4, Landroid/os/Handler;

    move-object v8, v4

    move-object v4, v8

    move-object v5, v8

    invoke-direct {v5}, Landroid/os/Handler;-><init>()V

    new-instance v5, Lgtandroid/universal/MyAccessibilityService$100000001;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    move-object v7, v2

    invoke-direct {v6, v7}, Lgtandroid/universal/MyAccessibilityService$100000001;-><init>(Lgtandroid/universal/MyAccessibilityService;)V

    const/16 v6, 0x64

    int-to-long v6, v6

    invoke-virtual {v4, v5, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    move-result v4

    goto :goto_0
.end method


# virtual methods
.method public onAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/accessibility/AccessibilityEvent;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public onDestroy()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 53
    move-object v0, p0

    sget-object v2, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    move-object v3, v0

    if-ne v2, v3, :cond_0

    const/4 v2, 0x0

    check-cast v2, Lgtandroid/universal/MyAccessibilityService;

    sput-object v2, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    .line 54
    :cond_0
    move-object v2, v0

    invoke-super {v2}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onInterrupt()V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method

.method public onServiceConnected()V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 26
    move-object v1, p0

    move-object v5, v1

    sput-object v5, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    .line 27
    new-instance v5, Landroid/accessibilityservice/AccessibilityServiceInfo;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Landroid/accessibilityservice/AccessibilityServiceInfo;-><init>()V

    move-object v3, v5

    .line 29
    move-object v5, v3

    const/16 v6, 0x20

    iput v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->eventTypes:I

    .line 30
    move-object v5, v3

    const/16 v6, 0x10

    iput v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->feedbackType:I

    .line 31
    move-object v5, v3

    const/4 v6, 0x0

    iput v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->flags:I

    .line 32
    move-object v5, v3

    const/16 v6, 0x12c

    int-to-long v6, v6

    iput-wide v6, v5, Landroid/accessibilityservice/AccessibilityServiceInfo;->notificationTimeout:J

    .line 33
    move-object v5, v1

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/accessibilityservice/AccessibilityService;->setServiceInfo(Landroid/accessibilityservice/AccessibilityServiceInfo;)V

    return-void
.end method

.method public onUnbind(Landroid/content/Intent;)Z
    .locals 5
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 47
    move-object v0, p0

    move-object v1, p1

    sget-object v3, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    move-object v4, v0

    if-ne v3, v4, :cond_0

    const/4 v3, 0x0

    check-cast v3, Lgtandroid/universal/MyAccessibilityService;

    sput-object v3, Lgtandroid/universal/MyAccessibilityService;->instance:Lgtandroid/universal/MyAccessibilityService;

    .line 48
    :cond_0
    move-object v3, v0

    move-object v4, v1

    invoke-super {v3, v4}, Landroid/app/Service;->onUnbind(Landroid/content/Intent;)Z

    move-result v3

    move v0, v3

    return v0
.end method
