.class Lgtandroid/universal/KeyboardService$100000104;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000104"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$label:Ljava/lang/String;

.field private final val$onTap:Lgtandroid/universal/KeyboardService$ValueCb;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/KeyboardService$ValueCb;Ljava/lang/String;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000104;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000104;->val$onTap:Lgtandroid/universal/KeyboardService$ValueCb;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/KeyboardService$100000104;->val$label:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000104;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000104;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4173
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000104;->val$onTap:Lgtandroid/universal/KeyboardService$ValueCb;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000104;->val$label:Ljava/lang/String;

    invoke-interface {v3, v4}, Lgtandroid/universal/KeyboardService$ValueCb;->onValue(Ljava/lang/String;)V

    return-void
.end method
