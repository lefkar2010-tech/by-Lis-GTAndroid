.class Lgtandroid/universal/KeyboardService$100000161;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Lgtandroid/universal/KeyboardService$TileClick;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000161"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/KeyboardService$100000161$100000159;,
        Lgtandroid/universal/KeyboardService$100000161$100000160;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/KeyboardService$100000161;->this$0:Lgtandroid/universal/KeyboardService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000161;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000161;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTile(Lgtandroid/universal/KeyboardService$TileSpec;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgtandroid/universal/KeyboardService$TileSpec;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 5625
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    iget v3, v3, Lgtandroid/universal/KeyboardService$TileSpec;->style:I

    const/4 v4, 0x2

    if-ne v3, v4, :cond_0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000161;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v3}, Lgtandroid/universal/KeyboardService;->access$1000308(Lgtandroid/universal/KeyboardService;)V

    .line 5636
    :goto_0
    return-void

    .line 5626
    :cond_0
    move-object v3, v1

    iget v3, v3, Lgtandroid/universal/KeyboardService$TileSpec;->req:I

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000161;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v4}, Lgtandroid/universal/KeyboardService;->access$L1000014(Lgtandroid/universal/KeyboardService;)I

    move-result v4

    if-le v3, v4, :cond_1

    .line 5627
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000161;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v1

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$TileSpec;->name:Ljava/lang/String;

    move-object v5, v1

    iget v5, v5, Lgtandroid/universal/KeyboardService$TileSpec;->req:I

    new-instance v6, Lgtandroid/universal/KeyboardService$100000161$100000159;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    move-object v8, v0

    invoke-direct {v7, v8}, Lgtandroid/universal/KeyboardService$100000161$100000159;-><init>(Lgtandroid/universal/KeyboardService$100000161;)V

    new-instance v7, Lgtandroid/universal/KeyboardService$100000161$100000160;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    move-object v10, v1

    invoke-direct {v8, v9, v10}, Lgtandroid/universal/KeyboardService$100000161$100000160;-><init>(Lgtandroid/universal/KeyboardService$100000161;Lgtandroid/universal/KeyboardService$TileSpec;)V

    invoke-static {v3, v4, v5, v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000380(Lgtandroid/universal/KeyboardService;Ljava/lang/String;ILjava/lang/Runnable;Ljava/lang/Runnable;)V

    .line 5634
    goto :goto_0

    .line 5636
    :cond_1
    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000161;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v1

    const/4 v5, 0x0

    invoke-static {v3, v4, v5}, Lgtandroid/universal/KeyboardService;->access$1000441(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/KeyboardService$TileSpec;Z)V

    goto :goto_0
.end method
