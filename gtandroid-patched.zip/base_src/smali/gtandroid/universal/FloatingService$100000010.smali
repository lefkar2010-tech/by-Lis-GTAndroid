.class Lgtandroid/universal/FloatingService$100000010;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/widget/RadioGroup$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000010"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000010;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/RadioGroup;I)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/RadioGroup;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 644
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v4, v2

    const/4 v5, 0x1

    if-ne v4, v5, :cond_0

    .line 645
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    const/4 v5, 0x2

    invoke-static {v4, v5}, Lgtandroid/universal/FloatingService;->access$S1000014(Lgtandroid/universal/FloatingService;I)V

    .line 646
    const/4 v4, 0x2

    sput v4, Lgtandroid/universal/FloatingService;->currentChatMode:I

    .line 647
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    const-string v5, "\u0420\u0435\u0436\u0438\u043c: \u0410\u0434\u043c\u0438\u043d \u0447\u0430\u0442 (/a)"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    .line 657
    :goto_0
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v4}, Lgtandroid/universal/FloatingService;->access$L1000013(Lgtandroid/universal/FloatingService;)Landroid/content/SharedPreferences;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "chat_mode"

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v6}, Lgtandroid/universal/FloatingService;->access$L1000014(Lgtandroid/universal/FloatingService;)I

    move-result v6

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 658
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v4}, Lgtandroid/universal/FloatingService;->access$1000034(Lgtandroid/universal/FloatingService;)V

    return-void

    .line 648
    :cond_0
    move v4, v2

    const/4 v5, 0x2

    if-ne v4, v5, :cond_1

    .line 649
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    const/4 v5, 0x1

    invoke-static {v4, v5}, Lgtandroid/universal/FloatingService;->access$S1000014(Lgtandroid/universal/FloatingService;I)V

    .line 650
    const/4 v4, 0x1

    sput v4, Lgtandroid/universal/FloatingService;->currentChatMode:I

    .line 651
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    const-string v5, "\u0420\u0435\u0436\u0438\u043c: \u041d\u043e\u043d \u0420\u041f \u0447\u0430\u0442 (/n)"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 653
    :cond_1
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    const/4 v5, 0x0

    invoke-static {v4, v5}, Lgtandroid/universal/FloatingService;->access$S1000014(Lgtandroid/universal/FloatingService;I)V

    .line 654
    const/4 v4, 0x0

    sput v4, Lgtandroid/universal/FloatingService;->currentChatMode:I

    .line 655
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000010;->this$0:Lgtandroid/universal/FloatingService;

    const-string v5, "\u0420\u0435\u0436\u0438\u043c: \u041e\u0431\u044b\u0447\u043d\u044b\u0439"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method
