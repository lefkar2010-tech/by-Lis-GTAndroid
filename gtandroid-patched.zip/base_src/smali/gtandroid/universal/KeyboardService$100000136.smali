.class Lgtandroid/universal/KeyboardService$100000136;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Lgtandroid/universal/KeyboardService$TileClick;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000136"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/KeyboardService$100000136$100000135;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$mainContainer:Landroid/widget/LinearLayout;

.field private final val$playerId:Ljava/lang/String;

.field private final val$reopenPanel:Ljava/lang/Runnable;

.field private final val$violatorId:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Landroid/widget/LinearLayout;Ljava/lang/Runnable;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136;->val$playerId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136;->val$violatorId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136;->val$mainContainer:Landroid/widget/LinearLayout;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000136;->val$reopenPanel:Ljava/lang/Runnable;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000136;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000136;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTile(Lgtandroid/universal/KeyboardService$TileSpec;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lgtandroid/universal/KeyboardService$TileSpec;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4755
    move-object v0, p0

    move-object v1, p1

    new-instance v5, Lgtandroid/universal/KeyboardService$100000136$100000135;

    move-object v12, v5

    move-object v5, v12

    move-object v6, v12

    move-object v7, v0

    move-object v8, v1

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000136;->val$playerId:Ljava/lang/String;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/KeyboardService$100000136;->val$violatorId:Ljava/lang/String;

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/KeyboardService$100000136;->val$mainContainer:Landroid/widget/LinearLayout;

    invoke-direct/range {v6 .. v11}, Lgtandroid/universal/KeyboardService$100000136$100000135;-><init>(Lgtandroid/universal/KeyboardService$100000136;Lgtandroid/universal/KeyboardService$TileSpec;Ljava/lang/String;Ljava/lang/String;Landroid/widget/LinearLayout;)V

    move-object v3, v5

    .line 4759
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000136;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v1

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000136;->val$violatorId:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000136;->val$reopenPanel:Ljava/lang/Runnable;

    move-object v9, v3

    const/4 v10, 0x1

    invoke-static/range {v5 .. v10}, Lgtandroid/universal/KeyboardService;->access$1000310(Lgtandroid/universal/KeyboardService;Lgtandroid/universal/KeyboardService$TileSpec;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/Runnable;Z)V

    return-void
.end method
