.class Lgtandroid/universal/KeyboardService$100000070;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000070"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$adminId:Ljava/lang/String;

.field private final val$nick:Ljava/lang/String;

.field private final val$playerId:Ljava/lang/String;

.field private final val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000070;->val$playerId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000070;->val$nick:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000070;->val$adminId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000070;->val$text:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000070;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2988
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$1000227(Lgtandroid/universal/KeyboardService;)V

    .line 2989
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v5}, Lgtandroid/universal/KeyboardService;->access$1000226(Lgtandroid/universal/KeyboardService;)V

    .line 2990
    new-instance v5, Landroid/content/Intent;

    move-object v10, v5

    move-object v5, v10

    move-object v6, v10

    const-string v7, "HELP_PLAYER_ACCEPTED"

    invoke-direct {v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v3, v5

    .line 2991
    move-object v5, v3

    const-string v6, "playerId"

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000070;->val$playerId:Ljava/lang/String;

    invoke-virtual {v5, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v5

    .line 2992
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v3

    invoke-virtual {v5, v6}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    .line 2994
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v10, v8

    move-object v8, v10

    move-object v9, v10

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "/a [ATools] \u041f\u044b\u0442\u0430\u044e\u0441\u044c \u043f\u043e\u043c\u043e\u0447\u044c \u0438\u0433\u0440\u043e\u043a\u0443 \u0441 "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    const-string v9, "["

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000070;->val$playerId:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    const-string v7, "]"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 2995
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000070;->val$nick:Ljava/lang/String;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000070;->val$adminId:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000070;->val$text:Ljava/lang/String;

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_0

    new-instance v8, Ljava/lang/StringBuffer;

    move-object v10, v8

    move-object v8, v10

    move-object v9, v10

    invoke-direct {v9}, Ljava/lang/StringBuffer;-><init>()V

    const-string v9, "\u043f\u043e\u043c\u043e\u0449\u044c \u0438\u0433\u0440\u043e\u043a\u0443 "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/KeyboardService$100000070;->val$playerId:Ljava/lang/String;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v8

    :goto_0
    invoke-static {v5, v6, v7, v8}, Lgtandroid/universal/KeyboardService;->access$1000336(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 2997
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    const/4 v6, 0x1

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$S1000018(Lgtandroid/universal/KeyboardService;Z)V

    .line 2998
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000070;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000070;->val$playerId:Ljava/lang/String;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000070;->val$playerId:Ljava/lang/String;

    const/4 v8, 0x0

    invoke-static {v5, v6, v7, v8}, Lgtandroid/universal/KeyboardService;->access$1000280(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Z)V

    return-void

    .line 2995
    :cond_0
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000070;->val$text:Ljava/lang/String;

    goto :goto_0
.end method
