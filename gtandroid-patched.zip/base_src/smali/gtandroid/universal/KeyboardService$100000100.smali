.class Lgtandroid/universal/KeyboardService$100000100;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000100"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$id:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000100;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000100;->val$id:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000100;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000100;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 4009
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000100;->this$0:Lgtandroid/universal/KeyboardService;

    new-instance v3, Ljava/lang/StringBuffer;

    move-object v5, v3

    move-object v3, v5

    move-object v4, v5

    invoke-direct {v4}, Ljava/lang/StringBuffer;-><init>()V

    const-string v4, "/sp "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/KeyboardService$100000100;->val$id:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 4010
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000100;->this$0:Lgtandroid/universal/KeyboardService;

    const/4 v3, 0x1

    invoke-static {v2, v3}, Lgtandroid/universal/KeyboardService;->access$S1000018(Lgtandroid/universal/KeyboardService;Z)V

    .line 4011
    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/KeyboardService$100000100;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000100;->val$id:Ljava/lang/String;

    invoke-static {v2, v3}, Lgtandroid/universal/KeyboardService;->access$1000285(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    return-void
.end method
