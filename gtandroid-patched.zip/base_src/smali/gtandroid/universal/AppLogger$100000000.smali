.class Lgtandroid/universal/AppLogger$100000000;
.super Ljava/lang/Object;
.source "AppLogger.java"

# interfaces
.implements Ljava/lang/Thread$UncaughtExceptionHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/AppLogger;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final val$appCtx:Landroid/content/Context;

.field private final val$previous:Ljava/lang/Thread$UncaughtExceptionHandler;

.field private final val$tag:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Thread$UncaughtExceptionHandler;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/AppLogger$100000000;->val$appCtx:Landroid/content/Context;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/AppLogger$100000000;->val$tag:Ljava/lang/String;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/AppLogger$100000000;->val$previous:Ljava/lang/Thread$UncaughtExceptionHandler;

    return-void
.end method


# virtual methods
.method public uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Thread;",
            "Ljava/lang/Throwable;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 57
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v6, v0

    :try_start_0
    iget-object v6, v6, Lgtandroid/universal/AppLogger$100000000;->val$appCtx:Landroid/content/Context;

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/AppLogger$100000000;->val$tag:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, "_CRASH"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v8, v2

    invoke-static {v6, v7, v8}, Lgtandroid/universal/AppLogger;->logException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0

    .line 61
    :goto_0
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AppLogger$100000000;->val$previous:Ljava/lang/Thread$UncaughtExceptionHandler;

    if-eqz v6, :cond_0

    .line 62
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/AppLogger$100000000;->val$previous:Ljava/lang/Thread$UncaughtExceptionHandler;

    move-object v7, v1

    move-object v8, v2

    invoke-interface {v6, v7, v8}, Ljava/lang/Thread$UncaughtExceptionHandler;->uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    :cond_0
    return-void

    .line 57
    :catch_0
    move-exception v6

    move-object v4, v6

    goto :goto_0
.end method
