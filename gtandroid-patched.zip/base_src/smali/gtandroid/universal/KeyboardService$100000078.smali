.class Lgtandroid/universal/KeyboardService$100000078;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000078"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$idInput:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Landroid/widget/EditText;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000078;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/KeyboardService$100000078;->val$idInput:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000078;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000078;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 3258
    move-object v0, p0

    move-object v1, p1

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000078;->val$idInput:Landroid/widget/EditText;

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    invoke-interface {v5}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v3, v5

    .line 3259
    move-object v5, v3

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    if-eqz v5, :cond_0

    .line 3264
    :goto_0
    return-void

    .line 3263
    :cond_0
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000078;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$S1000034(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 3264
    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/KeyboardService$100000078;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v6, v3

    invoke-static {v5, v6}, Lgtandroid/universal/KeyboardService;->access$1000276(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    goto :goto_0
.end method
