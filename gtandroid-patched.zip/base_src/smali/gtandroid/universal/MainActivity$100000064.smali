.class Lgtandroid/universal/MainActivity$100000064;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000064"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$etAnswer:Landroid/widget/EditText;

.field private final val$etCommand:Landroid/widget/EditText;

.field private final val$etName:Landroid/widget/EditText;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;)V
    .locals 8

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000064;->this$0:Lgtandroid/universal/MainActivity;

    move-object v6, v0

    move-object v7, v2

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000064;->val$etName:Landroid/widget/EditText;

    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000064;->val$etCommand:Landroid/widget/EditText;

    move-object v6, v0

    move-object v7, v4

    iput-object v7, v6, Lgtandroid/universal/MainActivity$100000064;->val$etAnswer:Landroid/widget/EditText;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000064;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000064;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/DialogInterface;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2346
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000064;->val$etName:Landroid/widget/EditText;

    invoke-virtual {v8}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v8

    invoke-interface {v8}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    move-object v4, v8

    .line 2347
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000064;->val$etCommand:Landroid/widget/EditText;

    invoke-virtual {v8}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v8

    invoke-interface {v8}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    move-object v5, v8

    .line 2348
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000064;->val$etAnswer:Landroid/widget/EditText;

    invoke-virtual {v8}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v8

    invoke-interface {v8}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    move-object v6, v8

    .line 2350
    move-object v8, v4

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_0

    move-object v8, v6

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-nez v8, :cond_0

    .line 2351
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000064;->this$0:Lgtandroid/universal/MainActivity;

    move-object v9, v4

    move-object v10, v5

    move-object v11, v6

    invoke-static {v8, v9, v10, v11}, Lgtandroid/universal/MainActivity;->access$1000155(Lgtandroid/universal/MainActivity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 2352
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000064;->this$0:Lgtandroid/universal/MainActivity;

    const-string v9, "\u2705 \u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e!"

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 2354
    :goto_0
    return-void

    :cond_0
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000064;->this$0:Lgtandroid/universal/MainActivity;

    const-string v9, "\u0417\u0430\u043f\u043e\u043b\u043d\u0438\u0442\u0435 \u043d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u0438 \u043e\u0442\u0432\u0435\u0442!"

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    goto :goto_0
.end method
