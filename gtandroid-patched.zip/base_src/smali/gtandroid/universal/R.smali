.class public final Lgtandroid/universal/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/R$attr;,
        Lgtandroid/universal/R$drawable;,
        Lgtandroid/universal/R$id;,
        Lgtandroid/universal/R$layout;,
        Lgtandroid/universal/R$menu;,
        Lgtandroid/universal/R$mipmap;,
        Lgtandroid/universal/R$string;,
        Lgtandroid/universal/R$style;,
        Lgtandroid/universal/R$xml;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 171
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
