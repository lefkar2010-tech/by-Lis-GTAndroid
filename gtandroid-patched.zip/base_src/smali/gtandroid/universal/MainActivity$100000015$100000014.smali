.class Lgtandroid/universal/MainActivity$100000015$100000014;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity$100000015;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000014"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity$100000015;

.field private final val$bitmap:Landroid/graphics/Bitmap;

.field private final val$imageView:Landroid/widget/ImageView;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity$100000015;Landroid/widget/ImageView;Landroid/graphics/Bitmap;)V
    .locals 7

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v5, v0

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v0

    move-object v6, v1

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000015$100000014;->this$0:Lgtandroid/universal/MainActivity$100000015;

    move-object v5, v0

    move-object v6, v2

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000015$100000014;->val$imageView:Landroid/widget/ImageView;

    move-object v5, v0

    move-object v6, v3

    iput-object v6, v5, Lgtandroid/universal/MainActivity$100000015$100000014;->val$bitmap:Landroid/graphics/Bitmap;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000015$100000014;)Lgtandroid/universal/MainActivity$100000015;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000015$100000014;->this$0:Lgtandroid/universal/MainActivity$100000015;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 784
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lgtandroid/universal/MainActivity$100000015$100000014;->val$imageView:Landroid/widget/ImageView;

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000015$100000014;->val$bitmap:Landroid/graphics/Bitmap;

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    return-void
.end method
