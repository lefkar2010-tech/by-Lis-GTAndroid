.class Lgtandroid/universal/MainActivity$100000059;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000059"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$command:Ljava/lang/String;

.field private final val$index:I

.field private final val$minLevel:Ljava/lang/String;

.field private final val$name:Ljava/lang/String;

.field private final val$reason:Ljava/lang/String;

.field private final val$time:Ljava/lang/String;

.field private final val$typeName:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 12

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move v3, p3

    move-object/from16 v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object v10, v0

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    move-object v10, v0

    move-object v11, v1

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000059;->this$0:Lgtandroid/universal/MainActivity;

    move-object v10, v0

    move-object v11, v2

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000059;->val$typeName:Ljava/lang/String;

    move-object v10, v0

    move v11, v3

    iput v11, v10, Lgtandroid/universal/MainActivity$100000059;->val$index:I

    move-object v10, v0

    move-object v11, v4

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000059;->val$name:Ljava/lang/String;

    move-object v10, v0

    move-object v11, v5

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000059;->val$command:Ljava/lang/String;

    move-object v10, v0

    move-object v11, v6

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000059;->val$time:Ljava/lang/String;

    move-object v10, v0

    move-object v11, v7

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000059;->val$reason:Ljava/lang/String;

    move-object v10, v0

    move-object v11, v8

    iput-object v11, v10, Lgtandroid/universal/MainActivity$100000059;->val$minLevel:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000059;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000059;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2150
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000059;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/MainActivity$100000059;->val$typeName:Ljava/lang/String;

    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/MainActivity$100000059;->val$index:I

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000059;->val$name:Ljava/lang/String;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000059;->val$command:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000059;->val$time:Ljava/lang/String;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000059;->val$reason:Ljava/lang/String;

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000059;->val$minLevel:Ljava/lang/String;

    invoke-static/range {v3 .. v10}, Lgtandroid/universal/MainActivity;->access$1000147(Lgtandroid/universal/MainActivity;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
