.class Lgtandroid/universal/FloatingService$100000011;
.super Ljava/lang/Object;
.source "FloatingService.java"

# interfaces
.implements Landroid/widget/RadioGroup$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/FloatingService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000011"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/FloatingService;


# direct methods
.method constructor <init>(Lgtandroid/universal/FloatingService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/FloatingService$100000011;)Lgtandroid/universal/FloatingService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/RadioGroup;I)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/RadioGroup;",
            "I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 734
    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v4, v2

    const/4 v5, 0x1

    if-ne v4, v5, :cond_0

    .line 735
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    const/4 v5, 0x1

    invoke-static {v4, v5}, Lgtandroid/universal/FloatingService;->access$S1000015(Lgtandroid/universal/FloatingService;I)V

    .line 736
    const/4 v4, 0x1

    sput v4, Lgtandroid/universal/FloatingService;->currentCheatMode:I

    .line 737
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    const-string v5, "\u0427\u0438\u0442: \u0411\u0435\u0441\u0441\u043c\u0435\u0440\u0442\u0438\u0435 (/gm) - \u043e\u0434\u043d\u043e\u0440\u0430\u0437\u043e\u0432\u044b\u0439"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    .line 750
    :goto_0
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v4}, Lgtandroid/universal/FloatingService;->access$L1000013(Lgtandroid/universal/FloatingService;)Landroid/content/SharedPreferences;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const-string v5, "cheat_mode"

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v6}, Lgtandroid/universal/FloatingService;->access$L1000015(Lgtandroid/universal/FloatingService;)I

    move-result v6

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 751
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    invoke-static {v4}, Lgtandroid/universal/FloatingService;->access$1000034(Lgtandroid/universal/FloatingService;)V

    return-void

    .line 738
    :cond_0
    move v4, v2

    const/4 v5, 0x2

    if-ne v4, v5, :cond_1

    .line 739
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    const/4 v5, 0x2

    invoke-static {v4, v5}, Lgtandroid/universal/FloatingService;->access$S1000015(Lgtandroid/universal/FloatingService;I)V

    .line 740
    const/4 v4, 0x2

    sput v4, Lgtandroid/universal/FloatingService;->currentCheatMode:I

    .line 741
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    const-string v5, "\u0427\u0438\u0442: ID \u0422\u0421 (/dl) - \u043e\u0434\u043d\u043e\u0440\u0430\u0437\u043e\u0432\u044b\u0439"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 742
    :cond_1
    move v4, v2

    const/4 v5, 0x3

    if-ne v4, v5, :cond_2

    .line 743
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    const/4 v5, 0x3

    invoke-static {v4, v5}, Lgtandroid/universal/FloatingService;->access$S1000015(Lgtandroid/universal/FloatingService;I)V

    .line 744
    const/4 v4, 0x3

    sput v4, Lgtandroid/universal/FloatingService;->currentCheatMode:I

    .line 745
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    const-string v5, "\u0427\u0438\u0442: \u041c\u0430\u0441\u043a\u0430 (/clist) - \u043e\u0434\u043d\u043e\u0440\u0430\u0437\u043e\u0432\u044b\u0439"

    const/4 v6, 0x0

    invoke-static {v4, v5, v6}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v4

    invoke-virtual {v4}, Landroid/widget/Toast;->show()V

    goto :goto_0

    .line 747
    :cond_2
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/FloatingService$100000011;->this$0:Lgtandroid/universal/FloatingService;

    const/4 v5, 0x0

    invoke-static {v4, v5}, Lgtandroid/universal/FloatingService;->access$S1000015(Lgtandroid/universal/FloatingService;I)V

    .line 748
    const/4 v4, 0x0

    sput v4, Lgtandroid/universal/FloatingService;->currentCheatMode:I

    goto :goto_0
.end method
