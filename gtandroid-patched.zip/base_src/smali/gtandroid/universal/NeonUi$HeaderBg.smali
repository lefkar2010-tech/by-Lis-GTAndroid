.class public Lgtandroid/universal/NeonUi$HeaderBg;
.super Landroid/graphics/drawable/Drawable;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x29
    name = "HeaderBg"
.end annotation


# instance fields
.field private alpha:I

.field private final dens:F

.field private final edge:Landroid/graphics/Paint;

.field private final fill:Landroid/graphics/Paint;

.field private final line:Landroid/graphics/Paint;

.field private final r:Landroid/graphics/RectF;

.field private final radius:F

.field private final strokeW:F

.field private final tv:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/widget/TextView;)V
    .locals 9

    .prologue
    .line 233
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v4, v0

    invoke-direct {v4}, Landroid/graphics/drawable/Drawable;-><init>()V

    move-object v4, v0

    new-instance v5, Landroid/graphics/Paint;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    const/4 v7, 0x1

    invoke-direct {v6, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->fill:Landroid/graphics/Paint;

    move-object v4, v0

    new-instance v5, Landroid/graphics/Paint;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    const/4 v7, 0x1

    invoke-direct {v6, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->edge:Landroid/graphics/Paint;

    move-object v4, v0

    new-instance v5, Landroid/graphics/Paint;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    const/4 v7, 0x1

    invoke-direct {v6, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object v4, v0

    new-instance v5, Landroid/graphics/RectF;

    move-object v8, v5

    move-object v5, v8

    move-object v6, v8

    invoke-direct {v6}, Landroid/graphics/RectF;-><init>()V

    iput-object v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->r:Landroid/graphics/RectF;

    move-object v4, v0

    const/16 v5, 0xff

    iput v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->alpha:I

    .line 234
    move-object v4, v0

    move-object v5, v2

    iput-object v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->tv:Landroid/widget/TextView;

    .line 235
    move-object v4, v0

    move-object v5, v1

    invoke-virtual {v5}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    iget v5, v5, Landroid/util/DisplayMetrics;->density:F

    iput v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    .line 236
    move-object v4, v0

    move-object v5, v1

    const/high16 v6, 0x41200000    # 10.0f

    invoke-static {v5, v6}, Lgtandroid/universal/NeonUi;->dp(Landroid/content/Context;F)I

    move-result v5

    int-to-float v5, v5

    iput v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->radius:F

    .line 237
    move-object v4, v0

    const/high16 v5, 0x3f800000    # 1.0f

    move-object v6, v0

    iget v6, v6, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    invoke-static {v5, v6}, Ljava/lang/Math;->max(FF)F

    move-result v5

    iput v5, v4, Lgtandroid/universal/NeonUi$HeaderBg;->strokeW:F

    .line 238
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$HeaderBg;->edge:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 239
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$HeaderBg;->edge:Landroid/graphics/Paint;

    move-object v5, v0

    iget v5, v5, Lgtandroid/universal/NeonUi$HeaderBg;->strokeW:F

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 240
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 241
    move-object v4, v0

    iget-object v4, v4, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    sget-object v5, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    return-void
.end method


# virtual methods
.method public draw(Landroid/graphics/Canvas;)V
    .locals 33
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Canvas;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 252
    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object/from16 v26, v2

    invoke-virtual/range {v26 .. v26}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v26

    move-object/from16 v5, v26

    .line 253
    move-object/from16 v26, v5

    invoke-virtual/range {v26 .. v26}, Landroid/graphics/Rect;->height()I

    move-result v26

    move/from16 v0, v26

    int-to-float v0, v0

    move/from16 v26, v0

    move/from16 v6, v26

    .line 254
    move/from16 v26, v6

    const/16 v27, 0x0

    move/from16 v0, v27

    int-to-float v0, v0

    move/from16 v27, v0

    cmpg-float v26, v26, v27

    if-gtz v26, :cond_0

    .line 274
    :goto_0
    return-void

    .line 256
    :cond_0
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->fill:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->alpha:I

    move/from16 v27, v0

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setAlpha(I)V

    .line 257
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->r:Landroid/graphics/RectF;

    move-object/from16 v26, v0

    move-object/from16 v27, v5

    move-object/from16 v0, v27

    iget v0, v0, Landroid/graphics/Rect;->left:I

    move/from16 v27, v0

    move/from16 v0, v27

    int-to-float v0, v0

    move/from16 v27, v0

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->strokeW:F

    move/from16 v28, v0

    const/high16 v29, 0x40000000    # 2.0f

    div-float v28, v28, v29

    add-float v27, v27, v28

    move-object/from16 v28, v5

    move-object/from16 v0, v28

    iget v0, v0, Landroid/graphics/Rect;->top:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-float v0, v0

    move/from16 v28, v0

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->strokeW:F

    move/from16 v29, v0

    const/high16 v30, 0x40000000    # 2.0f

    div-float v29, v29, v30

    add-float v28, v28, v29

    move-object/from16 v29, v5

    move-object/from16 v0, v29

    iget v0, v0, Landroid/graphics/Rect;->right:I

    move/from16 v29, v0

    move/from16 v0, v29

    int-to-float v0, v0

    move/from16 v29, v0

    move-object/from16 v30, v2

    move-object/from16 v0, v30

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->strokeW:F

    move/from16 v30, v0

    const/high16 v31, 0x40000000    # 2.0f

    div-float v30, v30, v31

    sub-float v29, v29, v30

    move-object/from16 v30, v5

    move-object/from16 v0, v30

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    move/from16 v30, v0

    move/from16 v0, v30

    int-to-float v0, v0

    move/from16 v30, v0

    move-object/from16 v31, v2

    move-object/from16 v0, v31

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->strokeW:F

    move/from16 v31, v0

    const/high16 v32, 0x40000000    # 2.0f

    div-float v31, v31, v32

    sub-float v30, v30, v31

    invoke-virtual/range {v26 .. v30}, Landroid/graphics/RectF;->set(FFFF)V

    .line 259
    move-object/from16 v26, v3

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->r:Landroid/graphics/RectF;

    move-object/from16 v27, v0

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->radius:F

    move/from16 v28, v0

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->radius:F

    move/from16 v29, v0

    move-object/from16 v30, v2

    move-object/from16 v0, v30

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->fill:Landroid/graphics/Paint;

    move-object/from16 v30, v0

    invoke-virtual/range {v26 .. v30}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 260
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->edge:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    const v27, -0xd13701

    const/16 v28, 0x88

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->alpha:I

    move/from16 v29, v0

    mul-int v28, v28, v29

    const/16 v29, 0xff

    move/from16 v0, v28

    div-int/lit16 v0, v0, 0xff

    move/from16 v28, v0

    invoke-static/range {v27 .. v28}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v27

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setColor(I)V

    .line 261
    move-object/from16 v26, v3

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->r:Landroid/graphics/RectF;

    move-object/from16 v27, v0

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->radius:F

    move/from16 v28, v0

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->radius:F

    move/from16 v29, v0

    move-object/from16 v30, v2

    move-object/from16 v0, v30

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->edge:Landroid/graphics/Paint;

    move-object/from16 v30, v0

    invoke-virtual/range {v26 .. v30}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 263
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->tv:Landroid/widget/TextView;

    move-object/from16 v26, v0

    invoke-virtual/range {v26 .. v26}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v26

    move-object/from16 v7, v26

    .line 264
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->tv:Landroid/widget/TextView;

    move-object/from16 v26, v0

    invoke-virtual/range {v26 .. v26}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v26

    move-object/from16 v27, v7

    if-nez v27, :cond_1

    const-string v27, ""

    :goto_1
    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->measureText(Ljava/lang/String;)F

    move-result v26

    move/from16 v8, v26

    .line 265
    move-object/from16 v26, v5

    invoke-virtual/range {v26 .. v26}, Landroid/graphics/Rect;->exactCenterX()F

    move-result v26

    move/from16 v9, v26

    .line 266
    move-object/from16 v26, v5

    invoke-virtual/range {v26 .. v26}, Landroid/graphics/Rect;->exactCenterY()F

    move-result v26

    move/from16 v10, v26

    .line 267
    move/from16 v26, v8

    const/high16 v27, 0x40000000    # 2.0f

    div-float v26, v26, v27

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    move/from16 v27, v0

    const/high16 v28, 0x41400000    # 12.0f

    mul-float v27, v27, v28

    add-float v26, v26, v27

    move/from16 v11, v26

    .line 268
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    move/from16 v26, v0

    const/high16 v27, 0x40e00000    # 7.0f

    mul-float v26, v26, v27

    move/from16 v12, v26

    .line 269
    move-object/from16 v26, v5

    move-object/from16 v0, v26

    iget v0, v0, Landroid/graphics/Rect;->top:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-float v0, v0

    move/from16 v26, v0

    move/from16 v27, v6

    const v28, 0x3e75c28f    # 0.24f

    mul-float v27, v27, v28

    add-float v26, v26, v27

    move/from16 v13, v26

    .line 270
    move-object/from16 v26, v5

    move-object/from16 v0, v26

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-float v0, v0

    move/from16 v26, v0

    move/from16 v27, v6

    const v28, 0x3e75c28f    # 0.24f

    mul-float v27, v27, v28

    sub-float v26, v26, v27

    move/from16 v14, v26

    .line 271
    move/from16 v26, v6

    const v27, 0x3e6147ae    # 0.22f

    mul-float v26, v26, v27

    move/from16 v15, v26

    .line 272
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    move/from16 v26, v0

    const/high16 v27, 0x41600000    # 14.0f

    mul-float v26, v26, v27

    move/from16 v16, v26

    .line 274
    const/16 v26, -0x1

    move/from16 v17, v26

    :goto_2
    move/from16 v26, v17

    const/16 v27, 0x1

    move/from16 v0, v26

    move/from16 v1, v27

    if-le v0, v1, :cond_2

    goto/16 :goto_0

    .line 264
    :cond_1
    move-object/from16 v27, v7

    invoke-interface/range {v27 .. v27}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v27

    goto/16 :goto_1

    .line 275
    :cond_2
    const/16 v26, 0x0

    move/from16 v18, v26

    :goto_3
    move/from16 v26, v18

    const/16 v27, 0x3

    move/from16 v0, v26

    move/from16 v1, v27

    if-lt v0, v1, :cond_6

    .line 295
    move/from16 v26, v9

    move/from16 v27, v17

    move/from16 v0, v27

    int-to-float v0, v0

    move/from16 v27, v0

    move/from16 v28, v11

    const/16 v29, 0x2

    move/from16 v0, v29

    int-to-float v0, v0

    move/from16 v29, v0

    move/from16 v30, v12

    mul-float v29, v29, v30

    add-float v28, v28, v29

    move/from16 v29, v15

    add-float v28, v28, v29

    mul-float v27, v27, v28

    add-float v26, v26, v27

    move/from16 v18, v26

    .line 296
    move/from16 v26, v17

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-ge v0, v1, :cond_c

    move-object/from16 v26, v5

    move-object/from16 v0, v26

    iget v0, v0, Landroid/graphics/Rect;->left:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-float v0, v0

    move/from16 v26, v0

    move/from16 v27, v16

    add-float v26, v26, v27

    :goto_4
    move/from16 v19, v26

    .line 297
    move/from16 v26, v17

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-ge v0, v1, :cond_3

    move/from16 v26, v18

    move/from16 v27, v19

    cmpg-float v26, v26, v27

    if-gtz v26, :cond_4

    :cond_3
    move/from16 v26, v17

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-le v0, v1, :cond_5

    move/from16 v26, v18

    move/from16 v27, v19

    cmpg-float v26, v26, v27

    if-gez v26, :cond_5

    .line 298
    :cond_4
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    move/from16 v27, v0

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 299
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    const v27, -0xd13701

    const/16 v28, 0x55

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->alpha:I

    move/from16 v29, v0

    mul-int v28, v28, v29

    const/16 v29, 0xff

    move/from16 v0, v28

    div-int/lit16 v0, v0, 0xff

    move/from16 v28, v0

    invoke-static/range {v27 .. v28}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v27

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setColor(I)V

    .line 300
    move-object/from16 v26, v3

    move/from16 v27, v18

    move/from16 v28, v10

    move/from16 v29, v19

    move/from16 v30, v10

    move-object/from16 v31, v2

    move-object/from16 v0, v31

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v31, v0

    invoke-virtual/range {v26 .. v31}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 274
    :cond_5
    move/from16 v26, v17

    const/16 v27, 0x2

    add-int/lit8 v26, v26, 0x2

    move/from16 v17, v26

    goto/16 :goto_2

    .line 276
    :cond_6
    move/from16 v26, v9

    move/from16 v27, v17

    move/from16 v0, v27

    int-to-float v0, v0

    move/from16 v27, v0

    move/from16 v28, v11

    move/from16 v29, v18

    move/from16 v0, v29

    int-to-float v0, v0

    move/from16 v29, v0

    move/from16 v30, v12

    mul-float v29, v29, v30

    add-float v28, v28, v29

    mul-float v27, v27, v28

    add-float v26, v26, v27

    move/from16 v19, v26

    .line 277
    move/from16 v26, v19

    move-object/from16 v27, v5

    move-object/from16 v0, v27

    iget v0, v0, Landroid/graphics/Rect;->left:I

    move/from16 v27, v0

    move/from16 v0, v27

    int-to-float v0, v0

    move/from16 v27, v0

    move/from16 v28, v16

    add-float v27, v27, v28

    cmpl-float v26, v26, v27

    if-ltz v26, :cond_7

    move/from16 v26, v19

    move-object/from16 v27, v5

    move-object/from16 v0, v27

    iget v0, v0, Landroid/graphics/Rect;->right:I

    move/from16 v27, v0

    move/from16 v0, v27

    int-to-float v0, v0

    move/from16 v27, v0

    move/from16 v28, v16

    sub-float v27, v27, v28

    cmpl-float v26, v26, v27

    if-lez v26, :cond_8

    .line 275
    :cond_7
    :goto_5
    add-int/lit8 v18, v18, 0x1

    goto/16 :goto_3

    .line 278
    :cond_8
    move/from16 v26, v18

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-ne v0, v1, :cond_9

    const/16 v26, 0xff

    :goto_6
    move/from16 v20, v26

    .line 279
    move/from16 v26, v17

    const/16 v27, 0x0

    move/from16 v0, v26

    move/from16 v1, v27

    if-ge v0, v1, :cond_b

    .line 281
    move/from16 v26, v19

    move/from16 v27, v15

    const/high16 v28, 0x40000000    # 2.0f

    div-float v27, v27, v28

    sub-float v26, v26, v27

    move/from16 v21, v26

    move/from16 v26, v14

    move/from16 v22, v26

    move/from16 v26, v19

    move/from16 v27, v15

    const/high16 v28, 0x40000000    # 2.0f

    div-float v27, v27, v28

    add-float v26, v26, v27

    move/from16 v23, v26

    move/from16 v26, v13

    move/from16 v24, v26

    .line 286
    :goto_7
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    move/from16 v27, v0

    const/high16 v28, 0x40900000    # 4.5f

    mul-float v27, v27, v28

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 287
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    const v27, -0xd13701

    move/from16 v28, v20

    const/16 v29, 0x4

    div-int/lit8 v28, v28, 0x4

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->alpha:I

    move/from16 v29, v0

    mul-int v28, v28, v29

    const/16 v29, 0xff

    move/from16 v0, v28

    div-int/lit16 v0, v0, 0xff

    move/from16 v28, v0

    invoke-static/range {v27 .. v28}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v27

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setColor(I)V

    .line 288
    move-object/from16 v26, v3

    move/from16 v27, v21

    move/from16 v28, v22

    move/from16 v29, v23

    move/from16 v30, v24

    move-object/from16 v31, v2

    move-object/from16 v0, v31

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v31, v0

    invoke-virtual/range {v26 .. v31}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 290
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->dens:F

    move/from16 v27, v0

    const v28, 0x3fe66666    # 1.8f

    mul-float v27, v27, v28

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 291
    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v26, v0

    const v27, -0xd13701

    move/from16 v28, v20

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->alpha:I

    move/from16 v29, v0

    mul-int v28, v28, v29

    const/16 v29, 0xff

    move/from16 v0, v28

    div-int/lit16 v0, v0, 0xff

    move/from16 v28, v0

    invoke-static/range {v27 .. v28}, Lgtandroid/universal/NeonUi;->withAlpha(II)I

    move-result v27

    invoke-virtual/range {v26 .. v27}, Landroid/graphics/Paint;->setColor(I)V

    .line 292
    move-object/from16 v26, v3

    move/from16 v27, v21

    move/from16 v28, v22

    move/from16 v29, v23

    move/from16 v30, v24

    move-object/from16 v31, v2

    move-object/from16 v0, v31

    iget-object v0, v0, Lgtandroid/universal/NeonUi$HeaderBg;->line:Landroid/graphics/Paint;

    move-object/from16 v31, v0

    invoke-virtual/range {v26 .. v31}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    goto/16 :goto_5

    .line 278
    :cond_9
    move/from16 v26, v18

    const/16 v27, 0x1

    move/from16 v0, v26

    move/from16 v1, v27

    if-ne v0, v1, :cond_a

    const/16 v26, 0xaa

    goto/16 :goto_6

    :cond_a
    const/16 v26, 0x60

    goto/16 :goto_6

    .line 283
    :cond_b
    move/from16 v26, v19

    move/from16 v27, v15

    const/high16 v28, 0x40000000    # 2.0f

    div-float v27, v27, v28

    sub-float v26, v26, v27

    move/from16 v21, v26

    move/from16 v26, v13

    move/from16 v22, v26

    move/from16 v26, v19

    move/from16 v27, v15

    const/high16 v28, 0x40000000    # 2.0f

    div-float v27, v27, v28

    add-float v26, v26, v27

    move/from16 v23, v26

    move/from16 v26, v14

    move/from16 v24, v26

    goto/16 :goto_7

    .line 296
    :cond_c
    move-object/from16 v26, v5

    move-object/from16 v0, v26

    iget v0, v0, Landroid/graphics/Rect;->right:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-float v0, v0

    move/from16 v26, v0

    move/from16 v27, v16

    sub-float v26, v26, v27

    goto/16 :goto_4
.end method

.method public getOpacity()I
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 307
    move-object v0, p0

    const/4 v2, -0x3

    move v0, v2

    return v0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/Rect;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 246
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/NeonUi$HeaderBg;->fill:Landroid/graphics/Paint;

    new-instance v4, Landroid/graphics/LinearGradient;

    move-object v13, v4

    move-object v4, v13

    move-object v5, v13

    const/4 v6, 0x0

    move-object v7, v1

    iget v7, v7, Landroid/graphics/Rect;->top:I

    int-to-float v7, v7

    const/4 v8, 0x0

    move-object v9, v1

    iget v9, v9, Landroid/graphics/Rect;->bottom:I

    int-to-float v9, v9

    const v10, -0xe9d6b1

    const v11, -0xf4e9ce

    sget-object v12, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct/range {v5 .. v12}, Landroid/graphics/LinearGradient;-><init>(FFFFIILandroid/graphics/Shader$TileMode;)V

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    move-result-object v3

    return-void
.end method

.method public setAlpha(I)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 305
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    move v4, v1

    iput v4, v3, Lgtandroid/universal/NeonUi$HeaderBg;->alpha:I

    move-object v3, v0

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/graphics/ColorFilter;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    return-void
.end method
