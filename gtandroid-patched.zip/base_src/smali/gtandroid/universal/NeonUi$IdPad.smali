.class public final Lgtandroid/universal/NeonUi$IdPad;
.super Ljava/lang/Object;
.source "NeonUi.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/NeonUi;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "IdPad"
.end annotation


# instance fields
.field public final backBottom:Landroid/widget/Button;

.field public final continueTop:Landroid/widget/Button;

.field public final field:Landroid/widget/EditText;

.field public final root:Landroid/widget/LinearLayout;


# direct methods
.method constructor <init>(Landroid/widget/LinearLayout;Landroid/widget/EditText;Landroid/widget/Button;Landroid/widget/Button;)V
    .locals 8

    .prologue
    .line 1436
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v6, v0

    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 1437
    move-object v6, v0

    move-object v7, v1

    iput-object v7, v6, Lgtandroid/universal/NeonUi$IdPad;->root:Landroid/widget/LinearLayout;

    .line 1438
    move-object v6, v0

    move-object v7, v2

    iput-object v7, v6, Lgtandroid/universal/NeonUi$IdPad;->field:Landroid/widget/EditText;

    .line 1439
    move-object v6, v0

    move-object v7, v3

    iput-object v7, v6, Lgtandroid/universal/NeonUi$IdPad;->continueTop:Landroid/widget/Button;

    .line 1440
    move-object v6, v0

    move-object v7, v4

    iput-object v7, v6, Lgtandroid/universal/NeonUi$IdPad;->backBottom:Landroid/widget/Button;

    return-void
.end method


# virtual methods
.method public setOnBack(Landroid/view/View$OnClickListener;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View$OnClickListener;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1448
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/NeonUi$IdPad;->backBottom:Landroid/widget/Button;

    move-object v4, v1

    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public setOnContinue(Landroid/view/View$OnClickListener;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View$OnClickListener;",
            ")V"
        }
    .end annotation

    .prologue
    .line 1444
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/NeonUi$IdPad;->continueTop:Landroid/widget/Button;

    move-object v4, v1

    invoke-virtual {v3, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method
