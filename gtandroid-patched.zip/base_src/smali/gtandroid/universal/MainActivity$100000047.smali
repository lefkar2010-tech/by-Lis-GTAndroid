.class Lgtandroid/universal/MainActivity$100000047;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000047"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$cbFollow:Landroid/widget/CheckBox;

.field private final val$dlg:Landroid/app/AlertDialog;

.field private final val$etWord:Landroid/widget/EditText;

.field private final val$index:I

.field private final val$selName:[Ljava/lang/String;

.field private final val$selText:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;Landroid/widget/EditText;[Ljava/lang/String;Landroid/widget/CheckBox;[Ljava/lang/String;ILandroid/app/AlertDialog;)V
    .locals 11

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object/from16 v5, p5

    move/from16 v6, p6

    move-object/from16 v7, p7

    move-object v9, v0

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    move-object v9, v0

    move-object v10, v1

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    move-object v9, v0

    move-object v10, v2

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000047;->val$etWord:Landroid/widget/EditText;

    move-object v9, v0

    move-object v10, v3

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000047;->val$selName:[Ljava/lang/String;

    move-object v9, v0

    move-object v10, v4

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000047;->val$cbFollow:Landroid/widget/CheckBox;

    move-object v9, v0

    move-object v10, v5

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000047;->val$selText:[Ljava/lang/String;

    move-object v9, v0

    move v10, v6

    iput v10, v9, Lgtandroid/universal/MainActivity$100000047;->val$index:I

    move-object v9, v0

    move-object v10, v7

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000047;->val$dlg:Landroid/app/AlertDialog;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000047;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 1680
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->val$etWord:Landroid/widget/EditText;

    invoke-virtual {v8}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v8

    invoke-interface {v8}, Landroid/text/Editable;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v8

    move-object v3, v8

    .line 1681
    move-object v8, v3

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_0

    .line 1682
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    const-string v9, "\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0441\u043b\u043e\u0432\u043e \u0442\u0440\u0438\u0433\u0433\u0435\u0440"

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 1705
    :goto_0
    return-void

    .line 1685
    :cond_0
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->val$selName:[Ljava/lang/String;

    const/4 v9, 0x0

    aget-object v8, v8, v9

    if-eqz v8, :cond_1

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->val$selName:[Ljava/lang/String;

    const/4 v9, 0x0

    aget-object v8, v8, v9

    invoke-virtual {v8}, Ljava/lang/String;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_2

    .line 1686
    :cond_1
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    const-string v9, "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0431\u044b\u0441\u0442\u0440\u044b\u0439 \u043e\u0442\u0432\u0435\u0442"

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 1687
    goto :goto_0

    .line 1689
    :cond_2
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v8, v8, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    invoke-static {v8}, Lgtandroid/universal/TriggerData;->load(Landroid/content/SharedPreferences;)Ljava/util/List;

    move-result-object v8

    move-object v4, v8

    .line 1690
    new-instance v8, Lgtandroid/universal/TriggerData$Trigger;

    move-object v15, v8

    move-object v8, v15

    move-object v9, v15

    move-object v10, v3

    move-object v11, v0

    iget-object v11, v11, Lgtandroid/universal/MainActivity$100000047;->val$cbFollow:Landroid/widget/CheckBox;

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v11

    move-object v12, v0

    iget-object v12, v12, Lgtandroid/universal/MainActivity$100000047;->val$selName:[Ljava/lang/String;

    const/4 v13, 0x0

    aget-object v12, v12, v13

    move-object v13, v0

    iget-object v13, v13, Lgtandroid/universal/MainActivity$100000047;->val$selText:[Ljava/lang/String;

    const/4 v14, 0x0

    aget-object v13, v13, v14

    invoke-direct {v9, v10, v11, v12, v13}, Lgtandroid/universal/TriggerData$Trigger;-><init>(Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;)V

    move-object v5, v8

    .line 1691
    move-object v8, v5

    const/4 v9, 0x1

    iput-boolean v9, v8, Lgtandroid/universal/TriggerData$Trigger;->enabled:Z

    .line 1692
    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/MainActivity$100000047;->val$index:I

    const/4 v9, 0x0

    if-lt v8, v9, :cond_6

    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/MainActivity$100000047;->val$index:I

    move-object v9, v4

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    if-ge v8, v9, :cond_6

    .line 1693
    move-object v8, v4

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/MainActivity$100000047;->val$index:I

    move-object v10, v5

    invoke-interface {v8, v9, v10}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    .line 1694
    move-object v8, v4

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    const/4 v9, 0x1

    add-int/lit8 v8, v8, -0x1

    move v6, v8

    :goto_1
    move v8, v6

    const/4 v9, 0x0

    if-ge v8, v9, :cond_4

    .line 1702
    :goto_2
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    iget-object v8, v8, Lgtandroid/universal/MainActivity;->prefs:Landroid/content/SharedPreferences;

    move-object v9, v4

    invoke-static {v8, v9}, Lgtandroid/universal/TriggerData;->save(Landroid/content/SharedPreferences;Ljava/util/List;)V

    .line 1703
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    const-string v9, "\u0422\u0440\u0438\u0433\u0433\u0435\u0440 \u0441\u043e\u0445\u0440\u0430\u043d\u0451\u043d"

    const/4 v10, 0x0

    invoke-static {v8, v9, v10}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v8

    invoke-virtual {v8}, Landroid/widget/Toast;->show()V

    .line 1704
    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->val$dlg:Landroid/app/AlertDialog;

    invoke-virtual {v8}, Landroid/app/Dialog;->dismiss()V

    .line 1705
    move-object v8, v0

    iget v8, v8, Lgtandroid/universal/MainActivity$100000047;->val$index:I

    const/4 v9, 0x0

    if-lt v8, v9, :cond_3

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000047;->this$0:Lgtandroid/universal/MainActivity;

    invoke-static {v8}, Lgtandroid/universal/MainActivity;->access$1000115(Lgtandroid/universal/MainActivity;)V

    :cond_3
    goto/16 :goto_0

    .line 1695
    :cond_4
    move v8, v6

    move-object v9, v0

    iget v9, v9, Lgtandroid/universal/MainActivity$100000047;->val$index:I

    if-eq v8, v9, :cond_5

    move-object v8, v4

    move v9, v6

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lgtandroid/universal/TriggerData$Trigger;

    iget-object v8, v8, Lgtandroid/universal/TriggerData$Trigger;->word:Ljava/lang/String;

    invoke-static {v8}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object v9, v3

    invoke-static {v9}, Lgtandroid/universal/TriggerData;->norm(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_5

    .line 1696
    move-object v8, v4

    move v9, v6

    invoke-interface {v8, v9}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v8

    .line 1694
    :cond_5
    add-int/lit8 v6, v6, -0x1

    goto :goto_1

    .line 1700
    :cond_6
    move-object v8, v4

    move-object v9, v5

    invoke-static {v8, v9}, Lgtandroid/universal/TriggerData;->upsert(Ljava/util/List;Lgtandroid/universal/TriggerData$Trigger;)Z

    move-result v8

    goto :goto_2
.end method
