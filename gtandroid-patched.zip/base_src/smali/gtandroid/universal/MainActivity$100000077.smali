.class Lgtandroid/universal/MainActivity$100000077;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000077"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;

.field private final val$command:Ljava/lang/String;

.field private final val$index:I

.field private final val$minLevel:Ljava/lang/String;

.field private final val$name:Ljava/lang/String;

.field private final val$reason:Ljava/lang/String;

.field private final val$time:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 11

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object/from16 v5, p5

    move-object/from16 v6, p6

    move-object/from16 v7, p7

    move-object v9, v0

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    move-object v9, v0

    move-object v10, v1

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000077;->this$0:Lgtandroid/universal/MainActivity;

    move-object v9, v0

    move v10, v2

    iput v10, v9, Lgtandroid/universal/MainActivity$100000077;->val$index:I

    move-object v9, v0

    move-object v10, v3

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000077;->val$name:Ljava/lang/String;

    move-object v9, v0

    move-object v10, v4

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000077;->val$command:Ljava/lang/String;

    move-object v9, v0

    move-object v10, v5

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000077;->val$time:Ljava/lang/String;

    move-object v9, v0

    move-object v10, v6

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000077;->val$reason:Ljava/lang/String;

    move-object v9, v0

    move-object v10, v7

    iput-object v10, v9, Lgtandroid/universal/MainActivity$100000077;->val$minLevel:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000077;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000077;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 2959
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000077;->this$0:Lgtandroid/universal/MainActivity;

    move-object v4, v0

    iget v4, v4, Lgtandroid/universal/MainActivity$100000077;->val$index:I

    move-object v5, v0

    iget-object v5, v5, Lgtandroid/universal/MainActivity$100000077;->val$name:Ljava/lang/String;

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/MainActivity$100000077;->val$command:Ljava/lang/String;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/MainActivity$100000077;->val$time:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/MainActivity$100000077;->val$reason:Ljava/lang/String;

    move-object v9, v0

    iget-object v9, v9, Lgtandroid/universal/MainActivity$100000077;->val$minLevel:Ljava/lang/String;

    invoke-static/range {v3 .. v9}, Lgtandroid/universal/MainActivity;->access$1000191(Lgtandroid/universal/MainActivity;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
