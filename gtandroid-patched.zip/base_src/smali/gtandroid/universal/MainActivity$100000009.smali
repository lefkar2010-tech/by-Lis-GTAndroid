.class Lgtandroid/universal/MainActivity$100000009;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000009"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/MainActivity;


# direct methods
.method constructor <init>(Lgtandroid/universal/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/MainActivity$100000009;->this$0:Lgtandroid/universal/MainActivity;

    return-void
.end method

.method static access$0(Lgtandroid/universal/MainActivity$100000009;)Lgtandroid/universal/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/MainActivity$100000009;->this$0:Lgtandroid/universal/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 519
    move-object v0, p0

    move-object/from16 v1, p1

    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000009;->this$0:Lgtandroid/universal/MainActivity;

    const-string v11, "input_method"

    invoke-virtual {v10, v11}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/view/inputmethod/InputMethodManager;

    move-object v3, v10

    .line 521
    move-object v10, v3

    if-nez v10, :cond_0

    .line 538
    :goto_0
    return-void

    .line 522
    :cond_0
    const/4 v10, 0x0

    move v4, v10

    .line 523
    move-object v10, v3

    invoke-virtual {v10}, Landroid/view/inputmethod/InputMethodManager;->getEnabledInputMethodList()Ljava/util/List;

    move-result-object v10

    move-object v5, v10

    .line 524
    move-object v10, v5

    if-eqz v10, :cond_2

    .line 525
    move-object v10, v5

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v10

    move-object v6, v10

    .line 528
    :cond_1
    move-object v10, v6

    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-nez v10, :cond_3

    .line 532
    :cond_2
    :goto_1
    move v10, v4

    if-nez v10, :cond_4

    .line 534
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000009;->this$0:Lgtandroid/universal/MainActivity;

    const-string v11, "\u0421\u043d\u0430\u0447\u0430\u043b\u0430 \u0432\u043a\u043b\u044e\u0447\u0438 GTAndroid Keyboard"

    const/4 v12, 0x1

    invoke-static {v10, v11, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v10

    invoke-virtual {v10}, Landroid/widget/Toast;->show()V

    .line 535
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000009;->this$0:Lgtandroid/universal/MainActivity;

    new-instance v11, Landroid/content/Intent;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    const-string v13, "android.settings.INPUT_METHOD_SETTINGS"

    invoke-direct {v12, v13}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v11}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 536
    goto :goto_0

    .line 525
    :cond_3
    move-object v10, v6

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/view/inputmethod/InputMethodInfo;

    move-object v8, v10

    .line 526
    move-object v10, v0

    iget-object v10, v10, Lgtandroid/universal/MainActivity$100000009;->this$0:Lgtandroid/universal/MainActivity;

    invoke-virtual {v10}, Landroid/content/ContextWrapper;->getPackageName()Ljava/lang/String;

    move-result-object v10

    move-object v11, v8

    invoke-virtual {v11}, Landroid/view/inputmethod/InputMethodInfo;->getPackageName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_1

    .line 527
    const/4 v10, 0x1

    move v4, v10

    .line 528
    goto :goto_1

    .line 538
    :cond_4
    move-object v10, v3

    invoke-virtual {v10}, Landroid/view/inputmethod/InputMethodManager;->showInputMethodPicker()V

    goto :goto_0
.end method
