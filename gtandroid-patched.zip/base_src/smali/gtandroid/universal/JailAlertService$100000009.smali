.class Lgtandroid/universal/JailAlertService$100000009;
.super Ljava/lang/Object;
.source "JailAlertService.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/JailAlertService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000009"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lgtandroid/universal/JailAlertService$100000009$100000008;
    }
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/JailAlertService;


# direct methods
.method constructor <init>(Lgtandroid/universal/JailAlertService;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    return-void
.end method

.method static access$0(Lgtandroid/universal/JailAlertService$100000009;)Lgtandroid/universal/JailAlertService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public run()V
    .locals 28
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 603
    move-object/from16 v1, p0

    move-object/from16 v18, v1

    :try_start_0
    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    invoke-virtual/range {v18 .. v18}, Landroid/accessibilityservice/AccessibilityService;->getRootInActiveWindow()Landroid/view/accessibility/AccessibilityNodeInfo;

    move-result-object v18

    move-object/from16 v7, v18

    .line 604
    move-object/from16 v18, v7

    if-nez v18, :cond_0

    .line 631
    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    invoke-static/range {v18 .. v18}, Lgtandroid/universal/JailAlertService;->access$L1000035(Lgtandroid/universal/JailAlertService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v18

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :goto_0
    return-void

    .line 606
    :cond_0
    move-object/from16 v18, v7

    invoke-virtual/range {v18 .. v18}, Landroid/view/accessibility/AccessibilityNodeInfo;->getPackageName()Ljava/lang/CharSequence;

    move-result-object v18

    move-object/from16 v8, v18

    .line 607
    move-object/from16 v18, v8

    if-eqz v18, :cond_2

    move-object/from16 v18, v8

    invoke-interface/range {v18 .. v18}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v18

    :goto_1
    move-object/from16 v9, v18

    .line 609
    new-instance v18, Ljava/lang/StringBuilder;

    move-object/from16 v27, v18

    move-object/from16 v18, v27

    move-object/from16 v19, v27

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v10, v18

    .line 610
    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    const/16 v19, 0x0

    check-cast v19, Ljava/lang/String;

    invoke-static/range {v18 .. v19}, Lgtandroid/universal/JailAlertService;->access$S1000024(Lgtandroid/universal/JailAlertService;Ljava/lang/String;)V

    .line 611
    const/16 v18, 0x1

    move/from16 v0, v18

    new-array v0, v0, [I

    move-object/from16 v18, v0

    move-object/from16 v27, v18

    move-object/from16 v18, v27

    move-object/from16 v19, v27

    const/16 v20, 0x0

    const/16 v21, 0xfa0

    aput v21, v19, v20
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v11, v18

    .line 613
    move-object/from16 v18, v1

    :try_start_1
    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    move-object/from16 v19, v7

    move-object/from16 v20, v10

    move-object/from16 v21, v1

    move-object/from16 v0, v21

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v21, v0

    invoke-static/range {v21 .. v21}, Lgtandroid/universal/JailAlertService;->access$L1000041(Lgtandroid/universal/JailAlertService;)I

    move-result v21

    move-object/from16 v22, v1

    move-object/from16 v0, v22

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v22, v0

    invoke-static/range {v22 .. v22}, Lgtandroid/universal/JailAlertService;->access$L1000042(Lgtandroid/universal/JailAlertService;)I

    move-result v22

    move-object/from16 v23, v1

    move-object/from16 v0, v23

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v23, v0

    invoke-static/range {v23 .. v23}, Lgtandroid/universal/JailAlertService;->access$L1000041(Lgtandroid/universal/JailAlertService;)I

    move-result v23

    move-object/from16 v24, v1

    move-object/from16 v0, v24

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v24, v0

    invoke-static/range {v24 .. v24}, Lgtandroid/universal/JailAlertService;->access$L1000043(Lgtandroid/universal/JailAlertService;)I

    move-result v24

    add-int v23, v23, v24

    move-object/from16 v24, v1

    move-object/from16 v0, v24

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v24, v0

    invoke-static/range {v24 .. v24}, Lgtandroid/universal/JailAlertService;->access$L1000042(Lgtandroid/universal/JailAlertService;)I

    move-result v24

    move-object/from16 v25, v1

    move-object/from16 v0, v25

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v25, v0

    invoke-static/range {v25 .. v25}, Lgtandroid/universal/JailAlertService;->access$L1000044(Lgtandroid/universal/JailAlertService;)I

    move-result v25

    add-int v24, v24, v25

    move-object/from16 v25, v11

    invoke-static/range {v18 .. v25}, Lgtandroid/universal/JailAlertService;->access$1000095(Lgtandroid/universal/JailAlertService;Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/StringBuilder;IIII[I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 616
    move-object/from16 v18, v7

    :try_start_2
    invoke-virtual/range {v18 .. v18}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    .line 619
    move-object/from16 v18, v10

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    move-object/from16 v16, v18

    .line 620
    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    invoke-static/range {v18 .. v18}, Lgtandroid/universal/JailAlertService;->access$L1000000(Lgtandroid/universal/JailAlertService;)Landroid/os/Handler;

    move-result-object v18

    if-eqz v18, :cond_1

    .line 621
    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    invoke-static/range {v18 .. v18}, Lgtandroid/universal/JailAlertService;->access$L1000000(Lgtandroid/universal/JailAlertService;)Landroid/os/Handler;

    move-result-object v18

    new-instance v19, Lgtandroid/universal/JailAlertService$100000009$100000008;

    move-object/from16 v27, v19

    move-object/from16 v19, v27

    move-object/from16 v20, v27

    move-object/from16 v21, v1

    move-object/from16 v22, v9

    move-object/from16 v23, v16

    invoke-direct/range {v20 .. v23}, Lgtandroid/universal/JailAlertService$100000009$100000008;-><init>(Lgtandroid/universal/JailAlertService$100000009;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {v18 .. v19}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-result v18

    .line 631
    :cond_1
    :goto_2
    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    invoke-static/range {v18 .. v18}, Lgtandroid/universal/JailAlertService;->access$L1000035(Lgtandroid/universal/JailAlertService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v18

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    goto/16 :goto_0

    .line 607
    :cond_2
    :try_start_3
    const-string v18, ""

    goto/16 :goto_1

    .line 613
    :catchall_0
    move-exception v18

    move-object/from16 v12, v18

    .line 616
    move-object/from16 v18, v7

    invoke-virtual/range {v18 .. v18}, Landroid/view/accessibility/AccessibilityNodeInfo;->recycle()V

    move-object/from16 v18, v12

    throw v18
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 621
    :catch_0
    move-exception v18

    move-object/from16 v7, v18

    .line 629
    move-object/from16 v18, v1

    :try_start_4
    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    const-string v19, "AutoReport"

    move-object/from16 v20, v7

    invoke-static/range {v18 .. v20}, Lgtandroid/universal/AppLogger;->logException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v18

    move-object/from16 v3, v18

    .line 631
    move-object/from16 v18, v1

    move-object/from16 v0, v18

    iget-object v0, v0, Lgtandroid/universal/JailAlertService$100000009;->this$0:Lgtandroid/universal/JailAlertService;

    move-object/from16 v18, v0

    invoke-static/range {v18 .. v18}, Lgtandroid/universal/JailAlertService;->access$L1000035(Lgtandroid/universal/JailAlertService;)Ljava/util/concurrent/atomic/AtomicBoolean;

    move-result-object v18

    const/16 v19, 0x0

    invoke-virtual/range {v18 .. v19}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    move-object/from16 v18, v3

    throw v18
.end method
