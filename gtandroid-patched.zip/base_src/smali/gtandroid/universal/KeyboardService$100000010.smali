.class Lgtandroid/universal/KeyboardService$100000010;
.super Ljava/lang/Object;
.source "KeyboardService.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lgtandroid/universal/KeyboardService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000010"
.end annotation


# instance fields
.field private final this$0:Lgtandroid/universal/KeyboardService;

.field private final val$adminId:Ljava/lang/String;

.field private final val$command:Ljava/lang/String;

.field private final val$initials:Ljava/lang/String;

.field private final val$nick:Ljava/lang/String;


# direct methods
.method constructor <init>(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 9

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v7, v0

    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    move-object v7, v0

    move-object v8, v1

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    move-object v8, v2

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000010;->val$initials:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v3

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000010;->val$command:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v4

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000010;->val$adminId:Ljava/lang/String;

    move-object v7, v0

    move-object v8, v5

    iput-object v8, v7, Lgtandroid/universal/KeyboardService$100000010;->val$nick:Ljava/lang/String;

    return-void
.end method

.method static access$0(Lgtandroid/universal/KeyboardService$100000010;)Lgtandroid/universal/KeyboardService;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 649
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->val$initials:Ljava/lang/String;

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v6

    if-eqz v6, :cond_0

    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->val$command:Ljava/lang/String;

    :goto_0
    move-object v3, v6

    .line 650
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v3

    invoke-static {v6, v7}, Lgtandroid/universal/KeyboardService;->access$1000253(Lgtandroid/universal/KeyboardService;Ljava/lang/String;)V

    .line 652
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000095(Lgtandroid/universal/KeyboardService;)V

    .line 653
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000243(Lgtandroid/universal/KeyboardService;)V

    .line 654
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    invoke-static {v6}, Lgtandroid/universal/KeyboardService;->access$1000332(Lgtandroid/universal/KeyboardService;)V

    .line 655
    new-instance v6, Landroid/content/Intent;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    const-string v8, "AUTO_FORM_ACCEPTED"

    invoke-direct {v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object v4, v6

    .line 656
    move-object v6, v4

    const-string v7, "command"

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000010;->val$command:Ljava/lang/String;

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v6

    .line 657
    move-object v6, v4

    const-string v7, "adminId"

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000010;->val$adminId:Ljava/lang/String;

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v6

    .line 658
    move-object v6, v4

    const-string v7, "initials"

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000010;->val$initials:Ljava/lang/String;

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v6

    .line 659
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v4

    invoke-virtual {v6, v7}, Landroid/content/ContextWrapper;->sendBroadcast(Landroid/content/Intent;)V

    .line 660
    move-object v6, v0

    iget-object v6, v6, Lgtandroid/universal/KeyboardService$100000010;->this$0:Lgtandroid/universal/KeyboardService;

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000010;->val$nick:Ljava/lang/String;

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000010;->val$adminId:Ljava/lang/String;

    invoke-static {v6, v7, v8}, Lgtandroid/universal/KeyboardService;->access$1000356(Lgtandroid/universal/KeyboardService;Ljava/lang/String;Ljava/lang/String;)V

    return-void

    .line 649
    :cond_0
    new-instance v6, Ljava/lang/StringBuffer;

    move-object v10, v6

    move-object v6, v10

    move-object v7, v10

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v10, v7

    move-object v7, v10

    move-object v8, v10

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    move-object v8, v0

    iget-object v8, v8, Lgtandroid/universal/KeyboardService$100000010;->val$command:Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, " | "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v0

    iget-object v7, v7, Lgtandroid/universal/KeyboardService$100000010;->val$initials:Ljava/lang/String;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    goto/16 :goto_0
.end method
